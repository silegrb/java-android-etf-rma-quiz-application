package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;

import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.sql.BatchUpdateException;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Pitanje;
import static ba.unsa.etf.rma.klase.PomocnaBaza.kvizovi;
import static ba.unsa.etf.rma.klase.PomocnaBaza.kategorije;
import static ba.unsa.etf.rma.klase.ShareKviz.sharePitanja;

public class DodajPitanjeAkt extends AppCompatActivity {

    public class KreirajDokumentPitanjeTask extends AsyncTask<String,Void,Void> {

        @Override
        protected Void doInBackground(String... strings) {
            GoogleCredential credentials ;
            try{
                InputStream is = getResources().openRawResource(R.raw.secret);


                credentials = GoogleCredential.fromStream(is).
                        createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));


                credentials.refreshToken();

                String TOKEN = credentials.getAccessToken();
                Log.d("EMINA",TOKEN);
                String url="https://firestore.googleapis.com/v1/projects/spirala3-167cb/databases/(default)/documents/Pitanja?access_token=";

                URL urlObj=new URL(url+ URLEncoder.encode(TOKEN, "UTF-8"));
                HttpURLConnection conn= (HttpURLConnection) urlObj.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type","application/json");
                conn.setRequestProperty("Accept","application/json");
                //conn.setRequestProperty("User-Agent","Mozilla/5.0 ( compatible ) ");

                String dokument= "{ \"fields\": {\"indexTacnog\": {\"integerValue\": \""+odgovori.indexOf(tacanOdgovor)+"\"},\"naziv\": {\"stringValue\": \""+trenutnoPitanje.getNaziv()+"\"},\"odgovori\": {\"arrayValue\": {\"values\": [";
                int i=0;
                for(String o: trenutnoPitanje.getOdgovori()){
                    if(i!=0) dokument+=",";
                    i++;
                    dokument+="{\"stringValue\":\""+o+"\"}"; //ovdje treba promijeniti da trazi id dokumenta tog pitanja
                }

                dokument+="              \n" +
                        "            ]\n" +
                        "          }\n" +
                        "        }}}";

                try(OutputStream os= conn.getOutputStream()){
                    byte[] input= dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }
                int code = conn.getResponseCode();

                InputStream odgovor= conn.getInputStream();
                try(BufferedReader br= new BufferedReader(
                        new InputStreamReader(odgovor, "utf-8"))){
                    StringBuilder response= new StringBuilder();
                    String responseLine=null;
                    while((responseLine = br.readLine())!= null){
                        response.append(responseLine.trim());
                    }
                    Log.d("ODGOVOR",response.toString());
                }

            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }
    }

    private Pitanje trenutnoPitanje=new Pitanje();
    private String tacanOdgovor;
    private ArrayList<String> odgovori=new ArrayList<>();
    private String naziv;
    private ArrayAdapter adapterOdg;

    private ListView odg;
    private Button dugmeO;
    private Button dugmeT;
    private Button dugmeZ;

    private EditText etOdg;
    private EditText etNaziv;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_dodaj_pitanje);
        adapterOdg=new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, odgovori){
            @Override
            public View getView(int position, View convertView, ViewGroup parent){
                // Get the current item from ListView
                View view = super.getView(position,convertView,parent);
                int pos=odgovori.indexOf(tacanOdgovor);
                if(position == pos)
                {
                    // Set a background color for ListView regular row/item
                    view.setBackgroundColor(Color.parseColor("#008000"));
                }

                return view;
            }
        };
        odg= (ListView) findViewById(R.id.lvOdgovori);
        odg.setAdapter(adapterOdg);
        dugmeO= (Button) findViewById(R.id.btnDodajOdgovor);
        dugmeT=(Button) findViewById(R.id.btnDodajTacan);
        dugmeZ=(Button) findViewById(R.id.btnDodajPitanje);
        etOdg=(EditText) findViewById(R.id.etOdgovor);
        etNaziv=(EditText) findViewById(R.id.etNaziv);


        odg.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                odgovori.remove(i);
                adapterOdg.notifyDataSetChanged();
            }

        });
        dugmeO.setOnClickListener(new AdapterView.OnClickListener() {
            @Override
            public void onClick(View view) {
                odgovori.add(etOdg.getText().toString());
                adapterOdg.notifyDataSetChanged();
            }
        });
        dugmeT.setOnClickListener(new AdapterView.OnClickListener() {
            @Override
            public void onClick(View view) {
                odgovori.add(etOdg.getText().toString());
                tacanOdgovor=etOdg.getText().toString();
                adapterOdg.notifyDataSetChanged();
            }
        });
        dugmeZ.setOnClickListener(new AdapterView.OnClickListener() {
            @Override
            public void onClick(View view) {
                trenutnoPitanje.setTacan(tacanOdgovor);
                trenutnoPitanje.setOdgovori(odgovori);
                naziv= etNaziv.getText().toString();
                trenutnoPitanje.setNaziv(naziv);
                trenutnoPitanje.setTekstPitanja(naziv);
                sharePitanja.add(sharePitanja.size()-1,trenutnoPitanje);
                new KreirajDokumentPitanjeTask().execute("Spirala3");;
                Intent intent = new Intent();
                setResult(1,intent);
                finish();
            }
        });

    }



}
