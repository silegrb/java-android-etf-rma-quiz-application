package ba.unsa.etf.rma.fragmenti;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

import ba.unsa.etf.rma.R;

import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.ShareIgraj;

import static ba.unsa.etf.rma.klase.ShareIgraj.broj;
import static ba.unsa.etf.rma.klase.ShareIgraj.broj_preostalih;
import static ba.unsa.etf.rma.klase.ShareIgraj.broj_tacnih;
import static ba.unsa.etf.rma.klase.ShareIgraj.igraj_kviz;

public class InformacijeFrag extends Fragment {

    private TextView naziv;
    private TextView br_tacnih;
    private TextView br_preostalih;
    private TextView procenat_tacnih;
    private Button kraj;
    private OnFragmentInfInteractionListener mListener;

    public InformacijeFrag() {
        // Required empty public constructor
    }


    public static InformacijeFrag newInstance(String param1, String param2) {
        InformacijeFrag fragment = new InformacijeFrag();
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        broj_tacnih=0;

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

       View v=inflater.inflate(R.layout.fragment_informacije, container, false);
       naziv=(TextView)v.findViewById(R.id.infNazivKviza);
       br_tacnih=(TextView) v.findViewById(R.id.infBrojTacnihPitanja);
       br_preostalih=(TextView) v.findViewById(R.id.infBrojPreostalihPitanja);
       procenat_tacnih=(TextView) v.findViewById(R.id.infProcenatTacni);

       naziv.setText(igraj_kviz.getNaziv());
       kraj=(Button) v.findViewById(R.id.btnKraj);
       kraj.setOnClickListener(new AdapterView.OnClickListener() {
           @Override
           public void onClick(View view) {
             onButtonPressed();
           }
       });

        return v;
    }

    public void changeInf(){

        br_tacnih.setText(broj_tacnih+"");
        br_preostalih.setText(broj_preostalih+"");
        if(broj_preostalih<4) {
            int i=0;
        }
        if(broj!=0) {
            float proc = broj_tacnih / broj;
            procenat_tacnih.setText(Math.round(proc*100) + "%");
        } else procenat_tacnih.setText(0 + "%");
    }


    public void onButtonPressed() {
        if (mListener != null) {
            mListener.onFragmentInfInteraction();
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInfInteractionListener) {
            mListener = (OnFragmentInfInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    public interface OnFragmentInfInteractionListener {

        void onFragmentInfInteraction();
    }
}
