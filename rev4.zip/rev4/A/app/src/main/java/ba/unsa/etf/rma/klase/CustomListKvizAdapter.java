package ba.unsa.etf.rma.klase;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.maltaisn.icondialog.Icon;
import com.maltaisn.icondialog.IconHelper;

import java.security.AccessControlContext;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;

import static java.security.AccessController.getContext;


public class CustomListKvizAdapter extends BaseAdapter {
    private Activity activity;
    private ArrayList data;
    private static LayoutInflater inflater=null;
    public Resources res;
    Kviz tempValues=null;
    Context context;
    int i=0;



    public CustomListKvizAdapter(Activity a, ArrayList d, Resources resLocal) {

        /********** Take passed values **********/
        activity = a;
        data=d;
        res = resLocal;

        /***********  Layout inflator to call external xml layout () ***********/
        inflater = ( LayoutInflater )activity.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);


    }

    @Override
    public void notifyDataSetChanged() {

        super.notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        if(data.size()<=0)
            return 1;
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    public static class ViewHolder{

        public TextView naziv;
        public ImageView slika;

    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View vi = convertView;
        ViewHolder holder;

        if(convertView==null){

            /****** Inflate tabitem.xml file for each row ( Defined below ) *******/
            vi = inflater.inflate(R.layout.listaelem, null);

            /****** View Holder Object to contain tabitem.xml file elements ******/

            holder = new ViewHolder();
            holder.naziv = (TextView) vi.findViewById(R.id.lable);
            holder.slika= (ImageView) vi.findViewById(R.id.slika);


            /************  Set holder with LayoutInflater ************/
            vi.setTag( holder );
           // context=parent.getContext();
        }
        else
            holder=(ViewHolder)vi.getTag();

        if(data.size()<=0)
        {
            holder.naziv.setText("Nema unesenih kvizova");

        }
        else
        {
            /***** Get each Model object from Arraylist ********/
            tempValues=null;
            tempValues = ( Kviz ) data.get( position );

            /************  Set Model values in Holder elements ***********/

            holder.naziv.setText( tempValues.getNaziv() );
            int result=0;
 //           if(! tempValues.getNaziv().equals("Dodaj Kviz"))
//            result = Integer.parseInt(tempValues.getKategorija().getId());
//           IconHelper iconHelper= IconHelper.getInstance(context);
//           Icon icon= iconHelper.getIcon(result);
//             holder.slika.setImageDrawable(icon.getDrawable(context));



            /******** Set Item Click Listner for LayoutInflater for each row *******/

//            vi.setOnClickListener(new OnItemClickListener( position ));
        }
        return vi;
    }
}
