package ba.unsa.etf.rma.klase;

import android.content.Context;
import android.content.res.Resources;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;

public class CustomSpinnerAdapter extends ArrayAdapter<Kategorija> {


    public CustomSpinnerAdapter(Context context, ArrayList<Kategorija> kategorije ){
        super(context,0,kategorije);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return initView(position,convertView,parent);
    }


    @Override
    public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent){
        return initView(position,convertView,parent);
    }
    //da ne bismo duplicirali kod
    private View initView(int pos, View convertView,ViewGroup parent){
    //ako postoji covertview
        if (convertView == null) {
            convertView= LayoutInflater.from(getContext()).inflate(
                    R.layout.spinner_items,parent,false);

        }

        TextView ime_kat =convertView.findViewById(R.id.text_kat);
        Kategorija currentKat= getItem(pos);
        if(convertView!=null) {
            //ikona.setImageResource(currentKat.getId());
            ime_kat.setText(currentKat.getNaziv());
        }
        return convertView;
    }
}