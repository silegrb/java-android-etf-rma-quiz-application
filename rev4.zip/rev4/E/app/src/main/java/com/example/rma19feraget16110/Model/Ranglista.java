package com.example.rma19feraget16110.Model;

import java.io.Serializable;
import java.util.ArrayList;

public class Ranglista implements Serializable {
    private String nazivKviza ="";
    private String firebaseId = "";
    private ArrayList<Igrac> igrac;

    public Ranglista(String nazivKviza, ArrayList<Igrac> igrac) {
        this.nazivKviza = nazivKviza;
        this.igrac = igrac;
    }
    public Ranglista (){
        igrac = new ArrayList<>();
    }

    public String getNazivKviza() {
        return nazivKviza;
    }

    public void setNazivKviza(String nazivKviza) {
        this.nazivKviza = nazivKviza;
    }

    public ArrayList<Igrac> getIgrac() {
        return igrac;
    }

    public void setIgrac(ArrayList<Igrac> igrac) {
        this.igrac = igrac;
    }

    public String getFirebaseId() {
        return firebaseId;
    }

    public void setFirebaseId(String firebaseId) {
        this.firebaseId = firebaseId;
    }
}
