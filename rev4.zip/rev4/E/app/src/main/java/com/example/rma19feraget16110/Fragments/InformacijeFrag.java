package com.example.rma19feraget16110.Fragments;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.example.rma19feraget16110.KvizoviAkt;
import com.example.rma19feraget16110.Model.Kviz;
import com.example.rma19feraget16110.R;

public class InformacijeFrag extends Fragment{
    TextView nazivKviza,brojTacnihOdgovora,brojPreostalihPitanja,procenatTacnih;
    Kviz kviz;
    Integer broj,numberOfQuestion;
    Integer iBrojTacnih = 0;
    Button kraj;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View iv =inflater.inflate(R.layout.activity_informacije_frag,container,false);
        return iv;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if(getArguments() != null && getArguments().containsKey("kviz")){
            kviz=(Kviz)getArguments().getSerializable("kviz");
            numberOfQuestion = kviz.getPitanja().size();
            nazivKviza =getView().findViewById(R.id.infNazivKviza);
            brojTacnihOdgovora = getView().findViewById(R.id.infBrojTacnihOdgovora);
            brojPreostalihPitanja = getView().findViewById(R.id.infBrojPreostalihPitanja);
            procenatTacnih = getView().findViewById(R.id.infProcenatTacnih);
            kraj = getView().findViewById(R.id.btnKraj);
            nazivKviza.setText(kviz.getNaziv());
            brojPreostalihPitanja.setText(String.valueOf(numberOfQuestion - iBrojTacnih));
            brojTacnihOdgovora.setText(String.valueOf(iBrojTacnih));
            procenatTacnih.setText((double)iBrojTacnih/numberOfQuestion+"%");


            kraj.setOnClickListener(v -> {
                Intent i = new Intent(getContext(),KvizoviAkt.class);
                startActivity(i);
            });
        }

    }
    public void updateText(int count,Boolean trueAnswer){
        broj=count;
        if(trueAnswer) iBrojTacnih++;
        brojPreostalihPitanja.setText(String.valueOf(numberOfQuestion - broj));
        brojTacnihOdgovora.setText(String.valueOf(iBrojTacnih));
        procenatTacnih.setText(((double)iBrojTacnih/numberOfQuestion)*100+"%");
    }


}
