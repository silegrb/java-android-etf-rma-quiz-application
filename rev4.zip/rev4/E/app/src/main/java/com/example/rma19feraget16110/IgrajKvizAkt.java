package com.example.rma19feraget16110;

import android.content.Intent;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;

import com.example.rma19feraget16110.Fragments.InformacijeFrag;
import com.example.rma19feraget16110.Fragments.PitanjeFrag;
import com.example.rma19feraget16110.Fragments.RangLista;
import com.example.rma19feraget16110.Model.Kviz;
import com.example.rma19feraget16110.Services.GetAllData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;

public class IgrajKvizAkt extends AppCompatActivity implements PitanjeFrag.OnItemClick, GetAllData.ReturnData {
    Kviz kviz;
    InformacijeFrag informacijeFrag;
    FragmentManager fm =getSupportFragmentManager();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_igraj_kviz_akt);
        //new GetAllData(getApplicationContext(),IgrajKvizAkt.this).execute("Rangliste");
        Intent i=getIntent();
        Bundle b=i.getExtras();
        kviz= (Kviz) b.getSerializable("kviz");
        startAlarm();
        //FrameLayout informacije = findViewById(R.id.informacijePlace);
        //FrameLayout pitanje = findViewById(R.id.pitanjePlace);
         informacijeFrag = (InformacijeFrag)fm.findFragmentById(R.id.informacijePlace);
        if(informacijeFrag == null){
            Bundle podaci=new Bundle();
            podaci.putSerializable("kviz",kviz);
            informacijeFrag=new InformacijeFrag();
            informacijeFrag.setArguments(podaci);
            fm.beginTransaction().replace(R.id.informacijePlace,informacijeFrag).commit();
        }
        PitanjeFrag pitanjeFrag = (PitanjeFrag)fm.findFragmentById(R.id.pitanjePlace);
        if(pitanjeFrag == null){
            Bundle podaci = new Bundle();
            podaci.putSerializable("kviz",kviz);
            pitanjeFrag = new PitanjeFrag();
            pitanjeFrag.setArguments(podaci);
            fm.beginTransaction().replace(R.id.pitanjePlace,pitanjeFrag).commit();
        }
    }

    @Override
    public void onItemClicked(int count,Boolean trueAnswer) {
        fm.findFragmentById(R.id.informacijePlace);
        informacijeFrag.updateText(count,trueAnswer);
    }

    @Override
    public void returnData(JSONObject jsonObject, String kolekcija) throws JSONException {
        ArrayList<RangLista> rangliste = new ArrayList<>();
        JSONArray items = jsonObject.getJSONArray("documents");
        for(int i=0;i<items.length();i++){
            JSONObject item =items.getJSONObject(i);
            String name = item.getString("name");
            String[] temp = name.split("/");
            String categoryId = temp[6];
            JSONObject fields = item.getJSONObject("fields").getJSONObject("lista").getJSONObject("mapValue").getJSONObject("fields");
            JSONObject first = fields.getJSONObject("1");
            JSONObject second = fields.getJSONObject("2");

        }
    }

    public void startAlarm(){
        Intent i = new Intent(AlarmClock.ACTION_SET_ALARM);
        i.putExtra(AlarmClock.EXTRA_HOUR, Calendar.getInstance().getTime().getHours());
        i.putExtra(AlarmClock.EXTRA_MINUTES,Calendar.getInstance().getTime().getMinutes()+ kviz.getPitanja().size());
        i.putExtra(AlarmClock.EXTRA_MESSAGE,"Zavrseno");
        startActivity(i);
    }
}
