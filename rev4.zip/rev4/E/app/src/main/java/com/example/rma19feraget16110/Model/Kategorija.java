package com.example.rma19feraget16110.Model;

import java.io.Serializable;

public class Kategorija implements Serializable {
    private String naziv = "";
    private String id = "";
    private String databaseId = "";

    public Kategorija(String naziv,String id) {
        this.naziv = naziv;
        this.id=id;
    }

    public String getDatabaseId() {
        return databaseId;
    }

    public void setDatabaseId(String databaseId) {
        this.databaseId = databaseId;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return naziv;
    }

    @Override
    public boolean equals(Object object) {
        boolean sameSame = false;
            if (object instanceof Kategorija)
            {
                sameSame = this.naziv.equals(((Kategorija) object).naziv);
            }
        return sameSame;
    }

}
