package com.example.rma19feraget16110.Fragments;

import android.support.v4.app.Fragment;

public class RangLista extends Fragment {
}
