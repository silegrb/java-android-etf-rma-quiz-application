package com.example.rma19feraget16110.Fragments;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.example.rma19feraget16110.Model.Igrac;
import com.example.rma19feraget16110.Model.Kviz;
import com.example.rma19feraget16110.Model.Ranglista;
import com.example.rma19feraget16110.R;
import com.example.rma19feraget16110.Services.GetAllData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class PitanjeFrag extends Fragment implements GetAllData.ReturnData {
    private OnItemClick onItemClick;
    ArrayList<String> odgovori = new ArrayList<>();
    private Handler handler = new Handler();
    ArrayAdapter<String> odgovoriAdapter;
    TextView tekstPitanja;
    ListView listaOdgovora;
    Kviz kviz;
    Integer count = 0;
    Integer numberOfClicks = 0;
    String imeIgraca;
    Integer brojTacnih = 0;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View iv = inflater.inflate(R.layout.activity_pitanje_frag, container, false);
        return iv;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if(isNetworkAvailable())
            new GetAllData(getContext(), PitanjeFrag.this).execute("Rangliste");
        if (getArguments() != null && getArguments().containsKey("kviz"))
            kviz = (Kviz) getArguments().getSerializable("kviz");
        odgovori.addAll(kviz.getPitanja().get(0).getOdgovori());
        tekstPitanja = getView().findViewById(R.id.tekstPitanja);
        listaOdgovora = getView().findViewById(R.id.idodgovoriPitanja);
        tekstPitanja.setText(kviz.getPitanja().get(0).getTekstPitanja());
        odgovoriAdapter = new ArrayAdapter(getContext(), android.R.layout.simple_list_item_1, odgovori);
        listaOdgovora.setAdapter(odgovoriAdapter);
        try {
            onItemClick = (OnItemClick) getActivity();
        } catch (ClassCastException e) {
            throw new ClassCastException(getActivity().toString() + "Treba implementirat OnItemClick");
        }

        listaOdgovora.setOnItemClickListener((parent, view, position, id) -> {
            Integer corectAnswer;
            numberOfClicks++;
            Boolean trueAnswer;
            if (kviz.getPitanja().get(count).getTacan().equals(kviz.getPitanja().get(count).getOdgovori().get(position))) {
                listaOdgovora.getChildAt(position).setBackgroundColor(ContextCompat.getColor(getContext(), R.color.green));
                trueAnswer = true;
            } else {
                corectAnswer = kviz.getPitanja().get(count).getOdgovori().indexOf(kviz.getPitanja().get(count).getTacan());
                listaOdgovora.getChildAt(corectAnswer).setBackgroundColor(ContextCompat.getColor(getContext(), R.color.green));
                listaOdgovora.getChildAt(position).setBackgroundColor(ContextCompat.getColor(getContext(), R.color.red));
                trueAnswer = false;
            }
            onItemClick.onItemClicked(count, trueAnswer);
            handler.postDelayed(() -> {
                refreshFragment();
            }, 2000);
            if(trueAnswer) brojTacnih++;
            count++;
        });
    }

    public boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        boolean isConnected = false;
        if(connectivityManager != null){
            NetworkInfo activeNetwork= connectivityManager.getActiveNetworkInfo();
            isConnected = (activeNetwork != null) && (activeNetwork.isConnected());
        }
        return isConnected;
    }

    @Override
    public void returnData(JSONObject jsonObject, String kolekcija) throws JSONException {
        ArrayList<Ranglista> data = new ArrayList<>();
        JSONArray items = jsonObject.getJSONArray("documents");
        for(int i=0;i<items.length();i++){
            JSONObject item =items.getJSONObject(i);
            JSONObject nazivKviza = item.getJSONObject("fields").getJSONObject("nazivKviza");
            String naziv = nazivKviza.getString("stringValue");
            String name = item.getString("name");
            String[] temp = name.split("/");
            String firebaseId = temp[6];
            JSONObject fields = item.getJSONObject("fields").getJSONObject("lista").getJSONObject("mapValue").getJSONObject("fields");
            Iterator<String> id = fields.keys();
            ArrayList<Igrac> igraci = new ArrayList<>();
            while (id.hasNext()){
                String idD = id.next();
                JSONObject ime = fields.getJSONObject(idD).getJSONObject("mapValue").getJSONObject("fields");
                Iterator<String> imeIterator = ime.keys();
                while(imeIterator.hasNext()){
                    String imeD = imeIterator.next();
                    JSONObject object = ime.getJSONObject(imeD);
                    Double posotak = object.getDouble("doubleValue");
                    Igrac igrac = new Igrac(Integer.valueOf(idD),imeD,posotak);
                    igraci.add(igrac);
                }
            }
            Collections.sort(igraci);
            Ranglista ranglista = new Ranglista(naziv,igraci);
            ranglista.setFirebaseId(firebaseId);
            data.add(ranglista);
        }
    }


    public interface OnItemClick {
        void onItemClicked(int count, Boolean trueAnswer);
    }

    @Override
    public void onDetach() {
        onItemClick = null;
        super.onDetach();
    }

    private void refreshFragment() {
        for (int i = 0; i < kviz.getPitanja().get(count - 1).getOdgovori().size(); i++) {
            listaOdgovora.getChildAt(i).setBackgroundColor(Color.TRANSPARENT);
        }

        if (kviz.getPitanja().size() == numberOfClicks || kviz.getPitanja().get(numberOfClicks).getNaziv().equals("Dodaj pitanje")) {
            tekstPitanja.setText("Kviz je zavrsen!");
            odgovoriAdapter.clear();
            AlertDialog.Builder adb = new AlertDialog.Builder(getContext());
            LayoutInflater li =LayoutInflater.from(getContext());
            View promptsView =li.inflate(R.layout.prompts,null);
            EditText ime = promptsView.findViewById(R.id.editTextDialogUserInput);
            adb.setView(promptsView);
            adb.setTitle("Rang lista");
            adb.setNegativeButton("Cancel",null);
            adb.setPositiveButton("OK", (dialog, which) -> {
                imeIgraca = ime.getText().toString();
            });
            adb.show();
        } else {
            odgovoriAdapter.clear();
            odgovori.addAll(kviz.getPitanja().get(count).getOdgovori());
            tekstPitanja.setText(kviz.getPitanja().get(count).getTekstPitanja());
            odgovoriAdapter.notifyDataSetChanged();
        }
    }

    public void determinePozition(ArrayList<Igrac> igraci,Igrac igrac){
        if(igraci.isEmpty())
            igrac.setPozicija(1);
        for(Igrac i : igraci){
            if(i.getProcenat() == igrac.getProcenat())
                igrac.setPozicija(i.getPozicija());
            else if (i.getProcenat() < igrac.getProcenat()){

            }
        }
    }



}


