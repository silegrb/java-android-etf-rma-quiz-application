package com.example.rma19feraget16110.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.rma19feraget16110.Model.Kategorija;
import com.example.rma19feraget16110.Model.Kviz;
import com.example.rma19feraget16110.Model.Pitanje;

import java.util.ArrayList;

public class RMADatabse extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "rmaSpirala2019.db";
    private static final int DATABSE_VERSION = 1;
    private static final String TABLE_KATEGORIJE = "kategorije";
    private static final String TABLE_PITANJA = "pitanja";
    private static final String TABLE_ODGOVORI = "odgovori";
    private static final String TABLE_KVIZOVI = "kvizovi";
    private static final String TABLE_KVIZOVI_PITANJA = "kvizovi_pitanja";
    private static final String KATEGORIJA_ID = "id";
    private static final String KATEGORIJA_NAZIV = "naziv";
    private static final String KATEGORIJA_ID_IKONICE = "id_ikonice";
    private static final String PITANJE_ID_LOCAL = "local_id";
    private static final String PITANJE_TACAN_ODGOVOR = "tacan_odgovor";
    private static final String PITANJE_NAZIV = "naziv";
    private static final String PITANJE_ID_PITANJE = "id_pitanja";
    private static final String ODGOVOR_ID_PITANJE = "id_pitanja";
    private static final String ODGOVOR_NAZIV = "naziv";
    private static final String KVIZ_NAZIV = "naziv";
    private static final String KVIZ_ID_KATEGORIJE = "id_kategorije";
    private static final String ID_KVIZA = "id_kviza";


    public static final String CREATE_TABLE_KATEGORIJE = "CREATE TABLE "
            + TABLE_KATEGORIJE + "(" + KATEGORIJA_ID
            + " TEXT," + KATEGORIJA_NAZIV
            + " TEXT," + KATEGORIJA_ID_IKONICE + " TEXT);";

    public static final String CREATE_TABLE_ODGOVORI = "CREATE TABLE "
            + TABLE_ODGOVORI + "(" + ODGOVOR_ID_PITANJE
            + " TEXT," + ODGOVOR_NAZIV + " TEXT);";

    public static final String CREATE_TABLE_PITANJA = "CREATE TABLE "
            + TABLE_PITANJA + "(" + PITANJE_ID_LOCAL
            + " INTEGER PRIMARY KEY AUTOINCREMENT," + PITANJE_ID_PITANJE
            + " TEXT," + PITANJE_TACAN_ODGOVOR + " TEXT,"
            + PITANJE_NAZIV + " TEXT,"
            + ID_KVIZA + " TEXT);";

    public static final String CREATE_TABLE_KVIZOVI = "CREATE TABLE "
            + TABLE_KVIZOVI + "(" + ID_KVIZA + " TEXT,"
            + KVIZ_ID_KATEGORIJE
            + " TEXT," + KVIZ_NAZIV + " TEXT);";

    public static final String CREATE_TABLE_KVIZOVI_PITANJA = "CREATE TABLE "
            + TABLE_KVIZOVI_PITANJA + "(" + ID_KVIZA + " TEXT,"
            + PITANJE_ID_PITANJE
            + " TEXT);";

    /*public static final String CREATE_TABLE_PITANJA_KVIZ = "CREATE TABLE "
            + TABLE_PITANJA_KVIZ + "(" + ID_KVIZA
            + "TEXT," + ID_PITANJA + "TEXT);";*/


    public RMADatabse(Context context) {
        super(context,DATABASE_NAME,null, DATABSE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_KATEGORIJE);
        db.execSQL(CREATE_TABLE_KVIZOVI);
        db.execSQL(CREATE_TABLE_ODGOVORI);
        db.execSQL(CREATE_TABLE_PITANJA);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS '" + TABLE_PITANJA + "'");
        db.execSQL("DROP TABLE IF EXISTS '" + TABLE_KVIZOVI + "'");
        db.execSQL("DROP TABLE IF EXISTS '" + TABLE_ODGOVORI + "'");
        db.execSQL("DROP TABLE IF EXISTS '" + TABLE_KATEGORIJE + "'");
        onCreate(db);
    }

    public void addCategory(Kategorija kategorija){
        if(!checkIfCategoryExist(kategorija.getNaziv()) && !kategorija.getNaziv().equals("Dodaj Kategoriju")){
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(KATEGORIJA_ID,kategorija.getDatabaseId());
            values.put(KATEGORIJA_ID_IKONICE,kategorija.getId());
            values.put(KATEGORIJA_NAZIV,kategorija.getNaziv());
            long id=db.insertWithOnConflict(TABLE_KATEGORIJE,null,values,SQLiteDatabase.CONFLICT_REPLACE);
            Log.d("categoryID",String.valueOf(id));
        }
    }

    public void deleteCategory(String id){
        SQLiteDatabase db=this.getWritableDatabase();
        db.delete(TABLE_KATEGORIJE,KATEGORIJA_ID + "=?",new String[]{id});
    }

    public ArrayList<Kategorija> getAllCategory(){
        ArrayList<Kategorija> localCategories = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_KATEGORIJE;
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor c = database.rawQuery(selectQuery,null);
        if(c.moveToFirst()){
            do {
                String nazivKategorije = c.getString(c.getColumnIndex(KATEGORIJA_NAZIV));
                String idIkonice = c.getString(c.getColumnIndex(KATEGORIJA_ID_IKONICE));
                String firebaseId = c.getString(c.getColumnIndex(KATEGORIJA_ID));
                Kategorija kategorija = new Kategorija(nazivKategorije,idIkonice);
                kategorija.setDatabaseId(firebaseId);
                localCategories.add(kategorija);
            }while(c.moveToNext());
        }
        c.close();
        return localCategories;
    }

    public Kategorija getCategoryById(String categoryId){
        Kategorija kategorija = null;
        String[] projections = {KATEGORIJA_ID,KATEGORIJA_NAZIV,KATEGORIJA_ID_IKONICE};
        String selection = KATEGORIJA_ID + " LIKE ?";
        String[] selection_args = {categoryId};
        //String selectQuery = "SELECT * FROM " + TABLE_KATEGORIJE + " WHERE " + KATEGORIJA_ID +" = " + categoryId;
        SQLiteDatabase db = this.getWritableDatabase();
        //Cursor c= db.rawQuery(selectQuery,new String[]{categoryId});
        Cursor c =  db.query(TABLE_KATEGORIJE,projections,selection,selection_args,null,null,null);
        if(c.moveToFirst()){
            do {
                String idKategorije = c.getString(c.getColumnIndex(KATEGORIJA_ID));
                String nazivKategorije = c.getString(c.getColumnIndex(KATEGORIJA_NAZIV));
                String idIkonice = c.getString(c.getColumnIndex(KATEGORIJA_ID_IKONICE));
                kategorija = new Kategorija(nazivKategorije,idIkonice);
                kategorija.setDatabaseId(idKategorije);
            }while (c.moveToNext());
        }
        c.close();
        db.close();
        return kategorija;
    }

    public Kategorija getCategoryByName(String categoryName){
        Kategorija kategorija = null;
        String[] projections = {KATEGORIJA_ID,KATEGORIJA_NAZIV,KATEGORIJA_ID_IKONICE};
        String selection = KATEGORIJA_NAZIV + " LIKE ?";
        String[] selection_args = {categoryName};
        //String selectQuery = "SELECT * FROM " + TABLE_KATEGORIJE + " WHERE " + KATEGORIJA_ID +" = " + categoryId;
        SQLiteDatabase db = this.getWritableDatabase();
        //Cursor c= db.rawQuery(selectQuery,new String[]{categoryId});
        Cursor c =  db.query(TABLE_KATEGORIJE,projections,selection,selection_args,null,null,null);
        if(c.moveToFirst()){
            do {
                String idKategorije = c.getString(c.getColumnIndex(KATEGORIJA_ID));
                String nazivKategorije = c.getString(c.getColumnIndex(KATEGORIJA_NAZIV));
                String idIkonice = c.getString(c.getColumnIndex(KATEGORIJA_ID_IKONICE));
                kategorija = new Kategorija(nazivKategorije,idIkonice);
                kategorija.setDatabaseId(idKategorije);
            }while (c.moveToNext());
        }
        c.close();
        db.close();
        return kategorija;
    }

    public boolean checkIfCategoryExist(String name){
        String[] projections = {KATEGORIJA_ID,KATEGORIJA_NAZIV,KATEGORIJA_ID_IKONICE};
        String selection = KATEGORIJA_NAZIV + " LIKE ?";
        String[] selection_args = {name};
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor pitanje = database.query(TABLE_KATEGORIJE,projections,selection,selection_args,null,null,null);
        if(pitanje.getCount() <= 0){
            pitanje.close();
            return false;
        }
        return true;
    }

    public void addQuestion(Pitanje pitanje,String quizId){
        if(!checkIfQuestionExist(pitanje.getNaziv()) && !pitanje.getNaziv().equals("Dodaj pitanje")){
            SQLiteDatabase database =this.getWritableDatabase();
            ContentValues valuesPitanja= new ContentValues();
            valuesPitanja.put(PITANJE_ID_PITANJE,pitanje.getDatabaseId());
            valuesPitanja.put(PITANJE_TACAN_ODGOVOR,pitanje.getTacan());
            valuesPitanja.put(PITANJE_NAZIV,pitanje.getTekstPitanja());
            valuesPitanja.put(ID_KVIZA,quizId);
            for(String odgovor : pitanje.getOdgovori()){
                ContentValues valuesOdgovori = new ContentValues();
                valuesOdgovori.put(ODGOVOR_ID_PITANJE,pitanje.getDatabaseId());
                valuesOdgovori.put(ODGOVOR_NAZIV,odgovor);
                database.insert(TABLE_ODGOVORI,null,valuesOdgovori);
            }
            database.insert(TABLE_PITANJA,null,valuesPitanja);
        }
    }

    public void deleteQuestion(String questionId){
        SQLiteDatabase db=this.getWritableDatabase();
        db.delete(TABLE_ODGOVORI,ODGOVOR_ID_PITANJE + "=?",new String[]{questionId});
        db.delete(TABLE_PITANJA,PITANJE_ID_PITANJE + "=?",new String[]{questionId});
    }

    public ArrayList<Pitanje> getAllQuestions(){
        ArrayList<Pitanje> pitanja = new ArrayList<>();
        String firebaseId = "";
        String selectQuery = "SELECT * FROM " + TABLE_PITANJA;
        SQLiteDatabase database = this.getWritableDatabase();
        String[] projections = {ODGOVOR_ID_PITANJE,ODGOVOR_NAZIV};
        String selection = ODGOVOR_ID_PITANJE + " LIKE ?";
        String[] selection_args = {firebaseId};
        Cursor pitanje = database.rawQuery(selectQuery,null);{
            if(pitanje.moveToFirst()){
                do {
                    String tacanOdgovor = pitanje.getString(pitanje.getColumnIndex(PITANJE_TACAN_ODGOVOR));
                    String naziv = pitanje.getString(pitanje.getColumnIndex(PITANJE_NAZIV));
                    firebaseId = pitanje.getString(pitanje.getColumnIndex(PITANJE_ID_PITANJE));
                    String firebaseIdKviza = pitanje.getString(pitanje.getColumnIndex(ID_KVIZA));
                    Cursor odgovorCursor = database.query(TABLE_ODGOVORI,projections,selection,selection_args,null,null,null);
                    ArrayList<String> odgovori = new ArrayList<>();
                    if(odgovorCursor.moveToFirst()){
                        do {
                            String odgovor = odgovorCursor.getString(odgovorCursor.getColumnIndex(ODGOVOR_NAZIV));
                            odgovori.add(odgovor);
                        }while (odgovorCursor.moveToNext());
                    }
                    odgovorCursor.close();
                    Pitanje p = new Pitanje(naziv,naziv,tacanOdgovor,odgovori,firebaseId);
                    p.setKvizDatabseId(firebaseIdKviza);
                    pitanja.add(p);
                }while (pitanje.moveToNext());
            }
            pitanje.close();
        }
        return pitanja;
    }

    public ArrayList<String> getOdgovoriById(String id){
        ArrayList<String> odgovori = new ArrayList<>();
        String[] projections = {ODGOVOR_ID_PITANJE,ODGOVOR_NAZIV};
        String selection = ODGOVOR_ID_PITANJE + " LIKE ?";
        String[] selection_args = {id};
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor odgovorCursor = database.query(TABLE_ODGOVORI,projections,selection,selection_args,null,null,null);
        if(odgovorCursor.moveToFirst()){
            do {
                String odgovor = odgovorCursor.getString(odgovorCursor.getColumnIndex(ODGOVOR_NAZIV));
                odgovori.add(odgovor);
            }while (odgovorCursor.moveToNext());
        }
        odgovorCursor.close();
        return odgovori;
    }

    public ArrayList<Pitanje> getQuestionById(String questionId){
        ArrayList<Pitanje> pitanja = new ArrayList<>();
        String[] projections = {PITANJE_ID_LOCAL,PITANJE_ID_PITANJE,PITANJE_TACAN_ODGOVOR,PITANJE_NAZIV,ID_KVIZA};
        String selection = PITANJE_ID_PITANJE + " LIKE ?";
        String[] selection_args = {questionId};
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor pitanje = database.query(TABLE_PITANJA,projections,selection,selection_args,null,null,null);
                if(pitanje.moveToFirst()){
                do {
                    String firebaseId = pitanje.getString(pitanje.getColumnIndex(PITANJE_ID_PITANJE));
                    String tacanOdgovor = pitanje.getString(pitanje.getColumnIndex(PITANJE_TACAN_ODGOVOR));
                    String naziv = pitanje.getString(pitanje.getColumnIndex(PITANJE_NAZIV));
                    String id_kviza = pitanje.getString(pitanje.getColumnIndex(ID_KVIZA));
                    ArrayList<String> odgovori;
                    odgovori = getOdgovoriById(firebaseId);
                    Pitanje p = new Pitanje(naziv,naziv,tacanOdgovor,odgovori,firebaseId);
                    p.setKvizDatabseId(id_kviza);
                    pitanja.add(p);
                }while (pitanje.moveToNext());
            }
            pitanje.close();
        return pitanja;
    }

    public boolean checkIfQuestionExist(String name){
        String[] projections = {PITANJE_ID_LOCAL,PITANJE_ID_PITANJE,PITANJE_TACAN_ODGOVOR,PITANJE_NAZIV,ID_KVIZA};
        String selection = PITANJE_NAZIV + " LIKE ?";
        String[] selection_args = {name};
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor pitanje = database.query(TABLE_PITANJA,projections,selection,selection_args,null,null,null);
        if(pitanje.getCount() <= 0){
            pitanje.close();
            return false;
        }
        return true;
    }

    public ArrayList<Pitanje> getQuestionByQuizId(String quizId){
        ArrayList<Pitanje> pitanja = new ArrayList<>();
        String[] projections = {PITANJE_ID_LOCAL,PITANJE_ID_PITANJE,PITANJE_TACAN_ODGOVOR,PITANJE_NAZIV,ID_KVIZA};
        String selection = ID_KVIZA + " LIKE ?";
        String[] selection_args = {quizId};
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor pitanje = database.query(TABLE_PITANJA,projections,selection,selection_args,null,null,null);{
            if(pitanje.moveToFirst()){
                do {
                    String firebaseId = pitanje.getString(pitanje.getColumnIndex(PITANJE_ID_PITANJE));
                    String tacanOdgovor = pitanje.getString(pitanje.getColumnIndex(PITANJE_TACAN_ODGOVOR));
                    String naziv = pitanje.getString(pitanje.getColumnIndex(PITANJE_NAZIV));
                    String id_kviza = pitanje.getString(pitanje.getColumnIndex(ID_KVIZA));
                    ArrayList<String> odgovori;
                    odgovori = getOdgovoriById(firebaseId);
                    Pitanje p = new Pitanje(naziv,naziv,tacanOdgovor,odgovori,firebaseId);
                    p.setKvizDatabseId(id_kviza);
                    pitanja.add(p);
                }while (pitanje.moveToNext());
            }
            pitanje.close();
        }
        return pitanja;
    }


    public void addQuiz (Kviz kviz){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues valuesQuiz = new ContentValues();
        valuesQuiz.put(ID_KVIZA,kviz.getIdUBazi());
        valuesQuiz.put(KVIZ_ID_KATEGORIJE,kviz.getKategorija().getDatabaseId());
        valuesQuiz.put(KVIZ_NAZIV,kviz.getNaziv());
        for(Pitanje p : kviz.getPitanja()){
            if(!checkIfQuestionExist(p.getNaziv()))
                addQuestion(p,kviz.getIdUBazi());
        }
        if(!checkIfCategoryExist(kviz.getKategorija().getNaziv()))
            addCategory(kviz.getKategorija());
        db.insert(TABLE_KVIZOVI,null,valuesQuiz);
    }

    public void deleteQuiz(Kviz kviz){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ID_KVIZA,"");
        db.update(TABLE_PITANJA,values,ID_KVIZA + "=?",new String[]{kviz.getIdUBazi()});
        for (Pitanje p : kviz.getPitanja()){
            db.delete(TABLE_ODGOVORI,ODGOVOR_ID_PITANJE + "=?",new String[]{p.getDatabaseId()});
        }
        db.delete(TABLE_KVIZOVI,ID_KVIZA + "=?",new String[]{kviz.getIdUBazi()});
    }

    public void editQuiz(Kviz kviz){
        Boolean exist = true;
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KVIZ_NAZIV,kviz.getNaziv());
        values.put(KVIZ_ID_KATEGORIJE,kviz.getKategorija().getDatabaseId());
        database.update(TABLE_KVIZOVI,values,ID_KVIZA + "=?",new String[]{kviz.getIdUBazi()});
        ArrayList<Pitanje> kvizPitanja = getQuestionByQuizId(kviz.getIdUBazi());
        for(Pitanje p : kvizPitanja){
            for(Pitanje p1 : kviz.getPitanja()){
                if(!p1.equals(p))
                    exist = false;
            }
            if(!exist){
                ContentValues pitanje = new ContentValues();
                pitanje.put(ID_KVIZA,"");
                database.update(TABLE_PITANJA,pitanje,ID_KVIZA + "=?",new String[]{kviz.getIdUBazi()});
            }
        }
        exist = false;
        for (Pitanje p : kviz.getPitanja()){
            for (Pitanje p1 : kvizPitanja){
                if(p.equals(p1))
                    exist = true;
            }
            if(!exist){
               addQuestion(p,kviz.getIdUBazi());
            }
        }
    }

    public ArrayList<Kviz> getAllQuizes(){
        ArrayList<Kviz> kvizovi = new ArrayList<>();
        String[] projections = new String[]{ID_KVIZA,KVIZ_ID_KATEGORIJE,KVIZ_NAZIV};
        //String selectQuery = "SELECT * FROM " + TABLE_KVIZOVI;
        SQLiteDatabase database = this.getWritableDatabase();
       //Cursor quizCursor = database.rawQuery(selectQuery,null);
        Cursor quizCursor = database.query(TABLE_KVIZOVI,projections,null,null,null,null,null);
        if(quizCursor.moveToFirst()){
            do {
                Kviz kviz = null;
                String categoryId = quizCursor.getString(quizCursor.getColumnIndex(KVIZ_ID_KATEGORIJE));
                Kategorija kategorija = getCategoryById(categoryId);
                String idKviza = quizCursor.getString(quizCursor.getColumnIndex(ID_KVIZA));
                String nazivKviza = quizCursor.getString(quizCursor.getColumnIndex(KVIZ_NAZIV));
                kviz = new Kviz(nazivKviza,idKviza);
                kviz.setKategorija(kategorija);
                kviz.setPitanja(getQuestionByQuizId(idKviza));
                kvizovi.add(kviz);
            }while (quizCursor.moveToNext());
        }
        quizCursor.close();
        return kvizovi;
    }

    public ArrayList<Kviz> getQuizByCategory(String categoryId){
        ArrayList<Kviz> kvizovi = new ArrayList<>();
        String[] projections = new String[]{ID_KVIZA,KVIZ_ID_KATEGORIJE,KVIZ_NAZIV};
        String selection = KVIZ_ID_KATEGORIJE + " LIKE ?";
        String[] selection_args = {categoryId};
        //String selectQuery = "SELECT * FROM " + TABLE_KVIZOVI + " WHERE " + KVIZ_ID_KATEGORIJE + " = " + categoryId;
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor quizCursor = database.query(TABLE_KVIZOVI,projections,selection,selection_args,null,null,null);
        if(quizCursor.moveToFirst()){
            do {
                Kviz kviz;
                Kategorija kategorija = getCategoryById(categoryId);
                String idKviza = quizCursor.getString(quizCursor.getColumnIndex(ID_KVIZA));
                String nazivKviza = quizCursor.getString(quizCursor.getColumnIndex(KVIZ_NAZIV));
                kviz = new Kviz(nazivKviza,idKviza);
                kviz.setKategorija(kategorija);
                kviz.setPitanja(getQuestionByQuizId(idKviza));
                kvizovi.add(kviz);
            }while (quizCursor.moveToNext());
        }
        quizCursor.close();
        return kvizovi;
    }

    public ArrayList<Kviz> getQuizByCategoryName(String categoryName){
        Kategorija k = getCategoryByName(categoryName);
        String categoryId = k.getDatabaseId();
        ArrayList<Kviz> kvizovi = new ArrayList<>();
        String[] projections = new String[]{ID_KVIZA,KVIZ_ID_KATEGORIJE,KVIZ_NAZIV};
        String selection = KVIZ_ID_KATEGORIJE + " LIKE ?";
        String[] selection_args = {categoryId};
        //String selectQuery = "SELECT * FROM " + TABLE_KVIZOVI + " WHERE " + KVIZ_ID_KATEGORIJE + " = " + categoryId;
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor quizCursor = database.query(TABLE_KVIZOVI,projections,selection,selection_args,null,null,null);
        if(quizCursor.moveToFirst()){
            do {
                Kviz kviz;
                Kategorija kategorija = getCategoryById(categoryId);
                String idKviza = quizCursor.getString(quizCursor.getColumnIndex(ID_KVIZA));
                String nazivKviza = quizCursor.getString(quizCursor.getColumnIndex(KVIZ_NAZIV));
                kviz = new Kviz(nazivKviza,idKviza);
                kviz.setKategorija(kategorija);
                kviz.setPitanja(getQuestionByQuizId(idKviza));
                kvizovi.add(kviz);
            }while (quizCursor.moveToNext());
        }
        quizCursor.close();
        return kvizovi;
    }

    @Override
    public String toString() {
        SQLiteDatabase db=this.getWritableDatabase();
        return db.toString();
    }

    public ArrayList<Cursor> getData(String Query){
        //get writable database
        SQLiteDatabase sqlDB = this.getWritableDatabase();
        String[] columns = new String[] { "message" };
        //an array list of cursor to save two cursors one has results from the query
        //other cursor stores error message if any errors are triggered
        ArrayList<Cursor> alc = new ArrayList<Cursor>(2);
        MatrixCursor Cursor2= new MatrixCursor(columns);
        alc.add(null);
        alc.add(null);

        try{
            String maxQuery = Query ;
            //execute the query results will be save in Cursor c
            Cursor c = sqlDB.rawQuery(maxQuery, null);

            //add value to cursor2
            Cursor2.addRow(new Object[] { "Success" });

            alc.set(1,Cursor2);
            if (null != c && c.getCount() > 0) {

                alc.set(0,c);
                c.moveToFirst();

                return alc ;
            }
            return alc;
        } catch(SQLException sqlEx){
            Log.d("printing exception", sqlEx.getMessage());
            //if any exceptions are triggered save the error message to cursor an return the arraylist
            Cursor2.addRow(new Object[] { ""+sqlEx.getMessage() });
            alc.set(1,Cursor2);
            return alc;
        } catch(Exception ex){
            Log.d("printing exception", ex.getMessage());

            //if any exceptions are triggered save the error message to cursor an return the arraylist
            Cursor2.addRow(new Object[] { ""+ex.getMessage() });
            alc.set(1,Cursor2);
            return alc;
        }
    }

}
