package com.example.rma19feraget16110.Services;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.example.rma19feraget16110.Model.Igrac;
import com.example.rma19feraget16110.Model.Ranglista;
import com.example.rma19feraget16110.R;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

public class SaveRangliste extends AsyncTask<String,Integer,Void> {
    private Context mContext;
    private String kolekcija,token,id;
    private Ranglista ranglista;
    private String document = "";

    @Override
    protected Void doInBackground(String... strings) {
        kolekcija = strings[0];
        try {
            token = getToken();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Log.d("token",token);

        try {
            String url = "https://firestore.googleapis.com/v1/projects/spirala3-67197/databases/(default)/documents/" + kolekcija + "?access_token=";
            URL urlObj = new URL(url + URLEncoder.encode(token,"UTF-8"));
            HttpURLConnection httpURLConnection = (HttpURLConnection) urlObj.openConnection();
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setRequestProperty("Content-Type", "application/json");
            httpURLConnection.setRequestProperty("Accept", "application/json");
            try (OutputStream os = httpURLConnection.getOutputStream()) {
                byte[] input = document.getBytes("utf-8");
                os.write(input, 0, input.length);
            }
            int code = httpURLConnection.getResponseCode();
            InputStream odgovor = httpURLConnection.getInputStream();
            try (BufferedReader br = new BufferedReader(
                    new InputStreamReader(odgovor, "utf-8"))){
                StringBuilder response = new StringBuilder();
                String responseLine = null;
                while((responseLine = br.readLine()) != null){
                    response.append(responseLine.trim());
                }
                String[] temp = response.toString().split("/");
                id = temp[6].substring(0,20);
                Log.d("ODGOVOR",response.toString());
                Log.d("CODE",String.valueOf(code));
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private String getToken() throws IOException {
        InputStream is = mContext.getApplicationContext().getResources().openRawResource(R.raw.secret);
        GoogleCredential credential = GoogleCredential.fromStream(is).
                createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
        credential.refreshToken();
        return credential.getAccessToken();
    }


    public SaveRangliste(Context context, Ranglista ranglista){
        mContext = context;
        this.ranglista = ranglista;
        createRanglistu(ranglista);
    }


    public String createRanglistu(Ranglista ranglista){
        document += "{\"fields\": {\"nazivKviza\": {\"stringValue\": \"" + ranglista.getNazivKviza() + "\"},\"lista\": {\"mapValue\":{ \"fields\":{";
        ArrayList<Igrac> igraci = ranglista.getIgrac();
        for (int i = 0; i<ranglista.getIgrac().size() ; i++){
            int pozicija = igraci.get(i).getPozicija();
            document += "\"" + pozicija + "\": {\"mapValue\": {\"fields\": {";
            while(i<igraci.size() && igraci.get(i).getPozicija() == pozicija){
                document += "\"" + igraci.get(i).getImeIgraca() + "\": {\"stringValue\": \"" + igraci.get(i).getProcenat() + "\"},";
                i++;
            }
            document = document.substring(0,document.length() - 1);
            i--;
            document += "}}},";
        }
        document = document.substring(0,document.length() - 1);
        document +="}}}}}";
        return document;
    }
}
