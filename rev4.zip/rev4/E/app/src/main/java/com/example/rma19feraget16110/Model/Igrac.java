package com.example.rma19feraget16110.Model;

import java.io.Serializable;

public class Igrac implements Serializable,Comparable {
    private Integer pozicija;
    private String imeIgraca = "";
    private double procenat;

    public Igrac(Integer pozicija, String imeIgraca, double procenat) {
        this.pozicija = pozicija;
        this.imeIgraca = imeIgraca;
        this.procenat = procenat;
    }

    public Integer getPozicija() {
        return pozicija;
    }

    public void setPozicija(Integer pozicija) {
        this.pozicija = pozicija;
    }

    public String getImeIgraca() {
        return imeIgraca;
    }

    public void setImeIgraca(String imeIgraca) {
        this.imeIgraca = imeIgraca;
    }

    public double getProcenat() {
        return procenat;
    }

    public void setProcenat(double procenat) {
        this.procenat = procenat;
    }


    @Override
    public int compareTo(Object o) {
        int comparePozition = ((Igrac)o).getPozicija();
        return this.pozicija-comparePozition;
    }
}
