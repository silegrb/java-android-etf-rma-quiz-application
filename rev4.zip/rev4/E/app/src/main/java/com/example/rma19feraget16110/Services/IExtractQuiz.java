package com.example.rma19feraget16110.Services;

import com.example.rma19feraget16110.Model.Kviz;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public interface IExtractQuiz {
    ArrayList<Kviz> extractQuizes(JSONObject quizes) throws JSONException;
}
