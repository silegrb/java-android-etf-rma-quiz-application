package com.example.rma19feraget16110.Services;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.example.rma19feraget16110.Model.Kategorija;
import com.example.rma19feraget16110.Model.Kviz;
import com.example.rma19feraget16110.Model.Pitanje;
import com.example.rma19feraget16110.R;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class EditData extends AsyncTask<String,Integer,Void> {
    private Context mContext;
    Object object;
    //private OnDoneKvizovi pozivatelj;
    String token,kolekcija,documentId;
    String document ="";
    Kviz kviz;
    Pitanje pitanje;
    Kategorija kat;
    @Override
    protected Void doInBackground(String... strings) {
        kolekcija = strings[0];
        //String nazivKategorije = ((Kategorija) object).getNaziv();
        ///String idIkonice = ((Kategorija) object).getId();
        try {
            token = getToken();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Log.d("token",token);


        try {
            String url = "https://firestore.googleapis.com/v1/projects/spirala3-67197/databases/(default)/documents/" + kolekcija + "/" + documentId +  "?access_token=";
            URL urlObj = new URL(url + URLEncoder.encode(token,"UTF-8"));
            HttpURLConnection httpURLConnection = (HttpURLConnection) urlObj.openConnection();
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setRequestMethod("PATCH");
            httpURLConnection.setRequestProperty("Content-Type", "application/json");
            httpURLConnection.setRequestProperty("Accept", "application/json");
            try (OutputStream os = httpURLConnection.getOutputStream()) {
                byte[] input = document.getBytes("utf-8");
                os.write(input, 0, input.length);
            }
            int code = httpURLConnection.getResponseCode();
            InputStream odgovor = httpURLConnection.getInputStream();
            try (BufferedReader br = new BufferedReader(
                    new InputStreamReader(odgovor, "utf-8"))){
                StringBuilder response = new StringBuilder();
                String responseLine = null;
                while((responseLine = br.readLine()) != null){
                    response.append(responseLine.trim());
                }
                Log.d("ODGOVOR",response.toString());
                Log.d("CODE",String.valueOf(code));
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private String getToken() throws IOException {
        InputStream is = mContext.getApplicationContext().getResources().openRawResource(R.raw.secret);
        GoogleCredential credential = GoogleCredential.fromStream(is).
                createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
        credential.refreshToken();
        return credential.getAccessToken();
    }


/*public interface OnDoneKvizovi{
        void onDoneKvizovi(String rez);
}*/

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        //pozivatelj.onDoneKvizovi(rezultat);
    }

    public EditData(Context context, Object o,String documentId){
        //pozivatelj = p;
        this.documentId = documentId;
        mContext = context;
        if(o instanceof Kategorija){
            createCategory(o);
        }
        else if(o instanceof Kviz){
            createQuiz(o);
        }
        else if(o instanceof Pitanje){
            createQuestion(o);
        }
    }

    public void createCategory(Object object){
        kat = ((Kategorija) object);
        //String dokument = "{ \"fields\": { \"naziv\": {\"stringValue\":\"" + nazivKategorije + "\"}, \"idIkonice\": {\"stringValue\":  \""+ idIkonice + "\"}}}";
        document += "{ \"fields\": {\"naziv\": {\"stringValue\":\"" + kat.getNaziv() + "\"}, \"idIkonice\": {\"stringValue\": \""
                + kat.getId()+ "\"";
        document += "}}}";
    }

    public void createQuestion(Object object){
        pitanje = ((Pitanje) object);
        document += "{\"fields\": {\"naziv\": {\"stringValue\": \"" + pitanje.getNaziv() + "\"}, \"indexTacnog\": {\"integerValue\": \""
                + pitanje.getNumberOfTrueAnswer(pitanje) + "\"}, \"odgovori\": {\"arrayValue\": {\"values\": [";
        for(int i = 0;i< pitanje.getOdgovori().size() ; i++){
            document += "{\"stringValue\": \"" + pitanje.getOdgovori().get(i) + "\"}";
            if(i != pitanje.getOdgovori().size()-1) document += ",";
        }
        document += "]}}}}";
    }

    public void createQuiz(Object object){
        kviz= ((Kviz) object);
        document += "{\"fields\": {\"naziv\": {\"stringValue\": \"" + kviz.getNaziv() + "\"}, \"idKategorije\": {\"stringValue\": \""
                + kviz.getKategorija().getDatabaseId() + "\"}, \"pitanja\": {\"arrayValue\": {\"values\": [";
        for(int i = 0;i< kviz.getPitanja().size() ; i++){
            Pitanje p = kviz.getPitanja().get(i);
            document += "{\"stringValue\": \"" + p.getDatabaseId() + "\"}";
            if(i != kviz.getPitanja().size()-1) document += ",";
        }
        document += "]}}}}";
    }

}
