package com.example.rma19feraget16110;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.example.rma19feraget16110.Adapters.OdgovoriAdapter;
import com.example.rma19feraget16110.Model.Kviz;
import com.example.rma19feraget16110.Model.Pitanje;
import com.example.rma19feraget16110.Validation.ValidatorClass;

import java.util.ArrayList;

public class DodajPitanjeAkt extends AppCompatActivity {
    ValidatorClass validatorClass=new ValidatorClass();
    ArrayList<Pitanje> pitanja=new ArrayList<>();
    ArrayList<String> moguciOdgovori=new ArrayList<>();
    EditText nazivPitanja,odgovor,tekstPitanja;
    ListView listaOdgvovora;
    Button dodajOdgovor,dodajTacanOdgvovor,spasiPitanje;
    OdgovoriAdapter odgovoriAdapter;
    Kviz kviz;
    String tacan;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_pitanje_akt);
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        Intent i=getIntent();
        Bundle b=i.getExtras();
        kviz=(Kviz)b.getSerializable("kviz");
        pitanja=kviz.getPitanja();
        nazivPitanja=findViewById(R.id.etNaziv);
        odgovor=findViewById(R.id.etOdgovori);
        listaOdgvovora=findViewById(R.id.lvOdgovori);
        dodajOdgovor=findViewById(R.id.btnDodajOdgovor);
        dodajTacanOdgvovor=findViewById(R.id.btnDodajTacan);
        spasiPitanje=findViewById(R.id.btnDodajPitanje);
        tekstPitanja=findViewById(R.id.etTekstPitanja);
        //nazivPitanja.setText(kviz.getPitanja().get(0).getNaziv());
        odgovoriAdapter=new OdgovoriAdapter(this,R.layout.pitanja_kviz,moguciOdgovori);
        listaOdgvovora.setAdapter(odgovoriAdapter);


        dodajOdgovor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!validatorClass.validateField(odgovor)){
                    String temp=odgovor.getText().toString();
                    moguciOdgovori.add(temp);
                    odgovoriAdapter.notifyDataSetChanged();
                    odgovor.getBackground().setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_ATOP);
                } else
                    odgovor.getBackground().setColorFilter(Color.RED, PorterDuff.Mode.SRC_ATOP);


            }
        });
        dodajTacanOdgvovor.setOnClickListener(v -> {
            if(!validatorClass.validateField(odgovor)){
                tacan=odgovor.getText().toString();
                odgovor.setTextColor(Color.GREEN);
                odgovor.getBackground().setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_ATOP);
            } else
                odgovor.getBackground().setColorFilter(Color.RED, PorterDuff.Mode.SRC_ATOP);
        });

        spasiPitanje.setOnClickListener(v -> {
            String nazivPit = nazivPitanja.getText().toString();
            String tekstPit = tekstPitanja.getText().toString();
            Pitanje p=new Pitanje(nazivPit,tekstPit,tacan,moguciOdgovori);
            if(!validatorClass.validateField(nazivPitanja) && !validatorClass.validateField(tekstPitanja) && !uniqueNameOfQuestion(p.getNaziv())){
                Intent i1 =new Intent();
                i1.putExtra("pitanje",p);
                setResult(Activity.RESULT_OK, i1);
                finish();
            }

        });

        listaOdgvovora.setOnItemClickListener((parent, view, position, id) -> {
            AlertDialog.Builder adb=new AlertDialog.Builder(DodajPitanjeAkt.this);
            adb.setTitle("Delete");
            adb.setMessage("Are you sure you want to delete ");
            final int positionToRemove=position;
            adb.setNegativeButton("Cancel",null);
            adb.setPositiveButton("Ok", (dialog, which) -> {
                listaOdgvovora.invalidateViews();
                moguciOdgovori.remove(positionToRemove);
                odgovoriAdapter.notifyDataSetChanged();
            });
            adb.show();

        });
    }

    public boolean uniqueNameOfQuestion(String name){
        for (Pitanje p:pitanja) {
            if(p.getNaziv().toLowerCase().equals(name))
                return true;
        }
        return false;
    }
}
