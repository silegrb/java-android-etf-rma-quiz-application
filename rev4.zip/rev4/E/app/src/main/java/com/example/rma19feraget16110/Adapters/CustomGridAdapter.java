package com.example.rma19feraget16110.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.rma19feraget16110.Model.Kviz;
import com.example.rma19feraget16110.R;

import java.util.ArrayList;

public class CustomGridAdapter extends BaseAdapter {
    private Context mContext;
    private ArrayList<Kviz> mKvizovi;
    private ArrayList<Kviz> filteredData=new ArrayList<>();

    public CustomGridAdapter(Context context,ArrayList<Kviz> kvizovi){
        this.mContext=context;
        this.mKvizovi=kvizovi;
    }
    @Override
    public int getCount() {
        return mKvizovi.size();
    }

    @Override
    public Object getItem(int position) {
        return mKvizovi.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
       ViewHolder holder=new ViewHolder();
        if(convertView == null){
            LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView=inflater.inflate(R.layout.grid_elements,parent,false);
            holder.text =convertView.findViewById(R.id.tnazivKviza);
            holder.brojPitanja =convertView.findViewById(R.id.tbrojPitanja);
            convertView.setTag(holder);
        } else
            holder=(ViewHolder)convertView.getTag();
        holder.text.setText(mKvizovi.get(position).getNaziv());
        holder.brojPitanja.setText(String.valueOf(mKvizovi.get(position).getPitanja().size()));
        return convertView;
    }

    /*@Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                FilterResults results = new FilterResults();

                if(constraint == null || constraint.length() == 0){
                    results.values = mKvizovi;
                    results.count = mKvizovi.size();
                } else {
                    ArrayList<Kviz> filterResultData = new ArrayList<>();
                    for(Kviz data : mKvizovi){
                        if(data.getKategorija().getNaziv().toLowerCase().equals(constraint.toString().toLowerCase()))
                            filterResultData.add(data);
                    }
                    results.values = filterResultData;
                    results.count = filterResultData.size();
                }
                return results;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                filteredData = (ArrayList<Kviz>) results.values;
               // mKvizovi = (ArrayList<Kviz>) results.values;
                notifyDataSetChanged();
            }
        };
    }
*/


    static class ViewHolder{
        TextView text;
        TextView brojPitanja;
    }
}
