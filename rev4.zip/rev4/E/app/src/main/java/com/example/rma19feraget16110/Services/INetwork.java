package com.example.rma19feraget16110.Services;

public interface INetwork {
    boolean isNetworkAvailable();
}
