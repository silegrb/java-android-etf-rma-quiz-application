package com.example.rma19feraget16110.Fragments;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.Toast;

import com.example.rma19feraget16110.Adapters.CustomGridAdapter;
import com.example.rma19feraget16110.Model.Kategorija;
import com.example.rma19feraget16110.Model.Kviz;
import com.example.rma19feraget16110.Model.Pitanje;
import com.example.rma19feraget16110.R;
import com.example.rma19feraget16110.Services.GetQuiz;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class DetailFrag extends Fragment implements GetQuiz.ReturnQuizes{
    ArrayList<Kviz> kvizovi = new ArrayList<>();
    ArrayList<Kategorija> kategorije = new ArrayList<>();
    ArrayList<Pitanje> pitanja = new ArrayList<>();
    CustomGridAdapter gridAdapter;
    private SendQuiz mListener;
    //private SharedViewModel viewModel;
    GridView gridView;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View iv = inflater.inflate(R.layout.detail_frag,container,false);
        return iv;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        //if(getArguments() != null && getArguments().containsKey("kategorije") && getArguments().containsKey("kvizovi"))
            kvizovi = (ArrayList<Kviz>) getArguments().getSerializable("kvizovi");
        kategorije = (ArrayList<Kategorija>) getArguments().getSerializable("kategorije");
        pitanja = (ArrayList<Pitanje>) getArguments().getSerializable("pitanja");
        //viewModel = ViewModelProviders.of(getActivity()).get(SharedViewModel.class);
            gridView = getView().findViewById(R.id.gridKvizovi);
            gridAdapter = new CustomGridAdapter(getContext(), kvizovi);
            gridView.setAdapter(gridAdapter);
            gridView.setOnItemClickListener((parent, view, position, id) -> {
                Kviz quiz = (Kviz) parent.getItemAtPosition(position);
                mListener.onQuizSelected(quiz,position,kvizovi);
            });


            gridView.setOnItemLongClickListener((parent, view, position, id) -> {
                Kviz quiz = (Kviz) parent.getItemAtPosition(position);
                Toast.makeText(getContext(),quiz.getNaziv(),Toast.LENGTH_SHORT).show();
                mListener.onQuizLongSelected(quiz,position,kvizovi);
                return true;
            });

    }
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if(context instanceof SendQuiz){
            mListener = (SendQuiz) context;
        } else {
            throw new RuntimeException(context.toString()
                    + "must implemet listener!");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public void showQuizes(Kategorija kategorija){
        new GetQuiz(getContext(),kategorija.getDatabaseId(), DetailFrag.this).execute("Kvizovi");
       /* if(constraint == null)
            gridAdapter.getFilter().filter(null);
        else
            gridAdapter.getFilter().filter(constraint);*/
    }

    @Override
    public void returnQuizes(JSONObject object) throws JSONException {
        String nazivKviza,idKategorije;
        ArrayList<Kviz> kvizoviDatabase = new ArrayList<>();
        Kategorija kategorija = null;
        JSONArray items = object.getJSONArray("documents");
        for(int i=0;i<items.length();i++){
            ArrayList<Pitanje> kvizPitanja = new ArrayList<>();
            ArrayList<String> idPitanja = new ArrayList<>();
            JSONObject item =items.getJSONObject(i);
            JSONObject document = item.getJSONObject("document");
            String name = document.getString("name");
            String[] temp = name.split("/");
            String quizId = temp[6];
            JSONObject fields = document.getJSONObject("fields");
            nazivKviza = fields.getJSONObject("naziv").getString("stringValue");
            idKategorije = fields.getJSONObject("idKategorije").getString("stringValue");
            JSONObject pitanja = fields.getJSONObject("pitanja").getJSONObject("arrayValue");
            JSONArray values = pitanja.getJSONArray("values");
            for(int j = 0;j<values.length() ; j++){
                JSONObject pitanje =values.getJSONObject(j);
                if(pitanje.getString("stringValue").length() != 0)
                    idPitanja.add(pitanje.getString("stringValue"));
            }
            kategorija = getCategoryFromId(idKategorije);
            for(String id : idPitanja)
                kvizPitanja.add(getQuestionFromId(id));
            Kviz kviz = new Kviz(nazivKviza,quizId);
            kviz.setKategorija(kategorija);
            kviz.setPitanja(kvizPitanja);
            kvizoviDatabase.add(kviz);
        }
        kvizovi = kvizoviDatabase;
        gridAdapter=new CustomGridAdapter(getContext(),kvizovi);
        gridView.setAdapter(gridAdapter);
    }

    public interface SendQuiz{
        void onQuizSelected(Kviz quiz, int position,ArrayList<Kviz> kvizovi);
        void onQuizLongSelected(Kviz quiz, int position,ArrayList<Kviz> kvizovi);
    }

    public Kategorija getCategoryFromId(String id){
        for (Kategorija k : kategorije){
            if(k.getDatabaseId().equals(id))
                return k;
        }
        return null;
    }

    public Pitanje getQuestionFromId(String id){
        for (Pitanje p : pitanja){
            if(p.getDatabaseId().equals(id))
                return p;
        }
        return null;
    }



}
