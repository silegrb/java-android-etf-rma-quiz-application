package com.example.rma19feraget16110;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.rma19feraget16110.Adapters.MogucaPitanjaAdapter;
import com.example.rma19feraget16110.Adapters.PitanjaAdapter;
import com.example.rma19feraget16110.Database.RMADatabse;
import com.example.rma19feraget16110.Model.Kategorija;
import com.example.rma19feraget16110.Model.Kviz;
import com.example.rma19feraget16110.Model.Pitanje;
import com.example.rma19feraget16110.Services.EditData;
import com.example.rma19feraget16110.Services.GetAllData;
import com.example.rma19feraget16110.Services.SaveData;
import com.example.rma19feraget16110.Validation.ValidatorClass;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import de.mxapplications.openfiledialog.OpenFileDialog;

public class DodajKvizAkt extends AppCompatActivity implements GetAllData.ReturnData,SaveData.OnDoneSaving{
    ValidatorClass validatorClass = new ValidatorClass();
    ArrayList<Kategorija> kategorije = new ArrayList<>();
    ArrayList<Pitanje> mogucaPitanja = new ArrayList<>();
    ArrayList<Kviz> SviKvizovi = new ArrayList<>();
    ArrayAdapter<Kategorija> spinerAdapter;
    private ListView lvDodanaPitanja, lvMogucaPitanja;
    private Spinner spKategorije;
    private EditText etNaziv;
    private Button dodajKviz, importujKviz;
    //private DatabaseReference mDatabase;
    Integer position;
    Kviz kviz;
    Kviz trenutni;
    ArrayList<Kviz> kvizovi = new ArrayList<>();
    PitanjaAdapter pitanjaAdapter;
    MogucaPitanjaAdapter mogucaPitanjaAdapter;
    int positionBefore;
    OpenFileDialog openFileDialog;
    String rezultat;
    Kviz importedKviz = new Kviz();
    Integer numerOfQuestions, numberOfAnswers, correctAnswer;
    Integer counter = 0;
    Integer temp = 0;
    Integer categoryPosition;
    RMADatabse databse;
    SQLiteDatabase db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kviz_akt);
        databse = new RMADatabse(this);
        //db =databse.getWritableDatabase();
        //databse.onUpgrade(db,1,1);
        ArrayList<Kviz> p = databse.getQuizByCategory("DHv1CZeCp59jXAm7XR6m");
        new GetAllData(getApplicationContext(),DodajKvizAkt.this).execute("Pitanja");
        new GetAllData(getApplicationContext(),DodajKvizAkt.this).execute("Kvizovi");
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        openFileDialog = new OpenFileDialog(this);
        Kategorija novaKategorija = new Kategorija("Dodaj Kategoriju", "0");
        Intent i = getIntent();
        Bundle b = i.getExtras();
        position = b.getInt("position");
        kvizovi = (ArrayList<Kviz>) b.getSerializable("kvizovi");
        //SviKvizovi = (ArrayList<Kviz>) b.getSerializable("SviKvizovi");
        categoryPosition = b.getInt("categoryPosition");
        kviz = kvizovi.get(position);
        if (!checkForQuestion("Dodaj pitanje"))
            kviz.getPitanja().add(new Pitanje("Dodaj pitanje", null, null, null));
        kategorije = (ArrayList<Kategorija>) b.getSerializable("kategorije");
        kategorije.add(novaKategorija);
        lvDodanaPitanja = findViewById(R.id.lvDodanaPitanja);
        lvMogucaPitanja = findViewById(R.id.lvMogucaPitanja);
        spKategorije = findViewById(R.id.spKategorije);
        etNaziv = findViewById(R.id.etNaziv);
        dodajKviz = findViewById(R.id.btnDodajKviz);
        importujKviz = findViewById(R.id.btnImportKviz);
        pitanjaAdapter = new PitanjaAdapter(this, R.layout.pitanja_kviz, kviz.getPitanja());
        lvDodanaPitanja.setAdapter(pitanjaAdapter);
        etNaziv.setText(kviz.getNaziv());
        if (etNaziv.getText().toString().toLowerCase().equals("dodaj kviz"))
            etNaziv.setText("");
        spinerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, kategorije);
        spinerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spKategorije.setAdapter(spinerAdapter);
        spKategorije.setSelection(categoryPosition);
        mogucaPitanjaAdapter = new MogucaPitanjaAdapter(this, R.layout.moguca_pitanja, mogucaPitanja);
        lvMogucaPitanja.setAdapter(mogucaPitanjaAdapter);
        spKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String nazivKat = parent.getItemAtPosition(position).toString();
                if (nazivKat.toLowerCase().equals("dodaj kategoriju") && isNetworkAvailable()) {
                    if (nazivKat.toLowerCase().equals("dodaj kategoriju")) {
                        Intent dodajKategoriju = new Intent(getApplicationContext(), DodajKategorijuAkt.class);
                        Bundle argumenti = new Bundle();
                        argumenti.putSerializable("kategorije", kategorije);
                        dodajKategoriju.putExtras(argumenti);
                        dodajKategoriju.setAction(Intent.ACTION_GET_CONTENT);
                        startActivityForResult(dodajKategoriju, 1);
                    }
                } else
                    Toast.makeText(getApplicationContext(),"No internet",Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        lvDodanaPitanja.setOnItemClickListener((parent, view, position, id) -> {
            String item = kviz.getPitanja().get(position).getNaziv();
            if(isNetworkAvailable()){
                if (item.toLowerCase().equals("dodaj pitanje")) {
                    Intent dodajPitanje = new Intent(getApplicationContext(), DodajPitanjeAkt.class);
                    Bundle argumenti = new Bundle();
                    argumenti.putSerializable("kviz", kviz);
                    dodajPitanje.putExtras(argumenti);
                    dodajPitanje.setAction(Intent.ACTION_GET_CONTENT);
                    startActivityForResult(dodajPitanje, 3);
                } else {
                    lvDodanaPitanja.invalidateViews();
                    lvMogucaPitanja.invalidateViews();
                    mogucaPitanja.add(0, kviz.getPitanja().get(position));
                    kviz.getPitanja().remove(position);
                    positionBefore = position;
                    mogucaPitanjaAdapter.notifyDataSetChanged();
                }
            } else
                Toast.makeText(getApplicationContext(),"No internet",Toast.LENGTH_SHORT).show();

        });

        importujKviz.setOnClickListener(view -> {
            Intent fileIntent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            fileIntent.addCategory(Intent.CATEGORY_OPENABLE);
            fileIntent.setType("text/*");
            startActivityForResult(fileIntent, 4);
        });

        lvMogucaPitanja.setOnItemClickListener((parent, view, position, id) -> {
            kviz.getPitanja().add(0, mogucaPitanja.get(position));
            pitanjaAdapter.notifyDataSetChanged();
            mogucaPitanja.remove(position);
            mogucaPitanjaAdapter.notifyDataSetChanged();
        });

        dodajKviz.setOnClickListener(v -> {
            String nazivKviza = etNaziv.getText().toString();
             trenutni = new Kviz(nazivKviza);
            if (!validatorClass.validateField(etNaziv)) {
                Kategorija kat = (Kategorija) spKategorije.getSelectedItem();
                trenutni.setKategorija(kat);
                trenutni.setIdUBazi(kviz.getIdUBazi());
                trenutni.setPitanja(kviz.getPitanja());
                //kviz.setNaziv(nazivKviza);
                //kviz.setKategorija(kat);
                Intent i1 = new Intent();
                i1.putExtra("kviz", trenutni);
                setResult(Activity.RESULT_OK, i1);
                etNaziv.getBackground().setColorFilter(Color.TRANSPARENT, PorterDuff.Mode.SRC_ATOP);
                if(!checkForKviz(nazivKviza)){
                    new SaveData(getApplicationContext(),trenutni,DodajKvizAkt.this).execute("Kvizovi");
                } else {
                    new EditData(getApplicationContext(),kviz,kviz.getIdFromName(nazivKviza,kvizovi)).execute("Kvizovi");
                    databse.editQuiz(trenutni);
                }
                finish();
            } else {
                etNaziv.getBackground().setColorFilter(Color.RED, PorterDuff.Mode.SRC_ATOP);
                Toast.makeText(getApplicationContext(), "Name is empty!", Toast.LENGTH_SHORT).show();
            }

        });

    }

    public boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        boolean isConnected = false;
        if(connectivityManager != null){
            NetworkInfo activeNetwork= connectivityManager.getActiveNetworkInfo();
            isConnected = (activeNetwork != null) && (activeNetwork.isConnected());
        }
        return isConnected;
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            Kategorija kat = (Kategorija) data.getSerializableExtra("kat");
            if (!checkForCategory(kat.getNaziv())){
                kategorije.add(0, kat);
                new SaveData(getApplicationContext(),kat,DodajKvizAkt.this).execute("Kategorije");
                Log.d("bla",databse.toString());
            }

            spKategorije.setSelection(0);
            spinerAdapter.notifyDataSetChanged();
        }
        if (requestCode == 3 && resultCode == RESULT_OK) {
            Pitanje pitanje = (Pitanje) data.getSerializableExtra("pitanje");
            new SaveData(getApplicationContext(),pitanje,DodajKvizAkt.this).execute("Pitanja");
            mogucaPitanja.add(pitanje);
            mogucaPitanjaAdapter.notifyDataSetChanged();
        }
        if (requestCode == 4 && resultCode == RESULT_OK) {
            try {
                rezultat = readTextFromUri(data.getData());
                extractData();
                if (checkIfCorrect())
                    saveData();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public boolean checkForKviz(String nazivKviza) {
        for (Kviz k : SviKvizovi) {
            if (k.getNaziv().toLowerCase().equals(nazivKviza.toLowerCase()))
                return true;
        }
        return false;
    }

    public boolean checkForAllKviz(String nazivKviza) {
        for (Kviz k : SviKvizovi) {
            if (k.getNaziv().toLowerCase().equals(nazivKviza.toLowerCase()))
                return true;
        }
        return false;
    }

    public boolean checkForCategory(String nazivKategorij) {
        for (Kategorija k : kategorije) {
            if (k.getNaziv().toLowerCase().equals(nazivKategorij.toLowerCase()))
                return true;
        }
        return false;
    }

    private boolean checkForQuestion(String nazivPitanja) {
        for (Pitanje p : kviz.getPitanja()) {
            if (p.getNaziv().toLowerCase().equals(nazivPitanja.toLowerCase()))
                return true;
        }
        return false;
    }

    private String readTextFromUri(Uri uri) throws IOException {
        InputStream inputStream = getContentResolver().openInputStream(uri);
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        StringBuilder stringBuilder = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            stringBuilder.append(line).append(";");
        }
        assert inputStream != null;
        inputStream.close();
        reader.close();
        return stringBuilder.toString();
    }

    private void extractData() {
        String[] rows = rezultat.split(";");
        for (String row : rows) {
            if (counter == 0) generalData(row);
            else generalQuestions(row, numerOfQuestions);
            counter++;
        }
//        etNaziv.setText(importedKviz.getNaziv());
        if (!checkForCategory(importedKviz.getKategorija().getNaziv())) {
            kategorije.add(importedKviz.getKategorija());
            spinerAdapter.notifyDataSetChanged();
        }
//         kviz.getPitanja().clear();
//         kviz.getPitanja().addAll(importedKviz.getPitanja());
//         pitanjaAdapter.notifyDataSetChanged();
    }

    private void generalData(String data) {
        List<String> al = new ArrayList<String>();
        String[] token = data.split(",");
        al = Arrays.asList(token);
        importedKviz.setNaziv(token[0]);
        importedKviz.setKategorija(new Kategorija(token[1], "0"));
//            if(Integer.parseInt(al.get(2)))
        numerOfQuestions = Integer.parseInt(token[2]);
    }

    private void generalQuestions(String data, Integer number) {
        Pitanje pitanje = new Pitanje();
        ArrayList<String> odgovori = new ArrayList<>();
        String[] token = data.split(",");
        pitanje.setNaziv(token[0]);
        pitanje.setTekstPitanja(token[0]);
        numberOfAnswers = Integer.parseInt(token[1]);
        correctAnswer = Integer.parseInt(token[2]);
        for (int i = 3; i < numberOfAnswers + 3; i++) {
            odgovori.add(token[i]);
            temp++;
        }
        pitanje.setOdgovori(odgovori);
        pitanje.setTacan(token[correctAnswer + 2]);
        importedKviz.dodajPitanje(pitanje);
    }

    public Boolean checkIfCorrect() {
        if (checkForAllKviz(importedKviz.getNaziv())) {
            showAlleretDialog("Kviz kojeg importujete vec postoji!");
            return false;
        }
        if (numerOfQuestions.equals(counter)) {
            showAlleretDialog("Kviz kojeg importujete ima neispravan broj pitanja!");
            return false;
        }
        if (numberOfAnswers.equals(temp)) {
            showAlleretDialog("Kviz kojeg importujete ima neispravan broj odgvovora!");
            return false;
        }
        return true;
    }

    private void showAlleretDialog(String message) {
        AlertDialog.Builder adb = new AlertDialog.Builder(DodajKvizAkt.this);
        adb.setTitle("Warning");
        adb.setMessage(message);
        adb.setCancelable(true);
        adb.setPositiveButton("Ok", (dialog, which) -> {
            dialog.cancel();
        });
        adb.show();
    }

    public void saveData() {
        etNaziv.setText(importedKviz.getNaziv());
        kviz.setNaziv(importedKviz.getNaziv());
        //kviz.setPitanja(importedKviz.getPitanja());
        kviz.setKategorija(importedKviz.getKategorija());
        kviz.getPitanja().clear();
        kviz.getPitanja().addAll(importedKviz.getPitanja());
        pitanjaAdapter.notifyDataSetChanged();
    }

    @Override
    public void returnData(JSONObject jsonObject, String kolekcija) throws JSONException {
        switch(kolekcija){
            case "Kvizovi":
                extractQuizes(jsonObject);
                break;
            case "Pitanja":
                extractQuestions(jsonObject);
                break;

        }
    }

    public ArrayList<Pitanje> extractQuestions(JSONObject questions) throws JSONException {
        ArrayList<Pitanje> pitanja =new ArrayList<>();
        Integer indexTacnog;
        String nazivPitanja;
        JSONArray items = questions.getJSONArray("documents");
        for(int i=0;i<items.length();i++){
            ArrayList<String> odgovoriString = new ArrayList<>();
            JSONObject item =items.getJSONObject(i);
            String name = item.getString("name");
            String[] temp = name.split("/");
            String questionId = temp[6];
            JSONObject fields = item.getJSONObject("fields");
            indexTacnog = Integer.valueOf(fields.getJSONObject("indexTacnog").getInt("integerValue"));
            JSONObject naziv = fields.getJSONObject("naziv");
            nazivPitanja = naziv.getString("stringValue");
            JSONObject odgovori = fields.getJSONObject("odgovori").getJSONObject("arrayValue");
            JSONArray values = odgovori.getJSONArray("values");
            for(int j = 0;j<values.length() ; j++){
                JSONObject odgovor =values.getJSONObject(j);
                odgovoriString.add(odgovor.getString("stringValue"));
            }
            Pitanje p = new Pitanje(nazivPitanja,nazivPitanja,odgovoriString.get(indexTacnog),odgovoriString);
            p.setDatabaseId(questionId);
            pitanja.add(p);
        }

            for(Pitanje pi : pitanja)
                if(!checkForQuestion(pi.getNaziv())){
                    mogucaPitanja.add(pi);
            }
        mogucaPitanjaAdapter.notifyDataSetChanged();
        return null;
    }

    public ArrayList<Kviz> extractQuizes(JSONObject quizes) throws JSONException {
        String nazivKviza,idKategorije;
        ArrayList<Kviz> kvizovi = new ArrayList<>();
        JSONArray items = quizes.getJSONArray("documents");
        for(int i=0;i<items.length();i++){
            ArrayList<Pitanje> kvizPitanja = new ArrayList<>();
            ArrayList<String> idPitanja = new ArrayList<>();
            JSONObject item =items.getJSONObject(i);
            String name = item.getString("name");
            String[] temp = name.split("/");
            String quizId = temp[6];
            JSONObject fields = item.getJSONObject("fields");
            JSONObject pitanja = fields.getJSONObject("pitanja").getJSONObject("arrayValue");
            JSONArray values = pitanja.getJSONArray("values");
            for(int j = 0;j<values.length() ; j++){
                JSONObject pitanje =values.getJSONObject(j);
                if(pitanje.getString("stringValue").length() != 0)
                    idPitanja.add(pitanje.getString("stringValue"));
            }
            nazivKviza = fields.getJSONObject("naziv").getString("stringValue");
            idKategorije = fields.getJSONObject("idKategorije").getString("stringValue");
            Kategorija kategorija = getCategoryFromId(idKategorije);
            for(String id : idPitanja)
                kvizPitanja.add(getQuestionFromId(id));
            Kviz kviz = new Kviz(nazivKviza,quizId);
            kviz.setKategorija(kategorija);
            kviz.setPitanja(kvizPitanja);
            kvizovi.add(kviz);
        }
        SviKvizovi = kvizovi;
        return null;
    }

    public Kategorija getCategoryFromId(String id){
        for (Kategorija k : kategorije){
            if(k.getDatabaseId().equals(id))
                return k;
        }
        return null;
    }

    public Pitanje getQuestionFromId(String id){
        for (Pitanje p : mogucaPitanja){
            if(p.getDatabaseId().equals(id))
                return p;
        }
        return null;
    }


    @Override
    public void onDoneSaving(String id, String kolekcija,Object object) {
        switch(kolekcija){
            case "Kvizovi":
                Kviz k =(Kviz)object;
                kviz.setIdUBazi(id);
                databse.addQuiz(k);
                break;
            case "Kategorije":
                Kategorija kategorija =(Kategorija)object;
                kategorija.setDatabaseId(id);
                databse.addCategory(kategorija);
                break;
            case "Pitanja":
                Pitanje pitanje = (Pitanje)object;
                pitanje.setDatabaseId(id);
                databse.addQuestion(pitanje,kviz.getIdUBazi());
                break;
        }
    }
}
