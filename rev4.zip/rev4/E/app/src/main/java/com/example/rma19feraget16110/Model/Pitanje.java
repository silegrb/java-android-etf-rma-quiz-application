package com.example.rma19feraget16110.Model;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;

public class Pitanje implements Serializable {
    private String naziv = "";
    private String tekstPitanja = "";
    private ArrayList<String> odgovori;
    private String tacan = "";
    private String databaseId= "";
    private String kvizDatabseId = "";

    public Pitanje(String naziv, String tekstPitanja, String tacan,ArrayList<String> odgovori) {
        this.naziv = naziv;
        this.tekstPitanja = tekstPitanja;
        this.tacan = tacan;
        this.odgovori=odgovori;
    }
    public Pitanje(String naziv, String tekstPitanja, String tacan,ArrayList<String> odgovori,String idDatabase) {
        this.naziv = naziv;
        this.tekstPitanja = tekstPitanja;
        this.tacan = tacan;
        this.odgovori=odgovori;
        this.databaseId=idDatabase;
    }
    public Pitanje(){
        odgovori=new ArrayList<>();
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getTekstPitanja() {
        return tekstPitanja;
    }

    public void setTekstPitanja(String tekstPitanja) {
        this.tekstPitanja = tekstPitanja;
    }

    public ArrayList<String> getOdgovori() {
        return odgovori;
    }

    public void setOdgovori(ArrayList<String> odgovori) {
        this.odgovori = odgovori;
    }

    public String getTacan() {
        return tacan;
    }

    public void setTacan(String tacan) {
        this.tacan = tacan;
    }

    public String getKvizDatabseId() {
        return kvizDatabseId;
    }

    public void setKvizDatabseId(String kvizDatabseId) {
        this.kvizDatabseId = kvizDatabseId;
    }

    ArrayList<String> dajRandomOdgovore(){
         Collections.shuffle(odgovori);
         return odgovori;
    }
    @Override
    public String toString() {
        return naziv;
    }

    public Integer getNumberOfTrueAnswer(Pitanje pitanje){
        return pitanje.getOdgovori().indexOf(pitanje.getTacan());
    }

    public String getDatabaseId() {
        return databaseId;
    }

    public void setDatabaseId(String databaseId) {
        this.databaseId = databaseId;
    }

    @Override
    public int hashCode() {
     int result = 17;
     result = 31*result +naziv.hashCode();
     result=31*result+tacan.hashCode();
     return result;
    }

    @Override
    public boolean equals(Object obj) {
        if(obj == this) return true;
        if(!(obj instanceof Pitanje)){
            return false;
    }
        Pitanje p = (Pitanje) obj;
        return p.naziv.equals(naziv) &&
                p.tacan.equals(tacan);
    }
}
