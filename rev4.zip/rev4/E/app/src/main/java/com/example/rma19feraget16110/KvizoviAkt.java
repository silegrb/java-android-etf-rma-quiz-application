package com.example.rma19feraget16110;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.rma19feraget16110.Adapters.KvizoviAdapter;
import com.example.rma19feraget16110.Database.RMADatabse;
import com.example.rma19feraget16110.Fragments.DetailFrag;
import com.example.rma19feraget16110.Fragments.ListaFrag;
import com.example.rma19feraget16110.Model.Kategorija;
import com.example.rma19feraget16110.Model.Kviz;
import com.example.rma19feraget16110.Model.Pitanje;
import com.example.rma19feraget16110.Services.GetAllData;
import com.example.rma19feraget16110.Services.GetQuiz;
import com.example.rma19feraget16110.Services.IExtractCategories;
import com.example.rma19feraget16110.Services.IExtractQuestion;
import com.example.rma19feraget16110.Services.IExtractQuiz;
import com.example.rma19feraget16110.Services.Network;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class KvizoviAkt extends AppCompatActivity implements ListaFrag.SendCategory,DetailFrag.SendQuiz, GetAllData.ReturnData, IExtractQuiz, IExtractQuestion, IExtractCategories,GetQuiz.ReturnQuizes {

    //new aproach
    ArrayList<Pitanje> pitanja = new ArrayList<>();


    ArrayList<Kategorija> kategorije = new ArrayList<>();
    ArrayList<Kviz> kvizovi =new ArrayList<>();
    ArrayList<Kviz> filteredQuizes=new ArrayList<>();
    ArrayAdapter<Kategorija> spinerAdapter;
    ArrayList<Pitanje> pitanja1=new ArrayList<>();
    ArrayList<Pitanje> pitanja2=new ArrayList<>();
    ArrayList<Pitanje> pitanja3=new ArrayList<>();
    ArrayList<String> odgovoriPitanje1=new ArrayList<>();
    ArrayList<String> odgovoriPitanje2=new ArrayList<>();
    ArrayList<String> odgovoriPitanje3=new ArrayList<>();
    ArrayList<String> odgovoriPitanje4=new ArrayList<>();
    KvizoviAdapter kvizoviAdapter;
    RMADatabse databse;
    ListView listaKvizova;
    Spinner sKategorije;
    Boolean wideScreen = false;
    private ListaFrag listaFrag;
    private DetailFrag detailFrag;
    FrameLayout listPlace,detailPlace;
    Integer categoryPosition;
    Network network;
    Button sql;
    //private SharedViewModel sharedViewModel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        network = new Network();
        listPlace = findViewById(R.id.listPlace);
        detailPlace = findViewById(R.id.detailPlace);
        sql = findViewById(R.id.sqlDatabase);
        databse = new RMADatabse(this);
        if(savedInstanceState !=null && savedInstanceState.getSerializable("savedQuizes") != null){
            kvizovi= (ArrayList<Kviz>)savedInstanceState.getSerializable("savedQuizes");
            kategorije = (ArrayList<Kategorija>) savedInstanceState.getSerializable("savedCategory");
            pitanja = (ArrayList<Pitanje>) savedInstanceState.getSerializable("savedQuestions");
        } else{
            if(isNetworkAvailable()){
                new GetAllData(getApplicationContext(),KvizoviAkt.this).execute("Kategorije");
                new GetAllData(getApplicationContext(),KvizoviAkt.this).execute("Pitanja");
            } else{
                kategorije = databse.getAllCategory();
                pitanja = databse.getAllQuestions();
            }

            /*
            odgovoriPitanje1.add("Keopsova Piramida");
            odgovoriPitanje1.add("Zeusov Kip");
            odgovoriPitanje1.add("Aleksandrijski svjetionik");
            odgovoriPitanje2.add("Misisipi");
            odgovoriPitanje2.add("Po");
            odgovoriPitanje2.add("Nil");
            odgovoriPitanje3.add("Aurora borealis");
            odgovoriPitanje3.add("acervus");
            odgovoriPitanje3.add("adamo");
            odgovoriPitanje4.add("Volan");
            odgovoriPitanje4.add("Auspuh");
            odgovoriPitanje4.add("Guma");
            pitanja1.add(new Pitanje("Pitanje1","Koje je 7 svjetsko cudo","Aleksandrijski svjetionik",odgovoriPitanje1,"ghg65h"));
            pitanja1.add(new Pitanje("Pitanje2","Najduza rijeka","Nil",odgovoriPitanje2,"ghv58kj"));
            pitanja2.add(new Pitanje("Pitanje3","Zelena polarna svjetlost se naziva","Aurora borealis",odgovoriPitanje3,"asd34cds"));
            pitanja3.add(new Pitanje("Pitanje4","Pneumatik je","Guma",odgovoriPitanje4,"sxcv45gh"));
            Kategorija scienceKategory =new Kategorija("Science","1");
            Kategorija historyKategory =new Kategorija("History","2");
            Kategorija carsKategory =new Kategorija("Cars","3");
            kategorije.add(scienceKategory);
            kategorije.add(historyKategory);
            kategorije.add(carsKategory);
            Kviz kviz1=new Kviz("Kviz1");
            kviz1.setPitanja(pitanja1);
            Kviz kviz2=new Kviz("Kviz2");
            kviz2.setPitanja(pitanja2);
            Kviz kviz3=new Kviz("Kviz3");
            kviz3.setPitanja(pitanja3);
            kvizovi.add(kviz1);
            kvizovi.add(kviz2);
            kvizovi.add(kviz3);
            kviz1.setKategorija(historyKategory);
            kviz2.setKategorija(scienceKategory);
            kviz3.setKategorija(carsKategory);*/
        }
        //kvizovi.add(new Kviz("Dodaj Kviz"));
        //new GetAllData(getApplicationContext(),KvizoviAkt.this).execute("Rangliste");
        if(listPlace != null) wideScreen = true;
        if(!wideScreen) {
                setRegularLayout();
        }
        else
            setUpWideLayout();
    }

    public boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        boolean isConnected = false;
        if(connectivityManager != null){
            NetworkInfo activeNetwork= connectivityManager.getActiveNetworkInfo();
            isConnected = (activeNetwork != null) && (activeNetwork.isConnected());
        }
        return isConnected;
    }
    public void setRegularLayout(){
        listaKvizova=findViewById(R.id.lvKvizovi);
        sKategorije = findViewById(R.id.spPostojeceKategorije);
        //new GetAllData(getApplicationContext(),KvizoviAkt.this).execute("Kategorije");
        //new GetQuiz(getApplicationContext(),"DHv1CZeCp59jXAm7XR6m",KvizoviAkt.this).execute("Kvizovi");
        //listaKvizova.setTextFilterEnabled(true);
        kvizoviAdapter=new KvizoviAdapter(getApplicationContext(), R.layout.pitanja_kviz,kvizovi);
        listaKvizova.setAdapter(kvizoviAdapter);
        //kvizoviAdapter.getFilter().filter(null);
        spinerAdapter=new  ArrayAdapter<>(this,android.R.layout.simple_spinner_item, kategorije);
        spinerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sKategorije.setAdapter(spinerAdapter);
        listaKvizova.setOnItemClickListener((parent, view, position, id) -> {
            //Kviz item=filteredQuizes.get(position);
            Kviz item = kvizovi.get(position);
            if(!item.getNaziv().equals("Dodaj Kviz")){
                Intent igrajKviz = new Intent(getApplicationContext(),IgrajKvizAkt.class);
                Bundle argumenti=new Bundle();
                //argumenti.putSerializable("kviz",filteredQuizes.get(position));
                argumenti.putSerializable("kviz",item);
                igrajKviz.putExtras(argumenti);
                startActivity(igrajKviz);
            }
        });

        listaKvizova.setOnItemLongClickListener((parent, view, position, id) -> {
            if(isNetworkAvailable()){
                Intent i=new Intent(getApplicationContext(),DodajKvizAkt.class);
                Bundle argumenti=new Bundle();
                argumenti.putSerializable("kvizovi", filteredQuizes);
                argumenti.putSerializable("SviKvizovi",kvizovi);
                argumenti.putSerializable("kategorije", kategorije);
                argumenti.putInt("position",position);
                argumenti.putInt("categoryPosition",categoryPosition);
                i.putExtras(argumenti);
                startActivityForResult(i,2);
            } else
               Toast.makeText(getApplicationContext(),"No internet",Toast.LENGTH_SHORT).show();

            return true;
        });

        sKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Kategorija kat=(Kategorija)parent.getItemAtPosition(position);
                if(isNetworkAvailable())
                    new GetQuiz(getApplicationContext(),kat.getDatabaseId(),KvizoviAkt.this).execute("Kvizovi");
                else{
                    kvizovi = databse.getQuizByCategoryName(kat.getNaziv());
                    kvizoviAdapter=new KvizoviAdapter(getApplicationContext(), R.layout.pitanja_kviz,kvizovi);
                    listaKvizova.setAdapter(kvizoviAdapter);
                }

                //kvizoviAdapter.getFilter().filter(kat.getNaziv());
                //findKvizFromCategory(kat);
                categoryPosition = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        sql.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent dbmanager = new Intent(getApplicationContext(),AndroidDatabaseManager.class);
                startActivity(dbmanager);
            }
        });
    }

    public void setUpWideLayout(){
        Bundle argumenti = new Bundle();
        argumenti.putSerializable("kategorije",kategorije);
        argumenti.putSerializable("kvizovi",kvizovi);
        argumenti.putSerializable("pitanja",pitanja);
        listaFrag = new ListaFrag();
        detailFrag = new DetailFrag();
        listaFrag.setArguments(argumenti);
        detailFrag.setArguments(argumenti);
        getSupportFragmentManager().beginTransaction().
                replace(R.id.listPlace,listaFrag).
                replace(R.id.detailPlace,detailFrag).commit();
    }
    public ArrayList<Kviz> findKvizFromCategory(Kategorija kategorija){
        filteredQuizes.clear();
        String nazivKategorije=kategorija.getNaziv().toLowerCase();
        for (Kviz k: kvizovi) {
            if(k.getKategorija()!=null && k.getKategorija().getNaziv().toLowerCase().equals(nazivKategorije))
                filteredQuizes.add(k);
        }
        filteredQuizes.add(new Kviz("Dodaj Kviz"));
        return filteredQuizes;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 2 && resultCode ==RESULT_OK){
            final Kviz kviz=(Kviz)data.getSerializableExtra("kviz");
            //kvizovi.add(0,kviz);
            if(!kategorije.contains(kviz.getKategorija()))
                kategorije.add(0,kviz.getKategorija());
            //kvizoviAdapter=new KvizoviAdapter(getApplicationContext(), R.layout.pitanja_kviz,findKvizFromCategory(kviz.getKategorija()));
            //listaKvizova.setAdapter(kvizoviAdapter);
            kvizoviAdapter.notifyDataSetChanged();
            //kvizoviAdapter.getFilter().filter(kviz.getKategorija().getNaziv());
            spinerAdapter.notifyDataSetChanged();
        }
        if(requestCode == 3 && resultCode ==RESULT_OK){
            final Kviz kviz=(Kviz)data.getSerializableExtra("kviz");
            //kvizovi.add(0,kviz);
            if(!kategorije.contains(kviz.getKategorija()))
                kategorije.add(0,kviz.getKategorija());
            //kvizoviAdapter=new KvizoviAdapter(getApplicationContext(), R.layout.pitanja_kviz,findKvizFromCategory(kviz.getKategorija()));
            //listaKvizova.setAdapter(kvizoviAdapter);
            kvizoviAdapter.notifyDataSetChanged();
            spinerAdapter.notifyDataSetChanged();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putSerializable("savedCategory",kategorije);
        outState.putSerializable("savedQuizes",kvizovi);
        outState.putSerializable("savedQuestions",pitanja);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        kategorije = (ArrayList<Kategorija>) savedInstanceState.getSerializable("savedCategory");
        kvizovi = (ArrayList<Kviz>) savedInstanceState.getSerializable("savedQuizes");
        pitanja = (ArrayList<Pitanje>) savedInstanceState.getSerializable("savedQuestions");
        spinerAdapter=new  ArrayAdapter<>(this,android.R.layout.simple_spinner_item, kategorije);
        spinerAdapter.notifyDataSetChanged();
    }

    @Override
    public void sendCategory(Kategorija kategorija,Integer categoryPosition) {
        this.categoryPosition = categoryPosition;
        findKvizFromCategory(kategorija);
        if(kategorija == null)
            detailFrag.showQuizes(null);
        else
            detailFrag.showQuizes(kategorija);
    }

    @Override
    public void onQuizSelected(Kviz quiz, int position,ArrayList<Kviz> kvizovi) {
        openActivity(quiz,position,IgrajKvizAkt.class,kvizovi);
    }

    @Override
    public void onQuizLongSelected(Kviz quiz, int position,ArrayList<Kviz> kvizovi) {
        openActivity(quiz,position,DodajKvizAkt.class,kvizovi);
    }

    public void openActivity(Kviz quiz, int position, Class activity,ArrayList<Kviz> kvizovi){
        Intent i = new Intent(getApplicationContext(),activity);
        Bundle podaci = new Bundle();
        podaci.putInt("categoryPosition",categoryPosition);
        podaci.putSerializable("kviz",quiz);;
        podaci.putSerializable("kategorije",kategorije);
        podaci.putSerializable("kvizovi", kvizovi);
        podaci.putSerializable("SviKvizovi",kvizovi);
        podaci.putInt("position",position);
        i.putExtras(podaci);
        startActivityForResult(i,3);
    }

    @Override
    public void returnData(JSONObject jsonObject,String kolekcija) throws JSONException {
        switch(kolekcija){
            case "Kvizovi":
                extractQuizes(jsonObject);
                break;
            case "Kategorije":
                extractCategories(jsonObject);
                break;
            case "Pitanja":
                extractQuestions(jsonObject);
                break;
            case "Rangliste":
                extractRangliste(jsonObject);
                break;
        }
    }

    @Override
    public ArrayList<Pitanje> extractCategories(JSONObject categories) throws JSONException {
        ArrayList<Kategorija> databaseKategorije = new ArrayList<>();
        String idIkonice,nazivKategorije;
        JSONArray items = categories.getJSONArray("documents");
        for(int i=0;i<items.length();i++){
            JSONObject item =items.getJSONObject(i);
            String name = item.getString("name");
            String[] temp = name.split("/");
            String categoryId = temp[6];
            JSONObject fields = item.getJSONObject("fields");
            idIkonice = fields.getJSONObject("idIkonice").getString("stringValue");
            JSONObject naziv = fields.getJSONObject("naziv");
            nazivKategorije = naziv.getString("stringValue");
            Kategorija k = new Kategorija(nazivKategorije,idIkonice);
            k.setDatabaseId(categoryId);
            databaseKategorije.add(k);
        }
        kategorije = databaseKategorije;
        spinerAdapter=new  ArrayAdapter<>(this,android.R.layout.simple_spinner_item, kategorije);
        spinerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sKategorije.setAdapter(spinerAdapter);
        return null;
    }

    @Override
    public ArrayList<Pitanje> extractQuestions(JSONObject questions) throws JSONException {
        ArrayList<Pitanje> pitanjaDatabase =new ArrayList<>();
        Integer indexTacnog;
        String nazivPitanja;
        JSONArray items = questions.getJSONArray("documents");
        for(int i=0;i<items.length();i++){
            ArrayList<String> odgovoriString = new ArrayList<>();
            JSONObject item =items.getJSONObject(i);
            String name = item.getString("name");
            String[] temp = name.split("/");
            String questionId = temp[6];
            JSONObject fields = item.getJSONObject("fields");
            indexTacnog = Integer.valueOf(fields.getJSONObject("indexTacnog").getInt("integerValue"));
            JSONObject naziv = fields.getJSONObject("naziv");
            nazivPitanja = naziv.getString("stringValue");
            JSONObject odgovori = fields.getJSONObject("odgovori").getJSONObject("arrayValue");
            JSONArray values = odgovori.getJSONArray("values");
            for(int j = 0;j<values.length() ; j++){
                JSONObject odgovor =values.getJSONObject(j);
                odgovoriString.add(odgovor.getString("stringValue"));
            }
            Pitanje p = new Pitanje(nazivPitanja,nazivPitanja,odgovoriString.get(indexTacnog),odgovoriString);
            p.setDatabaseId(questionId);
            pitanjaDatabase.add(p);
        }
        pitanja = pitanjaDatabase;
        return null;
    }

    @Override
    public ArrayList<Kviz> extractQuizes(JSONObject quizes) throws JSONException {
        String nazivKviza,idKategorije;
        ArrayList<Kviz> kvizovi = new ArrayList<>();
        JSONArray items = quizes.getJSONArray("documents");
        for(int i=0;i<items.length();i++){
            ArrayList<Pitanje> kvizPitanja = new ArrayList<>();
            ArrayList<String> idPitanja = new ArrayList<>();
            JSONObject item =items.getJSONObject(i);
            String name = item.getString("name");
            String[] temp = name.split("/");
            String quizId = temp[6];
            JSONObject fields = item.getJSONObject("fields");
            JSONObject pitanja = fields.getJSONObject("pitanja").getJSONObject("arrayValue");
            JSONArray values = pitanja.getJSONArray("values");
            for(int j = 0;j<values.length() ; j++){
                JSONObject pitanje =values.getJSONObject(j);
                if(pitanje.getString("stringValue").length() != 0)
                    idPitanja.add(pitanje.getString("stringValue"));
            }
            nazivKviza = fields.getJSONObject("naziv").getString("stringValue");
            idKategorije = fields.getJSONObject("idKategorije").getString("integerValue");
            Kategorija kategorija = getCategoryFromId(idKategorije);
            for(String id : idPitanja)
                kvizPitanja.add(getQuestionFromId(id));
            Kviz kviz = new Kviz(nazivKviza,quizId);
            kviz.setKategorija(kategorija);
            kviz.setPitanja(kvizPitanja);
            kvizovi.add(kviz);
        }
        return null;
    }
    public void extractRangliste(JSONObject ranglista){
        JSONObject j = ranglista;
        String ha = j.toString();
    }

    public Pitanje getQuestionFromId(String id){
        for (Pitanje p : pitanja){
            if(p.getDatabaseId().equals(id))
                return p;
        }
        return null;
    }

    public Kategorija getCategoryFromId(String id){
        for (Kategorija k : kategorije){
            if(k.getDatabaseId().equals(id))
                return k;
        }
        return null;
    }

    @Override
    public void returnQuizes(JSONObject object) throws JSONException {
        String nazivKviza,idKategorije;
        ArrayList<Kviz> kvizoviDatabase = new ArrayList<>();
        Kategorija kategorija = null;
        JSONArray items = object.getJSONArray("documents");
        for(int i=0;i<items.length();i++){
            ArrayList<Pitanje> kvizPitanja = new ArrayList<>();
            ArrayList<String> idPitanja = new ArrayList<>();
            JSONObject item =items.getJSONObject(i);
            JSONObject document = item.getJSONObject("document");
            String name = document.getString("name");
            String[] temp = name.split("/");
            String quizId = temp[6];
            JSONObject fields = document.getJSONObject("fields");
            nazivKviza = fields.getJSONObject("naziv").getString("stringValue");
            idKategorije = fields.getJSONObject("idKategorije").getString("stringValue");
            JSONObject pitanja = fields.getJSONObject("pitanja").getJSONObject("arrayValue");
            JSONArray values = pitanja.getJSONArray("values");
            for(int j = 0;j<values.length() ; j++){
                JSONObject pitanje =values.getJSONObject(j);
                if(pitanje.getString("stringValue").length() != 0)
                        idPitanja.add(pitanje.getString("stringValue"));
            }
            kategorija = getCategoryFromId(idKategorije);
            for(String id : idPitanja)
                kvizPitanja.add(getQuestionFromId(id));
            Kviz kviz = new Kviz(nazivKviza,quizId);
            kviz.setKategorija(kategorija);
            kviz.setPitanja(kvizPitanja);
            kvizoviDatabase.add(kviz);
        }
        kvizovi = kvizoviDatabase;
        kvizoviAdapter=new KvizoviAdapter(getApplicationContext(), R.layout.pitanja_kviz,kvizovi);
        listaKvizova.setAdapter(kvizoviAdapter);
        findKvizFromCategory(kategorija);

    }
}
