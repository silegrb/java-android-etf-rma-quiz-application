package ba.unsa.etf.rma.utilities;

public interface AsyncAddCategoryTaskResponse {
    void finishedAdd(String id);
}
