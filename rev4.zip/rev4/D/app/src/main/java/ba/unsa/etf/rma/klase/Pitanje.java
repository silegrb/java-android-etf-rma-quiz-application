package ba.unsa.etf.rma.klase;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Objects;

import static java.util.Collections.shuffle;

public class Pitanje implements Serializable, Parcelable {
    private String naziv;
    private String tekstPitanja;
    private ArrayList<String> odgovori;
    private String tacan;
    private boolean odgovoreno = false;
    private String databaseId;
    private long sqlId;

    public Pitanje(String naziv) {
        this.naziv = naziv;
    }

    public Pitanje(String naziv, String tekstPitanja, ArrayList<String> odgovori, String tacan) {
        this.naziv = naziv;
        this.tekstPitanja = tekstPitanja;
        this.odgovori = odgovori;
        this.tacan = tacan;
    }

    protected Pitanje(Parcel in) {
        naziv = in.readString();
        tekstPitanja = in.readString();
        if (in.readByte() == 0x01) {
            odgovori = new ArrayList<String>();
            in.readList(odgovori, String.class.getClassLoader());
        } else {
            odgovori = null;
        }
        tacan = in.readString();
        odgovoreno = in.readByte() != 0x00;
        databaseId = in.readString();
    }

    public static final Creator<Pitanje> CREATOR = new Creator<Pitanje>() {
        @Override
        public Pitanje createFromParcel(Parcel in) {
            return new Pitanje(in);
        }

        @Override
        public Pitanje[] newArray(int size) {
            return new Pitanje[size];
        }
    };

    public Pitanje(String text, String text1, ArrayList<String> o, String correct, String firebase, long id) {
        this.naziv = text;
        this.tekstPitanja = text;
        this.odgovori = o;
        this.tacan = correct;
        databaseId = firebase;
        sqlId = id;
    }

    ArrayList<String> dajRandomOdgovore() {
        shuffle(odgovori);
        return odgovori;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getTekstPitanja() {
        return tekstPitanja;
    }

    public void setTekstPitanja(String tekstPitanja) {
        this.tekstPitanja = tekstPitanja;
    }

    public ArrayList<String> getOdgovori() {
        return odgovori;
    }

    public void setOdgovori(ArrayList<String> odgovori) {
        this.odgovori = odgovori;
    }

    public String getTacan() {
        return tacan;
    }

    public void setTacan(String tacan) {
        this.tacan = tacan;
    }

    public boolean isOdgovoreno() {
        return odgovoreno;
    }

    public void setOdgovoreno(boolean odgovoreno) {
        this.odgovoreno = odgovoreno;
    }

    public void setDatabaseId(String databaseId) {
        this.databaseId = databaseId;
    }

    public String getDatabaseId() {
        return databaseId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Pitanje pitanje = (Pitanje) o;
        return Objects.equals(naziv, pitanje.naziv) &&
                Objects.equals(tekstPitanja, pitanje.tekstPitanja) &&
                Objects.equals(odgovori, pitanje.odgovori) &&
                Objects.equals(tacan, pitanje.tacan);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int i) {
        dest.writeString(naziv);
        dest.writeString(tekstPitanja);
        if (odgovori == null) {
            dest.writeByte((byte) (0x00));
        } else {
            dest.writeByte((byte) (0x01));
            dest.writeList(odgovori);
        }
        dest.writeString(tacan);
        dest.writeByte((byte) (odgovoreno ? 0x01 : 0x00));
        dest.writeString(databaseId);
    }

    public long getSqlId() {
        return sqlId;
    }
}
