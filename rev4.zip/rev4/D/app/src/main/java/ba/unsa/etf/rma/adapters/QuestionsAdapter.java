package ba.unsa.etf.rma.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.database.Cache;
import ba.unsa.etf.rma.enums.Type;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.projekat.R;

public class QuestionsAdapter extends AsyncListAdapter<Pitanje> {

    private ArrayList<Pitanje> noShowQuestions; //pitanja koja su u kvizu i treba ih izbacit
    private ListView listView;
    private ArrayList<Pitanje> objects;

    public QuestionsAdapter(@NonNull Context context, ArrayList<Pitanje> questions, ListView listView) {
        super(context, 0, Type.Question);
        this.noShowQuestions = questions;
        this.listView = listView;
        objects = new ArrayList<>();
        updateObjects();
        setListViewHeightBasedOnChildren(listView);
    }

    @Override
    protected ArrayList<Pitanje> getObjects() {
        return objects;
    }

    private void updateObjects() {
        objects.clear();
        objects.addAll(Cache.getInstance(context).getQuestions());
        if (objects != null && noShowQuestions != null) {
            for (Pitanje p : noShowQuestions) {
                objects.remove(p);
            }
        }
        notifyDataSetChanged();
        setListViewHeightBasedOnChildren(listView);
    }

    public void update(ArrayList<Pitanje> questions) {
        this.noShowQuestions = questions;
        updateObjects();
        notifyDataSetChanged();
        setListViewHeightBasedOnChildren(listView);
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return getObjects().size();
    }

    @Nullable
    @Override
    public Pitanje getItem(int position) {
        return getObjects().get(position);
    }

    @Override
    public int getPosition(@Nullable Pitanje item) {
        return getObjects().indexOf(item);
    }

    @Override
    protected View initView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.lv_kviz, parent, false);
        }
        ImageView ikonaPitanja = convertView.findViewById(R.id.ikonaKategorije);
        TextView nazivPitanja = convertView.findViewById(R.id.imeKviza);

        Pitanje currentItem = getItem(position);
        nazivPitanja.setText(currentItem.getNaziv());
        ikonaPitanja.setBackgroundResource(R.drawable.add_button);

        return convertView;
    }

    public void setListViewHeightBasedOnChildren(ListView listView) {
        notifyDataSetChanged();
        int totalHeight = 0;
        int desiredWidth = View.MeasureSpec.makeMeasureSpec(listView.getWidth(), View.MeasureSpec.AT_MOST);
        for (int i = 0; i < getCount(); i++) {
            View listItem = getView(i, null, listView);
            listItem.measure(desiredWidth, View.MeasureSpec.UNSPECIFIED);
            totalHeight += listItem.getMeasuredHeight();
        }

        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight + (listView.getDividerHeight() * (getCount() - 1));
        listView.setLayoutParams(params);
        listView.requestLayout();
    }

    @Override
    public void add(@Nullable Pitanje object) {
        noShowQuestions.remove(object);
        updateObjects();
    }

    @Override
    public void remove(@Nullable Pitanje object) {
        noShowQuestions.add(object);
        updateObjects();
    }
}
