package ba.unsa.etf.rma.aktivnosti;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

import java.io.IOException;
import java.util.ArrayList;

import ba.unsa.etf.rma.adapters.CategoriesAdapter;
import ba.unsa.etf.rma.adapters.InQuizQuestionsAdapter;
import ba.unsa.etf.rma.adapters.QuestionsAdapter;
import ba.unsa.etf.rma.database.Cache;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.projekat.R;
import ba.unsa.etf.rma.tasks.AddQuestionTask;
import ba.unsa.etf.rma.tasks.AddQuizTask;
import ba.unsa.etf.rma.tasks.EditQuizTask;
import ba.unsa.etf.rma.utilities.AsyncAddQuizTaskResponse;
import ba.unsa.etf.rma.utilities.AsyncEditTaskResponse;
import ba.unsa.etf.rma.utilities.ConnectionUtils;
import ba.unsa.etf.rma.utilities.Observer;
import ba.unsa.etf.rma.utilities.QuizTxtParser;
import ba.unsa.etf.rma.utilities.WrongQuizFormatException;

public class DodajKvizAkt extends AppCompatActivity implements AsyncAddQuizTaskResponse, AsyncEditTaskResponse,
        AddQuestionTask.AsyncAddQuestionTaskResponse, Observer {
    private static final int ADD_CATEGORY_CODE = 400;
    private static final int ADD_QUESTION_CODE = 500;
    private static final int READ_REQUEST_CODE = 42;

    private Spinner spKategorije;
    private ListView lvDodanaPitanja;
    private ListView lvMogucaPitanja;
    private EditText etNaziv;

    private Kviz kviz;
    private boolean editing;
    private boolean imported = false;
    private String oldName;

    private QuestionsAdapter mpitanjaAdapter;
    private InQuizQuestionsAdapter dpitanjaAdapter;
    private CategoriesAdapter categoriesAdapter;
    Uri uri = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dodaj_kviz_akt);

        lvMogucaPitanja = findViewById(R.id.lvMogucaPitanja);
        lvDodanaPitanja = findViewById(R.id.lvDodanaPitanja);
        etNaziv = findViewById(R.id.etNaziv);
        Button btnDodajKviz = findViewById(R.id.btnDodajKviz);
        spKategorije = findViewById(R.id.spKategorije);
        Button btnImportQuiz = findViewById(R.id.btnImportKviz);


        kviz = getIntent().getParcelableExtra("kviz");

        if (kviz == null) {
            kviz = new Kviz("", new ArrayList<>(), new Kategorija("Svi", "0"));
            editing = false;
        } else {
            etNaziv.setText(kviz.getNaziv());
            editing = true;
            oldName = kviz.getNaziv();
        }

        initList1();
        initList2();
        initSpinner();

        spKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Kategorija odabranaKategorija = (Kategorija) parent.getItemAtPosition(position);
                if (odabranaKategorija == null) {
                    Intent intent = new Intent(DodajKvizAkt.this, DodajKategorijuAkt.class);
                    startActivityForResult(intent, ADD_CATEGORY_CODE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        etNaziv.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                etNaziv.setBackgroundColor(Color.TRANSPARENT);
            }
        });

        lvDodanaPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Pitanje pitanje = (Pitanje) parent.getItemAtPosition(position);
                if (pitanje == null) {
                    Intent intent = new Intent(DodajKvizAkt.this, DodajPitanjeAkt.class);
                    intent.putParcelableArrayListExtra("questions", kviz.getPitanja());
                    startActivityForResult(intent, ADD_QUESTION_CODE);
                } else {
                    dpitanjaAdapter.remove(pitanje);
                    dpitanjaAdapter.notifyDataSetChanged();

                    mpitanjaAdapter.add(pitanje);
                    mpitanjaAdapter.notifyDataSetChanged();
                }
            }
        });

        lvMogucaPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Pitanje pitanje = (Pitanje) parent.getItemAtPosition(position);

                dpitanjaAdapter.add(pitanje);
                dpitanjaAdapter.notifyDataSetChanged();

                mpitanjaAdapter.remove(pitanje);
                mpitanjaAdapter.notifyDataSetChanged();

                lvDodanaPitanja.setBackgroundColor(Color.TRANSPARENT);
            }
        });


        btnDodajKviz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateInput()) {
                    if(!ConnectionUtils.isNetworkAvailable(DodajKvizAkt.this)){
                        showAlertDialog("Pokušajte ponovo nakon što se konektujete na internet!");
                        return;
                    }

                    if(imported) {
                        setResult(Activity.RESULT_CANCELED);
                        finish();
                    }
                    kviz.setNaziv(etNaziv.getText().toString());
                    kviz.setKategorija((Kategorija) spKategorije.getSelectedItem());
                    kviz.setPitanja(dpitanjaAdapter.getItems());

                    if (editing) {
                        editQuizInDatabase(kviz);
                    } else {
                        addQuizToDatabase(kviz);
                    }
                } else {
                    if (!validCategory()) {
                        spKategorije.setBackgroundColor(Color.RED);
                    }
                    if (!validQuizName()) {
                        etNaziv.setBackgroundColor(Color.RED);
                    }
                }
            }
        });

        btnImportQuiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                performFileSearch();
            }
        });
    }

    private void addQuizToDatabase(Kviz kviz) {
        new AddQuizTask(DodajKvizAkt.this, this).execute(kviz);
    }

    private void editQuizInDatabase(Kviz kviz) {
        new EditQuizTask(DodajKvizAkt.this, this).execute(kviz);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK) {
            super.onActivityResult(requestCode, resultCode, data);
            if (requestCode == ADD_CATEGORY_CODE) {
                onAddCategoryResultRecieved(data);
            } else if (requestCode == ADD_QUESTION_CODE) {
                onAddQuestionResultRecieved(data);
            } else if (requestCode == READ_REQUEST_CODE) {
                onReadQuizResultRecieved(data);
            }
        }
    }

    private void onAddCategoryResultRecieved(Intent data) {
        String id = data.getStringExtra("databaseId");
        //Log.d("kat", id);
        spKategorije.setSelection(categoriesAdapter.getPosition(categoriesAdapter.getCategoryById(id)));
        categoriesAdapter.notifyDataSetChanged();
    }

    private void onAddQuestionResultRecieved(Intent data) {

        Pitanje question = data.getParcelableExtra("addedQuestion");
        kviz.dodajPitanje(question);
        dpitanjaAdapter.setQuestions(kviz.getPitanja());
        mpitanjaAdapter.update(kviz.getPitanja());
    }

    private void onReadQuizResultRecieved(Intent data) {
        if (data != null) {
            uri = data.getData();
            try {
                QuizTxtParser quizParser = new QuizTxtParser(uri, DodajKvizAkt.this, this);
                quizParser.setOldName(editing ? oldName : null);
                kviz = quizParser.parse();
                updateActivityFromQuiz();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (WrongQuizFormatException e) {
                showAlertDialog(e.getMessage());
            }
        }
    }


    private boolean validateInput() {
        return validCategory() && validQuizName();
    }

    private boolean validCategory() {
        return spKategorije.getSelectedItem() != null && !((Kategorija) spKategorije.getSelectedItem()).getNaziv().equals("");
    }

    private boolean validQuizName() {
        return !etNaziv.getEditableText().toString().isEmpty() && isUnique(etNaziv.getEditableText().toString());
    }

    private void initList1() {
        dpitanjaAdapter = new InQuizQuestionsAdapter(DodajKvizAkt.this, kviz.getPitanja(), lvDodanaPitanja);
        lvDodanaPitanja.setAdapter(dpitanjaAdapter);
    }

    private void initList2() {
        mpitanjaAdapter = new QuestionsAdapter(DodajKvizAkt.this, kviz.getPitanja(), lvMogucaPitanja);
        lvMogucaPitanja.setAdapter(mpitanjaAdapter);
    }

    private void initSpinner() {
        categoriesAdapter = new CategoriesAdapter(DodajKvizAkt.this, true, this);
        spKategorije.setAdapter(categoriesAdapter);
        spKategorije.setSelection(categoriesAdapter.getPosition(kviz.getKategorija()));
    }

    private boolean isUnique(String nazivKviza) {
        if (editing && nazivKviza.equals(oldName)) return true;

        for (Kviz k : Cache.getInstance(DodajKvizAkt.this).getQuizes()) {
            if (k != null && k.getNaziv().equals(nazivKviza)) return false;
        }
        return true;
    }

    private void performFileSearch() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/*");
        startActivityForResult(intent, READ_REQUEST_CODE);
    }

    private void updateActivityFromQuiz() {
        if (kviz != null) {
            etNaziv.setText(kviz.getNaziv());
            spKategorije.setSelection(categoriesAdapter.getPosition(kviz.getKategorija()));
            categoriesAdapter.notifyDataSetChanged();
            imported = true;
            /*for (Pitanje p : kviz.getPitanja()) {
                if (!Cache.getInstance(DodajKvizAkt.this).getQuestions().contains(p)) {
                    new AddQuestionTask(DodajKvizAkt.this, this).execute(p);
                }
            }*/
        }
    }

    private void showAlertDialog(String message) {
        new AlertDialog.Builder(DodajKvizAkt.this).setMessage(message).setNeutralButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        }).show();
    }

    @Override
    public void finishedAdd(String id) {
        kviz.setDatabaseId(id);
        finalizeActivity();
    }

    @Override
    public void finishedQuestionAdd(String id) {
        Pitanje question = Cache.getInstance(DodajKvizAkt.this).getQuestionById(id);
        dpitanjaAdapter.add(question);
        dpitanjaAdapter.notifyDataSetChanged();

        mpitanjaAdapter.remove(question);
        mpitanjaAdapter.notifyDataSetChanged();
    }

    @Override
    public void finishedEdit() {
        finalizeActivity();
    }

    private void finalizeActivity() {
        Cache.getInstance(DodajKvizAkt.this).update();
        Intent intent = new Intent();
        intent.putExtra("quiz", (Parcelable) kviz);
        setResult(Activity.RESULT_OK, intent);
        finish();
    }

    @Override
    public void update() {
        //Cache.getInstance(DodajKvizAkt.this).update();
    }
}
