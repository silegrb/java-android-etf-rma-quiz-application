package ba.unsa.etf.rma.fragmenti;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import ba.unsa.etf.rma.adapters.RangListAdapter;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.projekat.R;

public class RangLista extends Fragment {
    private ListView rangList;
    private RangListAdapter adapter;

    public RangLista() {
        // Required empty public constructor
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Bundle args = getArguments();
        Kviz quiz = args.getParcelable("quiz");

        if (rangList != null) {
            adapter = new RangListAdapter(getContext(), quiz);
            rangList.setAdapter(adapter);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.rang_lista, container, false);

        rangList = view.findViewById(R.id.rangList);

        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    public void update() {
        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }
    }
}
