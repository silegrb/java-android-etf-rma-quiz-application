package ba.unsa.etf.rma.tasks;

import android.content.Context;
import android.os.AsyncTask;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;

import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.projekat.R;
import ba.unsa.etf.rma.utilities.AsyncAddCategoryTaskResponse;

public class AddCategoryTask extends AsyncTask<Kategorija, Void, String> {

    private WeakReference<Context> context;
    AsyncAddCategoryTaskResponse delegate;

    public AddCategoryTask(Context context, AsyncAddCategoryTaskResponse delegate) {
        this.context = new WeakReference<>(context);
        this.delegate = delegate;
    }

    @Override
    protected String doInBackground(Kategorija... categories) {

        String kolekcija = "Kategorije";
        String nazivKategorije = categories[0].getNaziv();
        int idIkonice = Integer.parseInt(categories[0].getId());

        InputStream is = context.get().getResources().openRawResource(R.raw.secret);
        GoogleCredential credentials = null;
        try {
            credentials = GoogleCredential.fromStream(is).
                    createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String TOKEN = credentials.getAccessToken();

            String url = "https://firestore.googleapis.com/v1/projects/spirala3-1998/databases/(default)/documents/" + kolekcija + "?access_token=";
            URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
            HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/jason");
            conn.setRequestProperty("Accept", "application/jason");

            String document = "{\"fields\": { \"naziv\": {\"stringValue\":\"" + nazivKategorije + "\"}, \"idIkonice\": {\"integerValue\": \"" + idIkonice + "\"}}}";
            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = document.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            int code = conn.getResponseCode();
            InputStream odgovor = conn.getInputStream();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(odgovor, "utf-8"))) {
                StringBuilder response = new StringBuilder();
                String responseLine = null;
                while ((responseLine = br.readLine()) != null) {
                    response.append(responseLine.trim());
                }
                return getDatabaseId(response.toString());
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (ProtocolException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(String id) {
        super.onPostExecute(id);
        delegate.finishedAdd(id);
    }

    private String getDatabaseId(String response) {
        try {
            JSONObject jsonObject = new JSONObject(response.toString());
            String name = jsonObject.getString("name");

            String[] idParser = name.split("/");
            String id = idParser[idParser.length - 1];
            return id;
        } catch (
                JSONException e) {
            e.printStackTrace();
        }

        return null;
    }

}
