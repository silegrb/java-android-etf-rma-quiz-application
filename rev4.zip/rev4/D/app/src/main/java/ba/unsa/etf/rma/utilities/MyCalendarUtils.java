package ba.unsa.etf.rma.utilities;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.CalendarContract;
import android.support.v4.app.ActivityCompat;
import android.util.Log;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;

public class MyCalendarUtils {
    private static final int MY_CAL_REQ = 500;
    Context context;
    Activity activity;
    public  MyCalendarUtils(Context context, Activity activity){
        this.context = context;
        this.activity = activity;
    }

    public ArrayList<Calendar> getStartDates() {
        return  queryFor(CalendarContract.Events.DTSTART);
    }

    public ArrayList<Calendar> getEndDates(){
        return queryFor(CalendarContract.Events.DTEND);
    }

    private ArrayList<Calendar> queryFor(String column) {
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.READ_CALENDAR}, MY_CAL_REQ);
        }
        Cursor cur = null;
        ContentResolver cr = context.getContentResolver();

        String[] mProjection =
                {
                        "_id",
                        CalendarContract.Events.TITLE,
                        CalendarContract.Events.EVENT_LOCATION,
                        CalendarContract.Events.DTSTART,
                        CalendarContract.Events.DTEND,
                };

        Uri uri = CalendarContract.Events.CONTENT_URI;

        cur = cr.query(uri, mProjection, null, null, null);
        ArrayList<Calendar> result = new ArrayList<>();
        while (cur.moveToNext()) {
            long milis = cur.getLong(cur.getColumnIndex(column));
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(milis);
            result.add(roundTime(calendar));
        }


        return result;
    }

    public boolean hasActiveEvents(Calendar current){
        ArrayList<Calendar> calendarsEnd = getEndDates();
        Log.e("datumi", ""+ calendarsEnd.size());
        Log.e("current", current.getTime().toString());
        ArrayList<Calendar> calendarsBegin = getStartDates();
        for(int i = 0; i < calendarsBegin.size(); i++){
            Log.e("calendar ", i + " " + calendarsBegin.get(i).getTime());
            if(current.getTime().after(calendarsBegin.get(i).getTime()) && current.getTime().before(calendarsEnd.get(i).getTime())){
                Log.e("progress", "Here");
                return true;
            }
        }

        return false;
    }

    public int getMinutesToFirstEvent(Calendar current){
        ArrayList<Calendar> calendars = getStartDates();
        Collections.sort(calendars, new Comparator<Calendar>() {
            public int compare(Calendar item1, Calendar item2) {
                if(item1.getTime().before(item2.getTime())) return -1;
                if(item1.getTime().equals(item1.getTime())) return 0;
                return 1;
            }
        });

        for(Calendar c : calendars){
            if(current.getTime().before(c.getTime())){
                Log.e("progress", "here");
                long milisDif = (c.getTimeInMillis() - current.getTimeInMillis());
                Calendar cal = Calendar.getInstance();
                cal.setTimeInMillis(milisDif);
                return cal.get(Calendar.MINUTE);
            }
        }

        return -1;
    }
    public Calendar roundTime(Calendar calendar) {
        if(calendar.get(Calendar.SECOND) > 0){
            calendar.set(Calendar.MINUTE, calendar.get(Calendar.MINUTE) + 1);
        }

        return calendar;
    }

}
