package ba.unsa.etf.rma.aktivnosti;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.Spinner;

import java.util.Calendar;

import ba.unsa.etf.rma.adapters.CategoriesAdapter;
import ba.unsa.etf.rma.adapters.QuizesAdapter;
import ba.unsa.etf.rma.database.Cache;
import ba.unsa.etf.rma.database.Queries;
import ba.unsa.etf.rma.fragmenti.DetailFrag;
import ba.unsa.etf.rma.fragmenti.ListaFrag;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.projekat.R;
import ba.unsa.etf.rma.tasks.AddCategoryTask;
import ba.unsa.etf.rma.utilities.AsyncAddCategoryTaskResponse;
import ba.unsa.etf.rma.utilities.AsyncAddRangListTaskResponse;
import ba.unsa.etf.rma.utilities.ConnectionUtils;
import ba.unsa.etf.rma.utilities.MyCalendarUtils;
import ba.unsa.etf.rma.utilities.Observer;

public class KvizoviAkt extends AppCompatActivity implements ListaFrag.ListFragmentListener, DetailFrag.DetailFragmentListener, Observer,
        AsyncAddCategoryTaskResponse, AsyncAddRangListTaskResponse {
    private static final int REQUEST = 400;
    private Spinner spPostojeceKategorije;
    private ListView lvKvizovi;

    private QuizesAdapter quizesAdapter;
    private CategoriesAdapter categoriesAdapter;

    private static final int CODE_EDIT = 100;
    private static final int CODE_ADD = 200;
    private static final int CODE_PLAY_QUIZ = 300;

    private boolean wideScreen = false;

    private ListaFrag listaFrag;
    private DetailFrag detailFrag;

    private Queries queries;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.kvizovi_akt);

        FrameLayout listPlace = findViewById(R.id.listPlace);
        FrameLayout detailPlace = findViewById(R.id.detailPlace);

        if (listPlace != null) wideScreen = true;

        //Log.d("CONNECTION", ConnectionUtils.isNetworkAvailable(KvizoviAkt.this) + "");
        //Log.d("PROGRESS","Here");

        if (!wideScreen) {
            setUpDefaultLayout();
        } else {
            setUpWideLayout();
        }

        if (ActivityCompat.checkSelfPermission(KvizoviAkt.this, Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(KvizoviAkt.this, new String[]{Manifest.permission.READ_CALENDAR}, REQUEST);
        }

    }

    private void setUpDefaultLayout() {

        spPostojeceKategorije = findViewById(R.id.spPostojeceKategorije);
        lvKvizovi = findViewById(R.id.lvKvizovi);

        initSpinner();
        initList();

        spPostojeceKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Kategorija odabranaKategorija = (Kategorija) parent.getItemAtPosition(position);
                filterList(odabranaKategorija);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                spPostojeceKategorije.setSelection(0);
            }
        });

        lvKvizovi.setLongClickable(true);
        lvKvizovi.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view,
                                           int position, long id) {
                Kviz odabraniKviz = (Kviz) parent.getItemAtPosition(position);


                if (odabraniKviz == null) {
                    openActivity(odabraniKviz, DodajKvizAkt.class, CODE_ADD);

                } else {
                    openActivity(odabraniKviz, DodajKvizAkt.class, CODE_EDIT);
                }
                return true;
            }
        });

        lvKvizovi.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Kviz odabraniKviz = (Kviz) adapterView.getItemAtPosition(i);

                if (odabraniKviz != null) {
                    Calendar current = Calendar.getInstance();
                    MyCalendarUtils myCalendarUtils = new MyCalendarUtils(KvizoviAkt.this, KvizoviAkt.this);
                    current = myCalendarUtils.roundTime(current);
                    if(myCalendarUtils.hasActiveEvents(current)){
                        showAlertDialog("U toku je dogadjaj i ne mozete igrati kviz!");
                        return;
                    }
                    int mins = myCalendarUtils.getMinutesToFirstEvent(current);
                    if(mins > getMinutes(odabraniKviz.getPitanja().size())/* && mins != -1*/) {
                        openActivity(odabraniKviz, IgrajKvizAkt.class, CODE_PLAY_QUIZ);
                    }else{
                        showAlertDialog("Imate dogadjaj u kalendaru za " + mins + " minuta!");
                        return;
                    }
                    openActivity(odabraniKviz, IgrajKvizAkt.class, CODE_PLAY_QUIZ);
                }
            }
        });
    }



    private void showAlertDialog(String message) {
        new AlertDialog.Builder(KvizoviAkt.this).setMessage(message).setNeutralButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        }).show();
    }

    private int getMinutes(int numberOfQuestions){
        return (int) Math.ceil((double)numberOfQuestions / 2);
    }

    private void openActivity(Kviz odabraniKviz, Class classToOpen, int code) {
        Intent intent = new Intent(KvizoviAkt.this, classToOpen);
        intent.putExtra("kviz", (Parcelable) odabraniKviz);
        startActivityForResult(intent, code);
    }

    private void setUpWideLayout() {
        listaFrag = new ListaFrag();
        detailFrag = new DetailFrag();

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.listPlace, listaFrag)
                .replace(R.id.detailPlace, detailFrag)
                .commit();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK) {
            super.onActivityResult(requestCode, resultCode, data);

            if (requestCode == CODE_PLAY_QUIZ) {
                if (!wideScreen) {
                    spPostojeceKategorije.setSelection(Cache.getInstance(KvizoviAkt.this, this).getCategories().indexOf(new Kategorija("Svi", "0")));
                    categoriesAdapter.notifyDataSetChanged();
                    quizesAdapter.updateConstraint(new Kategorija("Svi", "0"));
                    quizesAdapter.notifyDataSetChanged();
                }
                return;
            }

            Kviz quiz = data.getParcelableExtra("dodaniKviz");

            if (wideScreen) {
                detailFrag.processResults(requestCode == CODE_ADD, quiz);
                listaFrag.onResultRecieved();
            }
        }

        categoriesAdapter.notifyDataSetChanged();
        quizesAdapter.notifyDataSetChanged();
    }

    private void initSpinner() {
        categoriesAdapter = new CategoriesAdapter(KvizoviAkt.this, this);
        spPostojeceKategorije.setAdapter(categoriesAdapter);
        categoriesAdapter.notifyDataSetChanged();
    }

    private void initList() {
        quizesAdapter = new QuizesAdapter(this, this, lvKvizovi);
        lvKvizovi.setAdapter(quizesAdapter);
        quizesAdapter.notifyDataSetChanged();
    }

    private void filterList(Kategorija odabranaKategorija) {
        quizesAdapter.updateConstraint(odabranaKategorija);
    }


    @Override
    public void DisplayQuizesFromCategory(Kategorija k) {
        detailFrag.showQuizes(k);
    }

    @Override
    public void onQuizSelected(Kviz quiz) {
        if (quiz != null) {
            openActivity(quiz, IgrajKvizAkt.class, CODE_PLAY_QUIZ);
        }
    }

    @Override
    public void onQuizLongSelected(Kviz quiz) {
        if (quiz == null) {
            openActivity(quiz, DodajKvizAkt.class, CODE_ADD);

        } else {
            openActivity(quiz, DodajKvizAkt.class, CODE_EDIT);
        }
    }

    private boolean added = false;

    @Override
    public void update() {
        Log.d("progress", "here");
        if(!ConnectionUtils.isNetworkAvailable(KvizoviAkt.this)) {
            if(categoriesAdapter != null ) {
                categoriesAdapter.notifyDataSetChanged();
            }
            if(quizesAdapter != null) {
                quizesAdapter.notifyDataSetChanged();
            }
        }else {
            if (!added && !Cache.getInstance(KvizoviAkt.this, this).getCategories().contains(new Kategorija("Svi", "0"))) {
                added = true;
                new AddCategoryTask(KvizoviAkt.this, this).execute(new Kategorija("Svi", "0"));
            } else {
                categoriesAdapter.notifyDataSetChanged();
                quizesAdapter.notifyDataSetChanged();
            }
        }
    }

    @Override
    public void finishedAdd(String id) {
        added = true;
        Cache.getInstance(KvizoviAkt.this, this).update();
    }

    @Override
    public void finishedAdd() {

    }
}
