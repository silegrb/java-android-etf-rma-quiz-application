package ba.unsa.etf.rma.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;

import ba.unsa.etf.rma.database.Cache;
import ba.unsa.etf.rma.enums.Type;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.projekat.R;
import ba.unsa.etf.rma.tasks.AddCategoryTask;
import ba.unsa.etf.rma.utilities.Observer;

public class CategoriesAdapter extends AsyncListAdapter<Kategorija> {

    private boolean addOption;
    private Observer observer;

    public CategoriesAdapter(@NonNull Context context, Observer observer) {
        super(context, 0, Type.Category);
        this.addOption = false;
        this.observer = observer;
    }

    public CategoriesAdapter(Context context, boolean addOption, Observer observer){
        super(context, 0, Type.Category);
        this.addOption = addOption;
        this.observer = observer;
    }

    @Override
    public void add(Kategorija category) {
        new AddCategoryTask(context, this).execute(category);
    }

    public Kategorija getCategoryById(String id){
        for(Kategorija k : getObjects()){
            if(k != null && k.getDatabaseId().equals(id)){
                return k;
            }
        }

        return new Kategorija("Svi", "0");
    }

    @Override
    protected ArrayList<Kategorija> getObjects() {
        ArrayList<Kategorija> objects = Cache.getInstance(context, observer).getCategories();
        if(!addOption){
            objects.removeAll(Collections.singleton(null));
        }
        if(addOption && !objects.contains(null)){
            objects.add(null);
        }
        return objects;
    }

    @Override
    protected View initView(int position, View convertView, ViewGroup parent) {
        if(convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.sp_kategorija, parent, false);
        }

        TextView textViewKategorija = convertView.findViewById(R.id.kategorija);

        Kategorija currentItem = getItem(position);


        if (currentItem != null) {
            textViewKategorija.setText(currentItem.getNaziv());
        } else if (addOption) {
            textViewKategorija.setText(R.string.dodajKategoriju);
        }


        return convertView;
    }
}
