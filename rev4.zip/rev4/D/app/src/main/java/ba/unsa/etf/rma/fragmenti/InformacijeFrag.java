package ba.unsa.etf.rma.fragmenti;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.math.BigDecimal;
import java.math.RoundingMode;

import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.projekat.R;

public class InformacijeFrag extends Fragment {
    private TextView quizName;
    private TextView numberOfCorrectQuestions;
    private TextView numberOfRemainingQuestions;
    private TextView percentageOfCorrect;
    private Button finishPlaying;

    private Kviz quiz;

    int total, remaining, correct, incorrect;

    private InformationFragmentListener informationFragmentListener;


    public interface InformationFragmentListener {
        void finishPlaying() throws InterruptedException;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (container == null) return null;

        View view = inflater.inflate(R.layout.informacije_frag, container, false);

        quizName = view.findViewById(R.id.infNazivKviza);
        numberOfCorrectQuestions = view.findViewById(R.id.infBrojTacnihPitanja);
        numberOfRemainingQuestions = view.findViewById(R.id.infBrojPreostalihPitanja);
        numberOfCorrectQuestions = view.findViewById(R.id.infBrojTacnihPitanja);
        percentageOfCorrect = view.findViewById(R.id.infProcenatTacni);
        finishPlaying = view.findViewById(R.id.btnKraj);

        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof InformationFragmentListener) {
            informationFragmentListener = (InformationFragmentListener) context;
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        informationFragmentListener = null;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        finishPlaying.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    informationFragmentListener.finishPlaying();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });

        Bundle args = getArguments();
        quiz = args.getParcelable("quiz");
        setUpQuiz();
    }

    public void setUpQuiz() {
        quizName.setText(quiz.getNaziv());
        total = quiz.getPitanja().size();
        remaining = total;
        correct = 0;
        incorrect = 0;

        numberOfCorrectQuestions.setText(String.valueOf(correct));
        percentageOfCorrect.setText(String.valueOf(0) + "%");
    }

    public void updateInformation(boolean answeredCorrect) {
        if (answeredCorrect) correct++;
        else incorrect++;
        double percentage = correct * 100. / (correct + incorrect);
        numberOfCorrectQuestions.setText(String.valueOf(correct));
        percentageOfCorrect.setText(String.valueOf(BigDecimal.valueOf(percentage).setScale(2, RoundingMode.HALF_UP).doubleValue()) + "%");
    }

    public void updateRemaining() {
        remaining--;
        if (remaining == 0 || remaining == -1) {
            numberOfRemainingQuestions.setText(String.valueOf(0));
        } else {
            numberOfRemainingQuestions.setText(String.valueOf(remaining));
        }
    }

    public double getPercentageOfCorrect() {
        String percentage = percentageOfCorrect.getText().toString();
        percentage = percentage.substring(0, percentage.length() - 1);
        return Double.parseDouble(percentage);
    }
}
