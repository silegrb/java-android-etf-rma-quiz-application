package ba.unsa.etf.rma.aktivnosti;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

import ba.unsa.etf.rma.adapters.AnswersAdapter;
import ba.unsa.etf.rma.database.Cache;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.projekat.R;
import ba.unsa.etf.rma.tasks.AddQuestionTask;
import ba.unsa.etf.rma.utilities.ConnectionUtils;

public class DodajPitanjeAkt extends AppCompatActivity implements AddQuestionTask.AsyncAddQuestionTaskResponse {

    private EditText questionName;
    private EditText answer;
    private Button addCorrectAnswer;

    private AnswersAdapter answersAdapter;
    private ArrayList<String> arrayOfAnswers = new ArrayList<>();
    private Pitanje question;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dodaj_pitanje_akt);

        questionName = findViewById(R.id.etNaziv);
        ListView answers = findViewById(R.id.lvOdgovori);
        answer = findViewById(R.id.etOdgovor);
        Button addAnswer = findViewById(R.id.btnDodajOdgovor);
        addCorrectAnswer = findViewById(R.id.btnDodajTacan);
        Button addQuestion = findViewById(R.id.btnDodajPitanje);

        answersAdapter = new AnswersAdapter(DodajPitanjeAkt.this, arrayOfAnswers, answers);
        answers.setAdapter(answersAdapter);

        addAnswer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (validAnswer(answer.getText().toString())) {
                    arrayOfAnswers.add(answer.getText().toString());
                    answersAdapter.notifyDataSetChanged();
                    answersAdapter.dynamicallyResize();
                    answer.setText("");
                } else {
                    answer.setBackgroundColor(Color.RED);
                }
            }
        });

        addCorrectAnswer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (validAnswer(answer.getText().toString()) && answersAdapter.getCorrectPositon() == -1) {
                    arrayOfAnswers.add(answer.getText().toString());
                    answersAdapter.notifyDataSetChanged();
                    answersAdapter.dynamicallyResize();
                    answersAdapter.setCorrectPositon(arrayOfAnswers.size() - 1);
                    answersAdapter.notifyDataSetChanged();
                    answer.setText("");
                    addCorrectAnswer.setEnabled(false);
                } else {
                    answer.setBackgroundColor(Color.RED);
                }
            }
        });

        addQuestion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (arrayOfAnswers.size() != 0 && validQuestion(questionName.getText().toString()) && answersAdapter.getCorrectPositon() != -1) {
                    question = new Pitanje(questionName.getText().toString(), questionName.getText().toString(),
                            arrayOfAnswers, arrayOfAnswers.get(answersAdapter.getCorrectPositon()));

                    if(!ConnectionUtils.isNetworkAvailable(DodajPitanjeAkt.this)){
                        showAlertDialog("Pokušajte ponovo nakon što se konektujete na internet!");
                        questionName.setText("");
                        answer.setText("");
                        answersAdapter.setObjects(new ArrayList<>());
                        return;
                    }

                    addQuestionToDatabase(question);
                }else{
                    questionName.setBackgroundColor(Color.RED);
                }
            }
        });

        answers.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == answersAdapter.getCorrectPositon()) {
                    answersAdapter.setCorrectPositon(-1);
                    addCorrectAnswer.setEnabled(true);
                } else if (i < answersAdapter.getCorrectPositon()) {
                    answersAdapter.setCorrectPositon(answersAdapter.getCorrectPositon() - 1);
                }

                arrayOfAnswers.remove(i);
                answersAdapter.notifyDataSetChanged();
            }
        });

        questionName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                questionName.setBackgroundColor(Color.TRANSPARENT);
            }
        });

        answer.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                answer.setBackgroundColor(Color.TRANSPARENT);
            }
        });

    }

    private boolean uniqueQuestion(String s) {
        ArrayList<Pitanje> questions = Cache.getInstance(DodajPitanjeAkt.this).getQuestions();//getIntent().getParcelableArrayListExtra("questions");
        if (questions != null) {
            for (Pitanje question : questions) {
                if (question != null && question.getNaziv().equals(s)) return false;
            }
        }
        return true;
    }

    private boolean uniqueAnswer(String s) {
        return !answersAdapter.contains(s);
    }


    private boolean validQuestion(String s) {
        return !s.isEmpty() && uniqueQuestion(s);
    }

    private boolean validAnswer(String s) {
        return !s.isEmpty() && uniqueAnswer(s);
    }

    private void addQuestionToDatabase(Pitanje question) {
        new AddQuestionTask(DodajPitanjeAkt.this, this).execute(question);
    }

    @Override
    public void finishedQuestionAdd(String id) {
        Cache.getInstance(DodajPitanjeAkt.this).update();
        question.setDatabaseId(id);
        Intent intent = new Intent();
        intent.putExtra("addedQuestion", (Parcelable) question);
        setResult(Activity.RESULT_OK, intent);
        finish();
    }

    public void showAlertDialog(String message) {
        new AlertDialog.Builder(DodajPitanjeAkt.this).setMessage(message).
                setNeutralButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                }).show();

    }
}
