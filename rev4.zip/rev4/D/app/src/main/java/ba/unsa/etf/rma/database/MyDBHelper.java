package ba.unsa.etf.rma.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.Nullable;
import android.util.Log;

public class MyDBHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "quizes.db";
    public static final int DATABASE_VERSION = 1;


    public MyDBHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        Log.d("Progress", "CREATING TABLES");
        final String SQL_CREATE_CATEGORIES_TABLE = "CREATE TABLE " +
                Contract.CategoryEntry.TABLE_NAME + " (" +
                Contract.CategoryEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                Contract.CategoryEntry.COLUMN_NAME + " TEXT NOT NULL, " +
                Contract.CategoryEntry.COLUMN_ICON + " TEXT NOT NULL, " +
                Contract.CategoryEntry.COLUMN_FIREBASE + " TEXT NOT NULL" +
                ");";

        final String SQL_CREATE_QUESTIONS_TABLE = "CREATE TABLE " +
                Contract.QuestionEntry.TABLE_NAME + " (" +
                Contract.QuestionEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                Contract.QuestionEntry.COLUMN_TEXT + " TEXT NOT NULL, " +
                Contract.QuestionEntry.COLUMN_CORRECT + " TEXT NOT NULL, " +
                Contract.QuestionEntry.COLUMN_FIREBASE + " TEXT NOT NULL" +
                ");";

        final String SQL_CREATE_ANSWERS_TABLE = "CREATE TABLE " +
                Contract.AnswerEntry.TABLE_NAME + " (" +
                Contract.AnswerEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                Contract.AnswerEntry.COLUMN_TEXT + " TEXT NOT NULL, " +
                Contract.AnswerEntry.COLUMN_QUESTION + " INTEGER, " +
                "FOREIGN KEY (" + Contract.AnswerEntry.COLUMN_QUESTION + ") REFERENCES " + Contract.QuestionEntry.TABLE_NAME + "("+ Contract.QuestionEntry._ID + ")" +
                ");";

        final String SQL_CREATE_QUIZ_TABLE = "CREATE TABLE " +
                Contract.QuizEntry.TABLE_NAME + " (" +
                Contract.QuizEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                Contract.QuizEntry.COLUMN_NAME + " TEXT NOT NULL, " +
                Contract.QuizEntry.COLUMN_CATEGORY + " INTEGER, " +
                Contract.QuizEntry.COLUMN_FIREBASE + " TEXT NOT NULL, " +
                "FOREIGN KEY (" + Contract.QuizEntry.COLUMN_CATEGORY + ") REFERENCES " + Contract.CategoryEntry.TABLE_NAME + "("+ Contract.CategoryEntry._ID + ")" +
                ");";

        final String SQL_CREATE_QUIZ_QUESTIONS_TABLE = "CREATE TABLE " +
                Contract.QuizQuestionEntry.TABLE_NAME + " (" +
                Contract.QuizQuestionEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                Contract.QuizQuestionEntry.COLUMN_QUESTION + " INTEGER, " +
                Contract.QuizQuestionEntry.COLUMN_QUIZ + " INTEGER, " +
                "FOREIGN KEY (" + Contract.QuizQuestionEntry.COLUMN_QUIZ + ") REFERENCES " + Contract.QuizEntry.TABLE_NAME + "("+ Contract.QuizEntry._ID + "), " +
                "FOREIGN KEY (" + Contract.QuizQuestionEntry.COLUMN_QUESTION + ") REFERENCES " + Contract.QuestionEntry.TABLE_NAME + "("+ Contract.QuestionEntry._ID + ")" +
                ");";

        final String SQL_CREATE_RANGLIST_TABLE = "CREATE TABLE " +
                Contract.RangListEntry.TABLE_NAME + " (" +
                Contract.RangListEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                Contract.RangListEntry.COLUMN_QUIZ + " INTEGER, " +
                Contract.RangListEntry.COLUMN_FIREBASE + " TEXT, " +
                "FOREIGN KEY (" + Contract.RangListEntry.COLUMN_QUIZ + ") REFERENCES " + Contract.QuestionEntry.TABLE_NAME + "("+ Contract.QuizEntry._ID + ")" +
                ");";

        final String SQL_CREATE_RANGLISTITEM_TABLE = "CREATE TABLE " +
                Contract.RangListItemEntry.TABLE_NAME + " (" +
                Contract.RangListItemEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                Contract.RangListItemEntry.COLUMN_POSITION + " INTEGER NOT NULL, " +
                Contract.RangListItemEntry.COLUMN_PLAYER + " TEXT NOT NULL, " +
                Contract.RangListItemEntry.COLUMN_PERCENTAGE + " REAL NOT NULL, " +
                Contract.RangListItemEntry.COLUMN_RANG_LIST + " INTEGER," +
                "FOREIGN KEY (" + Contract.RangListItemEntry.COLUMN_RANG_LIST + ") REFERENCES " + Contract.RangListEntry.TABLE_NAME + "("+ Contract.RangListEntry._ID + ")" +
                ");";




        sqLiteDatabase.execSQL(SQL_CREATE_CATEGORIES_TABLE);
        sqLiteDatabase.execSQL(SQL_CREATE_QUESTIONS_TABLE);
        sqLiteDatabase.execSQL(SQL_CREATE_ANSWERS_TABLE);
        sqLiteDatabase.execSQL(SQL_CREATE_QUIZ_TABLE);
        sqLiteDatabase.execSQL(SQL_CREATE_QUIZ_QUESTIONS_TABLE);
        sqLiteDatabase.execSQL(SQL_CREATE_RANGLIST_TABLE);
        sqLiteDatabase.execSQL(SQL_CREATE_RANGLISTITEM_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + Contract.RangListItemEntry.TABLE_NAME);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + Contract.RangListEntry.TABLE_NAME);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + Contract.QuizQuestionEntry.TABLE_NAME);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + Contract.QuizEntry.TABLE_NAME);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + Contract.AnswerEntry.TABLE_NAME);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + Contract.QuestionEntry.TABLE_NAME);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + Contract.CategoryEntry.TABLE_NAME);
        onCreate(sqLiteDatabase);
    }


}
