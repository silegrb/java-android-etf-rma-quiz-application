package ba.unsa.etf.rma.database;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;

import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.klase.RangList;

public class Queries {
    private SQLiteDatabase database;

    public Queries(SQLiteDatabase database){
        this.database = database;
    }

    public long insertCategory(Kategorija category){
        long id = getCategoryId(category);
        if(id != -1) {
            return id; //ako vec postoji nemoj dodat
        }


        ContentValues cv = new ContentValues();
        cv.put(Contract.CategoryEntry.COLUMN_NAME, category.getNaziv());
        cv.put(Contract.CategoryEntry.COLUMN_ICON, category.getId());
        cv.put(Contract.CategoryEntry.COLUMN_FIREBASE, category.getDatabaseId());

        id = database.insert(Contract.CategoryEntry.TABLE_NAME, null, cv);
        return id;
    }

    public long  insertQuestion(Pitanje question){
        long id = getQuestionId(question);
        if(id != -1) {
            return id;
        }
        ContentValues cv = new ContentValues();
        cv.put(Contract.QuestionEntry.COLUMN_TEXT, question.getNaziv());
        cv.put(Contract.QuestionEntry.COLUMN_CORRECT, question.getTacan());
        cv.put(Contract.QuestionEntry.COLUMN_FIREBASE, question.getDatabaseId());

        id = database.insert(Contract.QuestionEntry.TABLE_NAME, null, cv);

        for(int i = 0; i < question.getOdgovori().size(); i++){
            insertAnswer(question.getOdgovori().get(i), id);
        }

        return id;
    }

    public void insertAnswer(String answer, long questionId){
        ContentValues cv = new ContentValues();
        cv.put(Contract.AnswerEntry.COLUMN_TEXT, answer);
        cv.put(Contract.AnswerEntry.COLUMN_QUESTION, questionId);

        database.insert(Contract.AnswerEntry.TABLE_NAME, null, cv);
    }

    public void insertQuiz(Kviz quiz){
        long categoryId = getCategoryId(quiz.getKategorija());

        if(categoryId == -1){
            categoryId = insertCategory(quiz.getKategorija());
        }

        long id = getQuizId(quiz);
        if(id != -1) {
            updateQuiz(quiz);
            return;
        }

        ContentValues cv = new ContentValues();
        cv.put(Contract.QuizEntry.COLUMN_NAME, quiz.getNaziv());
        cv.put(Contract.QuizEntry.COLUMN_CATEGORY, categoryId);
        cv.put(Contract.QuizEntry.COLUMN_FIREBASE, quiz.getDatabaseId());

        id = database.insert(Contract.QuizEntry.TABLE_NAME, null, cv);

        for(int i = 0; i < quiz.getPitanja().size(); i++){
            long qId =  getQuestionId(quiz.getPitanja().get(i));
            if(qId == -1){
                qId = insertQuestion(quiz.getPitanja().get(i));
            }

            long qqId = getQuizQuestionId(id, qId);
            if(qqId == -1){
                insertQuizQuestion(id, qId);
            }
        }
    }

    public void insertQuizQuestion(long quiz, long question){
        long qqId = getQuizQuestionId(quiz, question);
        if(qqId != -1){
            return;
        }
        ContentValues cv = new ContentValues();
        cv.put(Contract.QuizQuestionEntry.COLUMN_QUIZ, quiz);
        cv.put(Contract.QuizQuestionEntry.COLUMN_QUESTION, question);

        database.insert(Contract.QuizQuestionEntry.TABLE_NAME, null, cv);
    }

    public void insertRangList(RangList rangList){
        long id = getRangListId(rangList);
        if(id != -1){
            updateRangList(rangList);
            return;
        }

        long quizId = getQuizId(rangList.getQuiz());
        ContentValues cv = new ContentValues();
        cv.put(Contract.RangListEntry.COLUMN_QUIZ, quizId);
        cv.put(Contract.RangListEntry.COLUMN_FIREBASE, rangList.getDatabaseId());
        id = database.insert(Contract.RangListEntry.TABLE_NAME, null, cv);

        for(int i = 0; i < rangList.getList().size(); i++){
            RangList.Tuple t = rangList.getList().get(i);
            ContentValues cv1 = new ContentValues();
            cv1.put(Contract.RangListItemEntry.COLUMN_POSITION,t.getPosition());
            cv1.put(Contract.RangListItemEntry.COLUMN_PERCENTAGE, t.getPercentage());
            cv1.put(Contract.RangListItemEntry.COLUMN_PLAYER, t.getPlayer());
            cv1.put(Contract.RangListItemEntry.COLUMN_RANG_LIST, id);

            database.insert(Contract.RangListItemEntry.TABLE_NAME, null, cv1);
        }
    }

    private long getQuizId(Kviz quiz) {
        String[] columns = new String[]{Contract.QuizEntry._ID, Contract.QuizEntry.COLUMN_NAME};
        String where = Contract.QuizEntry.COLUMN_FIREBASE + " = ?";
        String[] whereArgs = new String[]{quiz.getDatabaseId()};

        Cursor cursor = database.query(Contract.QuizEntry.TABLE_NAME, columns, where, whereArgs, null, null, null);
        long id = -1;
        if (cursor.moveToFirst()){
            id = cursor.getLong(cursor.getColumnIndex(Contract.QuizEntry._ID));
        }

        cursor.close();
        return id;
    }

    private long getQuizQuestionId(long quizId, long questionId) {
        String[] columns = new String[]{Contract.QuizQuestionEntry._ID, Contract.QuizQuestionEntry.COLUMN_QUESTION, Contract.QuizQuestionEntry.COLUMN_QUIZ};
        String where = Contract.QuizQuestionEntry.COLUMN_QUESTION + " = ? AND " + Contract.QuizQuestionEntry.COLUMN_QUIZ + " = ?";
        String[] whereArgs = new String[]{String.valueOf(questionId), String.valueOf(quizId)};

        Cursor cursor = database.query(Contract.QuizQuestionEntry.TABLE_NAME, columns, where, whereArgs, null, null, null);
        long id = -1;
        if (cursor.moveToFirst()){
            id = cursor.getLong(cursor.getColumnIndex(Contract.QuizQuestionEntry._ID));
        }

        cursor.close();
        return id;
    }

    private long getQuestionId(Pitanje pitanje) {
        String[] columns = new String[]{Contract.QuestionEntry._ID};
        String where = Contract.QuestionEntry.COLUMN_FIREBASE + "= ?";
        String[] whereArgs = new String[]{pitanje.getDatabaseId()};

        Cursor cursor = database.query(Contract.QuestionEntry.TABLE_NAME, columns, where, whereArgs, null, null, null);
        long id = -1;
        if (cursor.moveToFirst()){
            id = cursor.getLong(cursor.getColumnIndex(Contract.QuestionEntry._ID));
        }

        cursor.close();
        //Log.d("ID", id + "");
        return id;
    }

    private long getCategoryId(Kategorija kategorija) {
        String[] columns = new String[]{Contract.CategoryEntry._ID, Contract.CategoryEntry.COLUMN_NAME};
        String where = Contract.CategoryEntry.COLUMN_NAME + "= ?";
        String[] whereArgs = new String[]{kategorija.getNaziv()};

        Cursor cursor = database.query(Contract.CategoryEntry.TABLE_NAME, columns, where, whereArgs, null, null, null);
        long id = -1;
        if (cursor.moveToFirst()){
            //Log.d("Progres", "in category id");
            id = cursor.getLong(cursor.getColumnIndex(Contract.CategoryEntry._ID));
        }

        cursor.close();
        return id;
    }

    private long getRangListId(RangList rangList) {
        String[] columns = new String[]{Contract.RangListEntry._ID, Contract.RangListEntry.COLUMN_FIREBASE};
        String where = Contract.RangListEntry.COLUMN_QUIZ + "= ?";
        String[] whereArgs = new String[]{String.valueOf(getQuizId(rangList.getQuiz()))};

        Cursor cursor = database.query(Contract.RangListEntry.TABLE_NAME, columns, where, whereArgs, null, null, null);
        long id = -1;
        if (cursor.moveToFirst() ){
            id = cursor.getLong(cursor.getColumnIndex(Contract.RangListEntry._ID));
        }

        cursor.close();
        return id;
    }

    private long getRangListItemId(RangList.Tuple t, long rangListId){
        String[] columns = new String[]{Contract.RangListItemEntry._ID};
        String where = Contract.RangListItemEntry.COLUMN_RANG_LIST + " = ? AND " + Contract.RangListItemEntry.COLUMN_PLAYER + " = ? AND " +
                 Contract.RangListItemEntry.COLUMN_PERCENTAGE + " = ?";
        String[] whereArgs = new String[]{String.valueOf(rangListId), t.getPlayer(), String.valueOf(t.getPercentage())};

        Cursor cursor = database.query(Contract.RangListItemEntry.TABLE_NAME, columns, where, whereArgs, null, null, null);
        long id = -1;
        if (cursor.moveToFirst()){
            id = cursor.getLong(cursor.getColumnIndex(Contract.RangListItemEntry._ID));
        }

        cursor.close();
        return id;
    }


    public void updateQuiz(Kviz quiz){

        long categoryId = getCategoryId(quiz.getKategorija());

        if(categoryId == -1){
            categoryId = insertCategory(quiz.getKategorija());
        }
        //Log.d("PROGRESS:", "UPDATING QUIZ " + quiz.getNaziv() + " k: " + categoryId);
        long id = getQuizId(quiz);

        ContentValues cv = new ContentValues();
        cv.put(Contract.QuizEntry.COLUMN_NAME, quiz.getNaziv());
        cv.put(Contract.QuizEntry.COLUMN_CATEGORY, categoryId);
        cv.put(Contract.QuizEntry.COLUMN_FIREBASE, quiz.getDatabaseId());

        String where = Contract.QuizEntry._ID + " = ?";
        String[] whereArgs = new String[]{String.valueOf(id)};

        database.update(Contract.QuizEntry.TABLE_NAME, cv, where, whereArgs);

        for(int i = 0; i < quiz.getPitanja().size(); i++){
            long qId =  getQuestionId(quiz.getPitanja().get(i));
            if(qId == -1){
                qId = insertQuestion(quiz.getPitanja().get(i));
            }

            long qqId = getQuizQuestionId(id, qId);
            if(qqId == -1){
                insertQuizQuestion(id, qId);
            }
        }

        ArrayList<Pitanje> pitanja = getAllQuestionsForQuiz(id);
        for(int i = 0; i < pitanja.size(); i++){
            if(!quiz.getPitanja().contains(pitanja.get(i))){
                deleteQuestionForQuiz(getQuestionId(pitanja.get(i)), id);
            }
        }
    }

    private void deleteQuestionForQuiz(long questionId, long quizId) {
        String where = Contract.QuizQuestionEntry.COLUMN_QUIZ + " = ? AND " + Contract.QuizQuestionEntry.COLUMN_QUESTION + " = ?";
        String[] whereArgs = new String[]{String.valueOf(quizId), String.valueOf(questionId)};

        database.delete(Contract.QuizQuestionEntry.TABLE_NAME, where, whereArgs);
        //Log.d("progress", "DELETING QUESTION FROM QUIZ " + questionId + " " + quizId);
    }

    private void updateRangList(RangList rangList) {
        long id = getRangListId(rangList);

        long quizId = getQuizId(rangList.getQuiz());
        ContentValues cv = new ContentValues();
        cv.put(Contract.RangListEntry.COLUMN_QUIZ, quizId);
        cv.put(Contract.RangListEntry.COLUMN_FIREBASE, rangList.getDatabaseId());

        String where = Contract.RangListEntry._ID + " = ?";
        String[] whereArgs = new String[]{String.valueOf(id)};

        database.update(Contract.RangListEntry.TABLE_NAME, cv, where, whereArgs);

        for(int i = 0; i < rangList.getList().size(); i++){
            RangList.Tuple t = rangList.getList().get(i);

            long itemId = getRangListItemId(t, id);
            Log.d("Itemid", itemId + ""+ t.getPlayer());
            ContentValues cv1 = new ContentValues();
            cv1.put(Contract.RangListItemEntry.COLUMN_POSITION, t.getPosition());
            cv1.put(Contract.RangListItemEntry.COLUMN_PERCENTAGE, t.getPercentage());
            cv1.put(Contract.RangListItemEntry.COLUMN_PLAYER, t.getPlayer());
            cv1.put(Contract.RangListItemEntry.COLUMN_RANG_LIST, id);

            if(itemId == -1) {
                database.insert(Contract.RangListItemEntry.TABLE_NAME, null, cv1);
            }else {
                String where1 = Contract.RangListItemEntry._ID + " = ?";
                String[] whereArgs1 = new String[]{String.valueOf(itemId)};
                Log.d("Updating entry", t.getPlayer() + " " +t.getPosition());
                database.update(Contract.RangListItemEntry.TABLE_NAME, cv1, where1, whereArgs1);
            }
        }
    }

    public ArrayList<Kviz> getAllQuizes(){
        ArrayList<Kviz> quizes = new ArrayList<>();
        Cursor  cursor = database.rawQuery("select * from " + Contract.QuizEntry.TABLE_NAME,null);
        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(cursor.getColumnIndex(Contract.QuizEntry._ID));
                String name = cursor.getString(cursor.getColumnIndex(Contract.QuizEntry.COLUMN_NAME));
                long category = cursor.getLong(cursor.getColumnIndex(Contract.QuizEntry.COLUMN_CATEGORY));
                String firebase = cursor.getString(cursor.getColumnIndex(Contract.CategoryEntry.COLUMN_FIREBASE));

                Kviz quiz = new Kviz(name, null, null, firebase, id);

                Kategorija c = getCategoryById(category);
                quiz.setKategorija(c);

                ArrayList<Pitanje> q = getAllQuestionsForQuiz(id);
                quiz.setPitanja(q);

                quizes.add(quiz);
            }while (cursor.moveToNext());
        }

        cursor.close();
        return quizes;
    }

    public ArrayList<Kategorija> getAllCategories(){
        ArrayList<Kategorija> categories = new ArrayList<>();
        Cursor  cursor = database.rawQuery("select * from " + Contract.CategoryEntry.TABLE_NAME,null);
        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(cursor.getColumnIndex(Contract.CategoryEntry._ID));
                String name = cursor.getString(cursor.getColumnIndex(Contract.CategoryEntry.COLUMN_NAME));
                String icon = cursor.getString(cursor.getColumnIndex(Contract.CategoryEntry.COLUMN_ICON));
                String firebase = cursor.getString(cursor.getColumnIndex(Contract.CategoryEntry.COLUMN_FIREBASE));

                categories.add(new Kategorija(name, icon, firebase, id));
            }while (cursor.moveToNext());
        }

        cursor.close();
        return categories;
    }

    public ArrayList<Pitanje> getAllQuestions(){
        ArrayList<Pitanje> questions = new ArrayList<>();
        Cursor  cursor = database.rawQuery("select * from " + Contract.QuestionEntry.TABLE_NAME,null);
        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(cursor.getColumnIndex(Contract.QuizQuestionEntry._ID));
                String text = cursor.getString(cursor.getColumnIndex(Contract.QuestionEntry.COLUMN_TEXT));
                String correct = cursor.getString(cursor.getColumnIndex(Contract.QuestionEntry.COLUMN_CORRECT));
                String firebase = cursor.getString(cursor.getColumnIndex(Contract.QuestionEntry.COLUMN_FIREBASE));
                Pitanje question = new Pitanje(text, text, null, correct, firebase, id);

                ArrayList<String> answers = getAllAnswersForQuestion(question);
                question.setOdgovori(answers);

                questions.add(question);
            }while (cursor.moveToNext());
        }

        cursor.close();
        return questions;
    }

    public  ArrayList<Pitanje> getAllQuestionsForQuiz(long quiz){
        ArrayList<Pitanje> questions = new ArrayList<>();
        String[] columns1 = new String[]{Contract.QuizQuestionEntry.COLUMN_QUESTION};
        String where1 = Contract.QuizQuestionEntry.COLUMN_QUIZ + " = ?";
        String[] whereArgs1 = new String[]{String.valueOf(quiz)};

        Cursor cursor1 = database.query(Contract.QuizQuestionEntry.TABLE_NAME, columns1, where1, whereArgs1, null, null, null);
        if(cursor1.moveToFirst()) {
            do {
                long questionId = cursor1.getLong(cursor1.getColumnIndex(Contract.QuizQuestionEntry.COLUMN_QUESTION));
                String[] columns = new String[]{Contract.QuestionEntry.COLUMN_TEXT, Contract.QuestionEntry._ID, Contract.QuestionEntry.COLUMN_CORRECT, Contract.QuestionEntry.COLUMN_FIREBASE};
                String where = Contract.QuestionEntry._ID + " = ?";
                String[] whereArgs = new String[]{String.valueOf(questionId)};

                Cursor cursor = database.query(Contract.QuestionEntry.TABLE_NAME, columns, where, whereArgs, null, null, null);

                if (cursor.moveToFirst()) {
                    //do {
                        long id = cursor.getLong(cursor.getColumnIndex(Contract.QuestionEntry._ID));
                        String text = cursor.getString(cursor.getColumnIndex(Contract.QuestionEntry.COLUMN_TEXT));
                        String correct = cursor.getString(cursor.getColumnIndex(Contract.QuestionEntry.COLUMN_CORRECT));
                        String firebase = cursor.getString(cursor.getColumnIndex(Contract.QuestionEntry.COLUMN_FIREBASE));
                        Pitanje question = new Pitanje(text, text, null, correct, firebase, id);

                        ArrayList<String> answers = getAllAnswersForQuestion(question);
                        question.setOdgovori(answers);

                        questions.add(question);
                   // } while (cursor.moveToNext());
                }

                cursor.close();
            }while (cursor1.moveToNext());
        }
        cursor1.close();
        return questions;
    }

    public ArrayList<String> getAllAnswersForQuestion(Pitanje question){
        String[] columns = new String[]{Contract.AnswerEntry.COLUMN_TEXT, Contract.AnswerEntry.COLUMN_QUESTION};
        String where = Contract.AnswerEntry.COLUMN_QUESTION + " = ?";
        String[] whereArgs = new String[]{String.valueOf(question.getSqlId())};

        ArrayList<String> answers = new ArrayList<>();
        Cursor cursor = database.query(Contract.AnswerEntry.TABLE_NAME, columns, where, whereArgs, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                String text = cursor.getString(cursor.getColumnIndex(Contract.AnswerEntry.COLUMN_TEXT));

                answers.add(text);
            }while (cursor.moveToNext());
        }

        cursor.close();
        return answers;
    }

    public Kategorija getCategoryById(long id){
        String[] columns = new String[]{Contract.CategoryEntry.COLUMN_NAME, Contract.CategoryEntry.COLUMN_ICON, Contract.CategoryEntry._ID, Contract.CategoryEntry.COLUMN_FIREBASE};
        String where = Contract.CategoryEntry._ID + " = ?";
        String[] whereArgs = new String[]{String.valueOf(id)};

        Cursor cursor = database.query(Contract.CategoryEntry.TABLE_NAME, columns, where, whereArgs, null, null, null);
        if(cursor.moveToFirst()){
            String name = cursor.getString(cursor.getColumnIndex(Contract.CategoryEntry.COLUMN_NAME));
            String icon = cursor.getString(cursor.getColumnIndex(Contract.CategoryEntry.COLUMN_ICON));
            String firebase = cursor.getString(cursor.getColumnIndex(Contract.CategoryEntry.COLUMN_FIREBASE));

            return new Kategorija(name, icon, firebase, id);
        }
        cursor.close();
        return null;
    }

    public RangList getRangListForQuiz(Kviz quiz){
        long quizId = getQuizId(quiz);
        String[] columns = new String[]{Contract.RangListEntry._ID, Contract.RangListEntry.COLUMN_FIREBASE};
        String where = Contract.RangListEntry.COLUMN_QUIZ + " = ?";
        String[] whereArgs = new String[]{String.valueOf(quizId)};

        Cursor cursor = database.query(Contract.RangListEntry.TABLE_NAME, columns, where, whereArgs, null, null, null);
        if(cursor.moveToFirst()){
            long id = cursor.getLong(cursor.getColumnIndex(Contract.RangListEntry._ID));
            String firebase = cursor.getString(cursor.getColumnIndex(Contract.RangListEntry.COLUMN_FIREBASE));

            RangList rangList = new RangList(quiz, firebase, id);
            ArrayList<RangList.Tuple> items = getRangListItemsForRangList(rangList);
            /*for(RangList.Tuple t : items){
                //Log.d("queries", t.getPosition() + " " + t.getPlayer());
                rangList.add(t.getPosition(), t.getPlayer(), t.getPercentage());
            }*/
            rangList.setLista(items);
            return rangList;
        }
        return null;
    }

    private ArrayList<RangList.Tuple> getRangListItemsForRangList(RangList rangList) {
        ArrayList<RangList.Tuple> items = new ArrayList<>();

        String[] columns = new String[]{Contract.RangListItemEntry.COLUMN_POSITION, Contract.RangListItemEntry.COLUMN_PLAYER, Contract.RangListItemEntry.COLUMN_PERCENTAGE};
        String where = Contract.RangListItemEntry.COLUMN_RANG_LIST + " = ?";
        String[] whereArgs = new String[]{String.valueOf(rangList.getSqlId())};

        Cursor cursor = database.query(Contract.RangListItemEntry.TABLE_NAME, columns, where, whereArgs, null, null, null);

        if(cursor.moveToFirst()){
            do{
                int position = cursor.getInt(cursor.getColumnIndex(Contract.RangListItemEntry.COLUMN_POSITION));
                String player = cursor.getString(cursor.getColumnIndex(Contract.RangListItemEntry.COLUMN_PLAYER));
                double percentage = cursor.getDouble(cursor.getColumnIndex(Contract.RangListItemEntry.COLUMN_PERCENTAGE));

                items.add(new RangList(rangList.getQuiz()). new Tuple(position, player, percentage));
            }while (cursor.moveToNext());
        }

        cursor.close();
        return items;
    }

    public ArrayList<RangList> getAllRangLists() {
        ArrayList<RangList> result = new ArrayList<>();
        ArrayList<Kviz> quizes = getAllQuizes();
        for(Kviz k : quizes){
            if(k != null) {
                result.add(getRangListForQuiz(k));
            }
        }

        return result;
    }

    public ArrayList<Kviz> getAllQuizesForCategory(Kategorija constraint) {
        ArrayList<Kviz> all = getAllQuizes();
        ArrayList<Kviz> result = new ArrayList<>();
        if(constraint.equals(new Kategorija("Svi", "0"))){
            return all;
        }else{
            for(Kviz k : all){
                if(k != null && k.getKategorija() != null && k.getKategorija().equals(constraint)){
                    result.add(k);
                }
            }
        }

        return result;
    }
}
