package ba.unsa.etf.rma.adapters;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.projekat.R;

public class InQuizQuestionsAdapter extends ArrayAdapter<Pitanje> /*implements AddQuestionTask.AsyncAddQuestionTaskResponse */ {
    private List<Pitanje> pitanja;
    private ListView listView;


    public InQuizQuestionsAdapter(Context context, ArrayList<Pitanje> pitanja, ListView listView) {
        super(context, 0);
        this.pitanja = new ArrayList<>();
        if (pitanja == null) {
            pitanja = new ArrayList<>();
        }
        this.pitanja.addAll(pitanja);
        this.pitanja.add(null);
        this.listView = listView;
        setListViewHeightBasedOnChildren(listView);
        notifyDataSetChanged();
    }

    @Override
    public void add(Pitanje object) {
        pitanja.removeAll(Collections.singleton(null));
        notifyDataSetChanged();
        setListViewHeightBasedOnChildren(listView);
        pitanja.add(object);
        notifyDataSetChanged();
        setListViewHeightBasedOnChildren(listView);
        pitanja.add(null);
        setListViewHeightBasedOnChildren(listView);
        notifyDataSetChanged();
    }

    @Override
    public void remove(Pitanje object) {
        pitanja.remove(object);
        notifyDataSetChanged();
        setListViewHeightBasedOnChildren(listView);
    }

    public void setQuestions(ArrayList<Pitanje> questions) {
        pitanja.clear();
        pitanja.addAll(questions);
        pitanja.removeAll(Collections.singleton(null));
        pitanja.add(null);
        notifyDataSetChanged();
        setListViewHeightBasedOnChildren(listView);
    }

    @Override
    public int getCount() {
        return pitanja.size();
    }

    @Override
    public Pitanje getItem(int position) {
        return pitanja.get(position);
    }

    public ArrayList<Pitanje> getItems() {
        return (ArrayList<Pitanje>) pitanja;

    }

    @Override
    public long getItemId(int position) {
        return pitanja.indexOf(getItem(position));
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return initView(position, convertView, parent);
    }

    private View initView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.lv_kviz, parent, false);
        }

        ImageView ikonaPitanja = convertView.findViewById(R.id.ikonaKategorije);
        TextView nazivPitanja = convertView.findViewById(R.id.imeKviza);

        Pitanje currentItem = getItem(position);
        if (currentItem != null) {
            nazivPitanja.setText(currentItem.getNaziv());
            ikonaPitanja.setBackgroundColor(Color.TRANSPARENT);
        } else {
            ikonaPitanja.setBackgroundResource(R.drawable.add_button);
            nazivPitanja.setText(R.string.dodajPitanje);
        }
        return convertView;
    }

    public void setListViewHeightBasedOnChildren(ListView listView) {
        int totalHeight = 0;
        int desiredWidth = View.MeasureSpec.makeMeasureSpec(listView.getWidth(), View.MeasureSpec.AT_MOST);
        for (int i = 0; i < getCount(); i++) {
            View listItem = getView(i, null, listView);
            listItem.measure(desiredWidth, View.MeasureSpec.UNSPECIFIED);
            totalHeight += listItem.getMeasuredHeight();
        }

        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight + (listView.getDividerHeight() * (getCount() - 1));
        listView.setLayoutParams(params);
        listView.requestLayout();
    }
}
