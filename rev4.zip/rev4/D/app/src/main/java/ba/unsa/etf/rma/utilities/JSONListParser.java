package ba.unsa.etf.rma.utilities;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;

import ba.unsa.etf.rma.database.Cache;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.klase.RangList;

public class JSONListParser {

    private Context context;

    public JSONListParser(Context context) {
        this.context = context;
    }

    public ArrayList<Kategorija> parseCategories(String response) {
        ArrayList<Kategorija> results = new ArrayList<>();

        try {
            JSONObject jsonObject1 = new JSONObject(response);
            if (!jsonObject1.has("documents")) return results;
            JSONArray categories = jsonObject1.getJSONArray("documents");
            for (int i = 0; i < categories.length(); i++) {
                JSONObject jsonObject2 = categories.getJSONObject(i);
                String dbName = jsonObject2.getString("name");
                String[] array = dbName.split("/");
                String databaseId = array[array.length - 1];
                JSONObject jsonObject3 = jsonObject2.getJSONObject("fields");
                JSONObject jsonObject4 = jsonObject3.getJSONObject("naziv");
                JSONObject jsonObject5 = jsonObject3.getJSONObject("idIkonice");
                String name = jsonObject4.getString("stringValue");
                int idIkonice = jsonObject5.getInt("integerValue");
                Kategorija category = new Kategorija(name, String.valueOf(idIkonice));
                category.setDatabaseId(databaseId);
                results.add(category);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return results;
    }

    /*public ArrayList<Kviz> parseQuizes(String response) {
        ArrayList<Kviz> result = new ArrayList<>();
        try {
            JSONObject jsonObject1 = new JSONObject(response);
            JSONArray quizes = jsonObject1.getJSONArray("documents");
            for (int i = 0; i < quizes.length(); i++){
                JSONObject jsonObject2 = quizes.getJSONObject(i);
                String dbName = jsonObject2.getString("name");
                String[] array = dbName.split("/");
                String databaseId = array[array.length - 1];
                JSONObject jsonObject3 = jsonObject2.getJSONObject("fields");
                JSONObject jsonObject4 = jsonObject3.getJSONObject("naziv");
                JSONObject jsonObject5 = jsonObject3.getJSONObject("idKategorije");
                String name = jsonObject4.getString("stringValue");
                String categoryId = jsonObject5.getString("stringValue");
                JSONObject jsonObject6 = jsonObject3.getJSONObject("pitanja");
                JSONObject jsonObject7 = jsonObject6.getJSONObject("arrayValue");
                ArrayList<Pitanje> questions = new ArrayList<>();
                if(jsonObject7.has("values")) {
                    JSONArray jsonObject8 = jsonObject7.getJSONArray("values");
                    for (int j = 0; j < jsonObject8.length(); j++) {
                        JSONObject jsonObject9 = jsonObject8.getJSONObject(j);
                        String questionId = jsonObject9.getString("stringValue");
                        questions.add(Cache.getInstance(context).getQuestionById(questionId));
                        //napraviti pitanje preko id
                    }
                }
                //napraviti kategoriju preko id
                Kategorija category = Cache.getInstance(context).getCategoryById(categoryId);
                Kviz quiz = new Kviz(name, questions, category);
                quiz.setDatabaseId(databaseId);
                result.add(quiz);
            }
        }catch (JSONException e){
            e.printStackTrace();
        }
        return result;
    }*/

    public ArrayList<Kviz> parseQuizes(String response) {
        ArrayList<Kviz> result = new ArrayList<>();
        try {
            JSONArray quizes = new JSONArray(response);
            for (int i = 0; i < quizes.length(); i++) {
                JSONObject jsonObject22 = quizes.getJSONObject(i);
                if (!jsonObject22.has("document")) break;
                JSONObject jsonObject2 = jsonObject22.getJSONObject("document");
                String dbName = jsonObject2.getString("name");
                String[] array = dbName.split("/");
                String databaseId = array[array.length - 1];
                JSONObject jsonObject3 = jsonObject2.getJSONObject("fields");
                JSONObject jsonObject4 = jsonObject3.getJSONObject("naziv");
                JSONObject jsonObject5 = jsonObject3.getJSONObject("idKategorije");
                String name = jsonObject4.getString("stringValue");
                String categoryId = jsonObject5.getString("stringValue");
                JSONObject jsonObject6 = jsonObject3.getJSONObject("pitanja");
                JSONObject jsonObject7 = jsonObject6.getJSONObject("arrayValue");
                ArrayList<Pitanje> questions = new ArrayList<>();
                if (jsonObject7.has("values")) {
                    JSONArray jsonObject8 = jsonObject7.getJSONArray("values");
                    for (int j = 0; j < jsonObject8.length(); j++) {
                        JSONObject jsonObject9 = jsonObject8.getJSONObject(j);
                        String questionId = jsonObject9.getString("stringValue");
                        questions.add(Cache.getInstance(context).getQuestionById(questionId));
                    }
                }
                Kategorija category = Cache.getInstance(context).getCategoryById(categoryId);
                Kviz quiz = new Kviz(name, questions, category);
                quiz.setDatabaseId(databaseId);
                result.add(quiz);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return result;
    }

    public ArrayList<Pitanje> parseQuestions(String response) {
        ArrayList<Pitanje> result = new ArrayList<>();

        try {
            JSONObject jsonObject1 = new JSONObject(response);
            if (!jsonObject1.has("documents")) return result;
            JSONArray quizes = jsonObject1.getJSONArray("documents");
            for (int i = 0; i < quizes.length(); i++) {
                JSONObject jsonObject2 = quizes.getJSONObject(i);
                String dbName = jsonObject2.getString("name");
                String[] array = dbName.split("/");
                String databaseId = array[array.length - 1];
                JSONObject jsonObject3 = jsonObject2.getJSONObject("fields");
                JSONObject jsonObject4 = jsonObject3.getJSONObject("naziv");
                JSONObject jsonObject5 = jsonObject3.getJSONObject("indexTacnog");
                String name = jsonObject4.getString("stringValue");
                int indexTacnog = jsonObject5.getInt("integerValue");
                JSONObject jsonObject6 = jsonObject3.getJSONObject("odgovori");
                JSONObject jsonObject7 = jsonObject6.getJSONObject("arrayValue");
                ArrayList<String> answers = new ArrayList<>();
                JSONArray jsonObject8 = jsonObject7.getJSONArray("values");
                for (int j = 0; j < jsonObject8.length(); j++) {
                    JSONObject jsonObject9 = jsonObject8.getJSONObject(j);
                    String answer = jsonObject9.getString("stringValue");
                    answers.add(answer);
                }
                Pitanje question = new Pitanje(name, name, answers, answers.get(indexTacnog));
                question.setDatabaseId(databaseId);
                result.add(question);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return result;
    }

    public ArrayList<RangList> parserRangLists(String response) {
        ArrayList<RangList> result = new ArrayList<>();
        try {
            JSONObject jsonObject1 = new JSONObject(response);
            if (!jsonObject1.has("documents")) return result;
            JSONArray quizes = jsonObject1.getJSONArray("documents");
            for (int i = 0; i < quizes.length(); i++) {
                JSONObject jsonObject2 = quizes.getJSONObject(i);
                String dbName = jsonObject2.getString("name");
                String[] array = dbName.split("/");
                String databaseId = array[array.length - 1];
                JSONObject jsonObject3 = jsonObject2.getJSONObject("fields");
                JSONObject jsonObject4 = jsonObject3.getJSONObject("nazivKviza");
                String quizName = jsonObject4.getString("stringValue");
                JSONObject jsonObject5 = jsonObject3.getJSONObject("lista");
                JSONObject jsonObject6 = jsonObject5.getJSONObject("mapValue");
                JSONObject jsonObject61 = jsonObject6.getJSONObject("fields");
                Iterator<String> keysIt = jsonObject61.keys();
                Kviz q = Cache.getInstance(context).getQuizByName(quizName);
                if (q == null) {
                    continue;
                }
                RangList rangList = new RangList(q);
                while (keysIt.hasNext()) {
                    String position = keysIt.next();
                    JSONObject jsonObject7 = jsonObject61.getJSONObject(position);
                    JSONObject jsonObject8 = jsonObject7.getJSONObject("mapValue");
                    JSONObject jsonObject9 = jsonObject8.getJSONObject("fields");
                    Iterator<String> playersIt = jsonObject9.keys();
                    while (playersIt.hasNext()) {
                        String player = playersIt.next();
                        //Log.d("player", player);
                        JSONObject jsonObject10 = jsonObject9.getJSONObject(player);
                        String percentage = jsonObject10.getString("stringValue");
                        rangList.add(Integer.parseInt(position), player, Double.parseDouble(percentage));
                    }
                }
                rangList.setDatabaseId(databaseId);
                result.add(rangList);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return result;
    }
}
