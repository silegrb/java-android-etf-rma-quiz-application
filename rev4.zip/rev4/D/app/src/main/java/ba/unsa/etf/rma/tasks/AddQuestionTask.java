package ba.unsa.etf.rma.tasks;

import android.content.Context;
import android.os.AsyncTask;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.projekat.R;

public class AddQuestionTask extends AsyncTask<Pitanje, Void, String> {
    private WeakReference<Context> context;
    private AsyncAddQuestionTaskResponse delegate;

    public AddQuestionTask(Context context, AsyncAddQuestionTaskResponse delegate) {
        this.context = new WeakReference<>(context);
        this.delegate = delegate;
    }

    @Override
    protected String doInBackground(Pitanje... questions) {

        String kolekcija = "Pitanja";

        InputStream is = context.get().getResources().openRawResource(R.raw.secret);
        GoogleCredential credentials = null;
        try {
            credentials = GoogleCredential.fromStream(is).
                    createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String TOKEN = credentials.getAccessToken();

            String url = "https://firestore.googleapis.com/v1/projects/spirala3-1998/databases/(default)/documents/" + kolekcija + "?access_token=";
            URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
            HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/jason");
            conn.setRequestProperty("Accept", "application/jason");

            String document = createDocument(questions[0]);
            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = document.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            int code = conn.getResponseCode();
            InputStream odgovor = conn.getInputStream();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(odgovor, "utf-8"))) {
                StringBuilder response = new StringBuilder();
                String responseLine = null;
                while ((responseLine = br.readLine()) != null) {
                    response.append(responseLine.trim());
                }

                JSONObject jsonObject = new JSONObject(response.toString());
                String name = jsonObject.getString("name");

                String[] idParser = name.split("/");
                String id = idParser[idParser.length - 1];
                return id;
            } catch (JSONException e) {
                e.printStackTrace();
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (ProtocolException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public interface AsyncAddQuestionTaskResponse {
        void finishedQuestionAdd(String id);
    }

    @Override
    protected void onPostExecute(String id) {
        super.onPostExecute(id);
        delegate.finishedQuestionAdd(id);
    }

    private String createDocument(Pitanje question) {
        String nazivPizanja = question.getNaziv();
        int indexTacnog = question.getOdgovori().indexOf(question.getTacan());
        ArrayList<String> odgovori = question.getOdgovori();
        String document = "";
        document += "{\"fields\": {\"naziv\": {\"stringValue\": \"" + nazivPizanja + "\"}," +
                "\"indexTacnog\": {\"integerValue\": \"" + indexTacnog + "\"}," +
                "\"odgovori\": {\"arrayValue\": {\"values\": [";
        for (int i = 0; i < odgovori.size(); i++) {
            document += "{\"stringValue\": \"" + odgovori.get(i) + "\"}";
            if (i != odgovori.size() - 1) {
                document += ",";
            }
        }
        document += "]}}}}";
        return document;
    }
}
