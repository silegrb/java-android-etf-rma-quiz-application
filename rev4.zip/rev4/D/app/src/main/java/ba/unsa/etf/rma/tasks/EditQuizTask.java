package ba.unsa.etf.rma.tasks;

import android.content.Context;
import android.os.AsyncTask;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;

import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.projekat.R;
import ba.unsa.etf.rma.utilities.AsyncEditTaskResponse;

public class EditQuizTask extends AsyncTask<Kviz, Void, Void> {
    private WeakReference<Context> context;
    private AsyncEditTaskResponse delegate;

    public EditQuizTask(Context context, AsyncEditTaskResponse delegate) {
        this.context = new WeakReference<>(context);
        this.delegate = delegate;
    }

    @Override
    protected Void doInBackground(Kviz... quizes) {
        String kolekcija = "Kvizovi";

        InputStream is = context.get().getResources().openRawResource(R.raw.secret);
        GoogleCredential credentials;
        try {
            credentials = GoogleCredential.fromStream(is).
                    createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String TOKEN = credentials.getAccessToken();

            String url = "https://firestore.googleapis.com/v1/projects/spirala3-1998/databases/(default)/documents/" + kolekcija + "/" + quizes[0].getDatabaseId() +
                    "?access_token=";
            URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
            HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
            conn.setDoOutput(true);
            conn.setRequestMethod("PATCH");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");

            String document = createDocument(quizes[0]);
            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = document.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            int code = conn.getResponseCode();
            InputStream odgovor = conn.getInputStream();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(odgovor, "utf-8"))) {
                StringBuilder response = new StringBuilder();
                String responseLine = null;
                while ((responseLine = br.readLine()) != null) {
                    response.append(responseLine.trim());
                }
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (ProtocolException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(Void v) {
        super.onPostExecute(v);
        delegate.finishedEdit();
    }

    private String createDocument(Kviz quiz) {
        String document = "";

        document += "{\"fields\": {\"naziv\": {\"stringValue\": \"" + quiz.getNaziv() + "\"}, \"idKategorije\": {\"stringValue\": \""
                + quiz.getKategorija().getDatabaseId() + "\"}, \"pitanja\": {\"arrayValue\": {\"values\": [";

        if (quiz.getPitanja() != null) {
            for (int i = 0; i < quiz.getPitanja().size(); i++) {
                if (quiz.getPitanja().get(i) != null) {
                    document += "{\"stringValue\": \"" + quiz.getPitanja().get(i).getDatabaseId() + "\"}";
                    if (i != quiz.getPitanja().size() - 1) document += ",";
                }
            }
        }
        document += "]}}}}";

        return document;
    }
}
