package ba.unsa.etf.rma.utilities;

import android.content.Context;
import android.net.Uri;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;

import ba.unsa.etf.rma.database.Cache;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.tasks.AddCategoryTask;

public class QuizTxtParser implements AsyncAddCategoryTaskResponse {
    private Uri uri;
    private Kviz parsedQuiz = null;
    private boolean addCategoryAfterImport;
    private String oldName = null;
    private Context context;
    private Observer observer;

    public QuizTxtParser(Uri uri, Context context, Observer observer) {
        this.uri = uri;
        this.context = context;
        this.observer = observer;
    }

    public Kviz parse() throws IOException, WrongQuizFormatException {
        readTextFromUri();
        if (addCategoryAfterImport) {
            new AddCategoryTask(context, this).execute(parsedQuiz.getKategorija());
        }
        return parsedQuiz;
    }

    public void setOldName(String oldName) {
        this.oldName = oldName;
    }

    private void readTextFromUri() throws IOException, WrongQuizFormatException {
        InputStream inputStream = context.getContentResolver().openInputStream(uri);
        BufferedReader reader = new BufferedReader(new InputStreamReader(
                inputStream));
        StringBuilder stringBuilder = new StringBuilder();
        String line;

        boolean firstLine = true;
        int numberOfQuestions = 0;
        ArrayList<Pitanje> questions = new ArrayList<>();

        while ((line = reader.readLine()) != null) {
            stringBuilder.append(line);
            if (firstLine) {
                numberOfQuestions = parseGeneralQuizData(line);
                firstLine = false;
            } else {
                Pitanje p = parseQuestion(line);
                questions.add(p);
            }
        }

        if (questions.size() != numberOfQuestions) {
            throw new WrongQuizFormatException("Kviz kojeg importujete ima neispravan broj pitanja!");
        }

        parsedQuiz.setPitanja(questions);
    }

    private int parseGeneralQuizData(String line) throws WrongQuizFormatException {
        ArrayList<String> parsedData = parseTextFromString(line);

        if (parsedData.size() != 3) {
            throw new WrongQuizFormatException("Datoteka kviza kojeg importujete nema ispravan format!");
        }

        String quizName = parsedData.get(0);
        if (!isUnique(quizName)) {
            throw new WrongQuizFormatException("Kviz kojeg importujete već postoji!");
        }

        String categoryName = parsedData.get(1);
        Kategorija category = null;
        for (Kategorija c : Cache.getInstance(context).getCategories()) {
            if (c != null && c.getNaziv().equals(categoryName)) {
                category = c;
                break;
            }
        }
        if (category == null) {
            category = new Kategorija(categoryName, "1");
            addCategoryAfterImport = true;
        }

        parsedQuiz = new Kviz(quizName, null, category);

        int num = 0;
        try {
            num = Integer.parseInt(parsedData.get(2));
        } catch (NumberFormatException e) {
            throw new WrongQuizFormatException("Datoteka kviza kojeg importujete nema ispravan format!");
        }
        return num; //n of questions
    }

    private Pitanje parseQuestion(String line) throws WrongQuizFormatException {
        ArrayList<String> parsedData = parseTextFromString(line);

        String question = parsedData.get(0);
        int numberOfAnswers = 1;
        try {
            numberOfAnswers = Integer.parseInt(parsedData.get(1));
        } catch (NumberFormatException e) {
            throw new WrongQuizFormatException("Datoteka kviza kojeg importujete nema ispravan format!");
        }

        if (parsedData.size() != numberOfAnswers + 3) {
            throw new WrongQuizFormatException("Kviz kojeg importujete ima neispravan broj odgovora!");
        }

        int correctAnswer = 0;
        try {
            correctAnswer = Integer.parseInt(parsedData.get(2));
        } catch (NumberFormatException e) {
            throw new WrongQuizFormatException("Datoteka kviza kojeg importujete nema ispravan format!");
        }
        if (!(0 <= correctAnswer && correctAnswer < numberOfAnswers)) {
            throw new WrongQuizFormatException("Kviz kojeg importujete ima neispravan index tačnog odgovora!");
        }

        ArrayList<String> answers = new ArrayList<>();
        for (int j = 3; j < 3 + numberOfAnswers; j++) {
            if (answers.contains(parsedData.get(j))) {
                throw new WrongQuizFormatException("Kviz kojeg importujete nije ispravan postoji ponavljanje odgovora!");
            }
            answers.add(parsedData.get(j));
        }
        return new Pitanje(question, question, answers, answers.get(correctAnswer));

    }

    private ArrayList<String> parseTextFromString(String readText) {
        String[] data = readText.split(",");
        return new ArrayList<>(Arrays.asList(data));
    }

    private boolean isUnique(String quizName) {
        if (quizName.equals(oldName)) return true;

        for (Kviz k : Cache.getInstance(context).getQuizes()) {
            if (k != null && k.getNaziv().equals(quizName)) return false;
        }
        return true;
    }

    @Override
    public void finishedAdd(String id) {
        observer.update();
    }
}
