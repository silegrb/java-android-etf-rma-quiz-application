package ba.unsa.etf.rma.utilities;

public interface AsyncAddRangListTaskResponse {
    void finishedAdd();
}
