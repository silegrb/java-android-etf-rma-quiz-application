package ba.unsa.etf.rma.database;

import android.provider.BaseColumns;

public class Contract {
    private Contract(){}

    public static final class CategoryEntry implements BaseColumns{
        public static final String TABLE_NAME = "categrory";
        public static final String COLUMN_NAME = "name";
        public static final String COLUMN_ICON = "icon";
        public static final String COLUMN_FIREBASE = "firebaseId";
    }

    public static final class QuestionEntry implements BaseColumns{
        public static final String TABLE_NAME = "question";
        public static final String COLUMN_TEXT = "text";
        public static final String COLUMN_CORRECT = "correctAnswer";
        public static final String COLUMN_FIREBASE = "firebaseId";
    }

    public static final class AnswerEntry implements BaseColumns{
        public static final String TABLE_NAME = "answer";
        public static final String COLUMN_TEXT = "text";
        public static final String COLUMN_QUESTION = "questionId";
    }

    public static final class QuizEntry implements BaseColumns{
        public static final String TABLE_NAME = "quiz";
        public static final String COLUMN_NAME = "name";
        public static final String COLUMN_CATEGORY = "categoryId";
        public static final String COLUMN_FIREBASE = "firebaseId";
    }

    public static final class QuizQuestionEntry implements BaseColumns{
        public static final String TABLE_NAME = "quizAndQuestion";
        public static final String COLUMN_QUESTION = "questionId";
        public static final String COLUMN_QUIZ = "quizId";
    }

    public static final class RangListEntry implements BaseColumns {
        public static final String TABLE_NAME = "rangList";
        public static final String COLUMN_QUIZ = "quizId";
        public static final String COLUMN_FIREBASE = "firebaseId";
    }

    public static final class RangListItemEntry implements BaseColumns{
        public static final String TABLE_NAME = "rangListItem";
        public static final String COLUMN_POSITION = "position";
        public static final String COLUMN_PLAYER = "playerName";
        public static final String COLUMN_PERCENTAGE = "percentage";
        public static final String COLUMN_RANG_LIST = "rangList";
    }
}
