package ba.unsa.etf.rma.fragmenti;


import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.aktivnosti.KvizoviAkt;
import ba.unsa.etf.rma.klase.Kategorija;


public class ListaFrag extends Fragment {

    private ListView listaKategorija;
    private ArrayList<Kategorija> kategorije;
    private ArrayList<String> naziviKategorija;
    private Listener listener;

    public ListaFrag() {
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.listener = (ListaFrag.Listener)context;
    }


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_lista, container, false);
        listaKategorija = view.findViewById(R.id.listaKategorija);

        if(getArguments() != null && getArguments().containsKey(KvizoviAkt.EXTRA_KATEGORIJA_TO_LISTA_FRAG))
        {
            kategorije = getArguments().getParcelableArrayList(KvizoviAkt.EXTRA_KATEGORIJA_TO_LISTA_FRAG);
            naziviKategorija = new ArrayList<>();
            for(Kategorija k: kategorije) {
                naziviKategorija.add(k.getNaziv());
            }
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(view.getContext(), android.R.layout.simple_list_item_1, naziviKategorija);
        listaKategorija.setAdapter(adapter);

        listaKategorija.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                listener.itemClicked(kategorije.get(position).getNaziv(), position);
            }
        });

        return view;
    }

    public interface Listener {
        void itemClicked(String kategorija, int pozicija);
    }

}
