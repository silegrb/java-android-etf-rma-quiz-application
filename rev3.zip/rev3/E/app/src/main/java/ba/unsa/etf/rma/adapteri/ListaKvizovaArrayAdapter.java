package ba.unsa.etf.rma.adapteri;

import android.content.Context;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.maltaisn.icondialog.IconHelper;

import java.util.List;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kviz;

public class ListaKvizovaArrayAdapter extends ArrayAdapter<Kviz> {
    private int resourceLayout;
    private Context mContext;
    private Kviz p;
    private ImageView iwKategorija;
    private TextView tvNazivKviza;

    public ListaKvizovaArrayAdapter(Context context, int resource, List<Kviz> items) {
        super(context, resource, items);
        this.resourceLayout = resource;
        this.mContext = context;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View v = convertView;

        if (v == null) {
            LayoutInflater vi;
            vi = LayoutInflater.from(mContext);
            v = vi.inflate(resourceLayout, null);
        }

        p = getItem(position);

        if (p != null) {
            tvNazivKviza = v.findViewById(R.id.tvNazivKviza);
            iwKategorija = v.findViewById(R.id.iwKategorija);

            if (tvNazivKviza != null) {
                tvNazivKviza.setText(p.getNaziv());
            }

            if (iwKategorija != null) {
                if(p.getNaziv().equals("Dodaj novi kviz")) {
                    iwKategorija.setImageResource(R.drawable.add_circle_green);
                    iwKategorija.setColorFilter(ActivityCompat.getColor(mContext, android.R.color.transparent));
                }
                else if(p.getKategorija().getNaziv().equals("Svi")){
                    iwKategorija.setImageResource(R.drawable.question_mark);
                    iwKategorija.setColorFilter(ActivityCompat.getColor(mContext, android.R.color.transparent));
                }
                else {
                    final IconHelper iconHelper = IconHelper.getInstance(mContext);
                    iconHelper.addLoadCallback(new IconHelper.LoadCallback() {
                        @Override
                        public void onDataLoaded() {
                            // This happens on UI thread, and is guaranteed to be called.

                            iwKategorija.setImageDrawable(iconHelper.getIcon(Integer.parseInt(p.getKategorija().getId())).getDrawable(mContext));
                            iwKategorija.setColorFilter(ActivityCompat.getColor(mContext, android.R.color.holo_orange_dark));
                        }
                    });
                }
            }
        }

        return v;
    }
}
