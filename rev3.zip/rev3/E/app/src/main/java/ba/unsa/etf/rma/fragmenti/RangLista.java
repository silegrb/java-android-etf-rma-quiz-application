package ba.unsa.etf.rma.fragmenti;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.aktivnosti.DodajPitanjeAkt;
import ba.unsa.etf.rma.servisi.DohvatiAzuriranuRangListu;
import ba.unsa.etf.rma.servisi.IndexPitanjaResultReceiver;
import ba.unsa.etf.rma.servisi.PitanjeCreate;
import ba.unsa.etf.rma.servisi.RangListaResultReceiver;


public class RangLista extends Fragment implements RangListaResultReceiver.Receiver {

    private String imeIgraca;
    private String nazivKviza;
    private double procent;
    private ArrayList<String> rangLista;

    public RangLista() { }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_rang_lista, container, false);

        if(getArguments() != null && getArguments().containsKey("ime") && getArguments().containsKey("procent"))
        {
            imeIgraca = getArguments().getString("ime");
            procent = getArguments().getDouble("procent");
            nazivKviza = getArguments().getString("kviz");
        }

        Intent servisIntent = new Intent(Intent.ACTION_SYNC, null, requireContext(), DohvatiAzuriranuRangListu.class);
        servisIntent.putExtra("ime", imeIgraca);
        servisIntent.putExtra("procent", procent);
        servisIntent.putExtra("kviz", nazivKviza);
        RangListaResultReceiver listaReceiver = new RangListaResultReceiver(new Handler());
        listaReceiver.setReceiver(RangLista.this);
        servisIntent.putExtra("receiver", listaReceiver);
        requireActivity().startService(servisIntent);

        return view;
    }

    @Override
    public void onReceiveResult(int resultCode, Bundle resultData) {
        switch (resultCode) {
            case PitanjeCreate.STATUS_RUNNING :
                break;
            case PitanjeCreate.STATUS_FINISHED :
                rangLista = resultData.getStringArrayList("rangLista");
                ListView lvRangLista = requireActivity().findViewById(R.id.lvRangLista);
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(requireContext(), android.R.layout.simple_list_item_1, rangLista);
                lvRangLista.setAdapter(adapter);
                break;
            case PitanjeCreate.STATUS_ERROR :
                String error = resultData.getString(Intent.EXTRA_TEXT);
                break;
        }
    }
}
