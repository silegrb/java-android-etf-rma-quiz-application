package ba.unsa.etf.rma.aktivnosti;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;

import com.maltaisn.icondialog.IconHelper;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Random;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.CSVFile;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.adapteri.ListaPitanjaAdapter;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.adapteri.SpinnerKategorijaAdapter;
import ba.unsa.etf.rma.servisi.DohvatiKategorije;
import ba.unsa.etf.rma.servisi.DohvatiKvizSaPitanjima;
import ba.unsa.etf.rma.servisi.DohvatiSveKvizove;
import ba.unsa.etf.rma.servisi.IndexPitanjaResultReceiver;
import ba.unsa.etf.rma.servisi.KategorijaCreate;
import ba.unsa.etf.rma.servisi.KategorijaResultReceiver;
import ba.unsa.etf.rma.servisi.KvizCreate;
import ba.unsa.etf.rma.servisi.KvizCreateResultReceiver;
import ba.unsa.etf.rma.servisi.KvizPatch;
import ba.unsa.etf.rma.servisi.PitanjeCreate;

public class DodajKvizAkt extends AppCompatActivity implements DohvatiKvizSaPitanjima.OnMogucaSearchDone,
                                                                DohvatiKategorije.OnKategorijeSearchDone,
                                                                DohvatiSveKvizove.OnKvizoviSearchDone,
                                                                KvizCreateResultReceiver.Receiver,
                                                                IndexPitanjaResultReceiver.Receiver,
                                                                KategorijaResultReceiver.Receiver {

    private Spinner spKategorije;
    private EditText etNaziv;
    private ListView lvDodanaPitanja;
    private ListView lvMogucaPitanja;
    private Button btnDodajKviz;
    private ArrayList<Kategorija> kategorije;
    private ArrayList<Pitanje> dodanaPitanja;
    private ArrayList<Pitanje> mogucaPitanja;
    private ArrayList<Kviz> kvizovi;
    private ArrayList<String[]>  redovi;
    private ListaPitanjaAdapter adapterDodana;
    private ListaPitanjaAdapter adapterMoguca;
    private SpinnerKategorijaAdapter adapterKategorije;
    private Button btnImportKviz;
    private Boolean ispravanNaziv;
    private Boolean ispravnaKategorija;
    private String importKategorija;
    private String alertPoruka;
    private int iconID;
    private IconHelper iconHelper;
    private AlertDialog.Builder alertDialogBuilder;
    private int pozicijaKategorije;
    private ArrayList<String> idDodanih;
    private ArrayList<String> idMogucih;
    private Boolean btnDodajClicked;
    private ArrayList<String> idIzbacenih;
    private String idKviza;
    private Kviz trenutniKviz;
    private Boolean prvoKreiranje;
    private String odabranaKategorija;
    private String etNoviNaziv;

    public static final int CATEGORY_REQUEST_CODE = 456;
    public static final int QUESTION_REQUEST_CODE = 789;
    public static final int IMPORT_QUIZ_REQUEST_CODE = 220;

    private static final String SIS_POZICIJA_KATEGORIJE = "kat_poz";
    private static final String SIS_ISPRAVAN_NAZIV = "okNaziv";
    private static final String SIS_ALERT_PORUKA = "alertPoruka";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kviz);

        spKategorije = findViewById(R.id.spKategorije);
        etNaziv = findViewById(R.id.etNaziv);
        lvDodanaPitanja = findViewById(R.id.lvDodanaPitanja);
        lvMogucaPitanja = findViewById(R.id.lvMogucaPitanja);
        btnDodajKviz = findViewById(R.id.btnDodajKviz);
        btnImportKviz = findViewById(R.id.btnImportKviz);

        if(savedInstanceState != null) {
            ucitajSavedInstanceStatePodatke(savedInstanceState);
            btnDodajClicked = false;
            prvoKreiranje = false;
        }
        else {
            btnDodajClicked = false;
            idIzbacenih = new ArrayList<>();
            idDodanih = new ArrayList<>();
            prvoKreiranje = true;
        }

        dohvatiPodatkeIzKvizoviAkt();

        lvDodanaPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (dodanaPitanja.size() != 0 && position != dodanaPitanja.size() - 1) {
                    mogucaPitanja.add(dodanaPitanja.get(position));
                    idMogucih.add(idDodanih.get(position));
                    idIzbacenih.add(idDodanih.get(position));
                    dodanaPitanja.remove(position);
                    idDodanih.remove(position);
                    adapterDodana.notifyDataSetChanged();
                    adapterMoguca.notifyDataSetChanged();
                }
                else {
                    Intent intent = new Intent(DodajKvizAkt.this, DodajPitanjeAkt.class);
                    startActivityForResult(intent, QUESTION_REQUEST_CODE);
                }
            }
        });

        lvMogucaPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(mogucaPitanja != null && mogucaPitanja.size() != 0 && !dodanaPitanja.contains(mogucaPitanja.get(position))) {
                    dodanaPitanja.add(dodanaPitanja.size() - 1, mogucaPitanja.get(position));
                    idDodanih.add(idMogucih.get(position));
                    idIzbacenih.remove(idMogucih.get(position));
                    mogucaPitanja.remove(position);
                    idMogucih.remove(position);
                    adapterDodana.notifyDataSetChanged();
                    adapterMoguca.notifyDataSetChanged();
                }
            }
        });

        btnDodajKviz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnDodajClicked = true;
                etNoviNaziv = etNaziv.getText().toString();
                InputStream is = getResources().openRawResource(R.raw.secret);
                new DohvatiKvizSaPitanjima(idDodanih, idIzbacenih, is, DodajKvizAkt.this).execute(idKviza);
            }
        });

        spKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(position == kategorije.size() - 1) {
                    etNoviNaziv = etNaziv.getText().toString();
                    Intent intent = new Intent(DodajKvizAkt.this, DodajKategorijuAkt.class);
                    startActivityForResult(intent, CATEGORY_REQUEST_CODE);
                }
                else {
                    etNoviNaziv = etNaziv.getText().toString();
                    odabranaKategorija = kategorije.get(position).getNaziv();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        btnImportKviz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etNoviNaziv = etNaziv.getText().toString();
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("text/*");
                startActivityForResult(intent, IMPORT_QUIZ_REQUEST_CODE);
            }
        });
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent pData) {
        if (requestCode == CATEGORY_REQUEST_CODE )
        {
            if (resultCode == AppCompatActivity.RESULT_OK)
            {
                odabranaKategorija = pData.getStringExtra(DodajKategorijuAkt.EXTRA_KATEGORIJA_DKAT_TO_DKVIZ);
                InputStream is = getResources().openRawResource(R.raw.secret);
                new DohvatiKategorije(is, DodajKvizAkt.this).execute();
            }
            else {
                spKategorije.setSelection(0);
            }
        }

        else if(requestCode == QUESTION_REQUEST_CODE) {
            if (resultCode == AppCompatActivity.RESULT_OK)
            {
                idDodanih.add(pData.getStringExtra("id"));
                InputStream is = getResources().openRawResource(R.raw.secret);
                new DohvatiKvizSaPitanjima(idDodanih, idIzbacenih, is, this).execute(idKviza);
            }
        }

        else if(requestCode == IMPORT_QUIZ_REQUEST_CODE) {
            if(resultCode == AppCompatActivity.RESULT_OK) {
                try {
                    readTextFromUri(pData.getData());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }



    private void provjeraValidnostiUnosa() {
        ispravanNaziv = true;
        ispravnaKategorija = true;
        btnDodajClicked = false;

        String temp = etNaziv.getText().toString().trim();
        if(temp.equals(""))
            ispravanNaziv = false;
        else {
            for(int i = 0; i<kvizovi.size(); i++)
                if(kvizovi.get(i).getNaziv().equals(temp) && !trenutniKviz.getNaziv().equals(temp)) {
                    ispravanNaziv = false;
                    break;
                }
        }

        if(!ispravanNaziv) {
            etNaziv.setBackgroundColor(getResources().getColor(R.color.podaci_greska));
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(DodajKvizAkt.this);
            alertDialogBuilder.setTitle("Greska pri kreiranju/izmjeni kviza");
            alertDialogBuilder.setIcon(getResources().getDrawable(R.drawable.alert_icon_red));
            alertDialogBuilder.setNeutralButton(R.string.alertButton, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            alertDialogBuilder.setMessage("Uneseni naziv vec postoji!");
            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();
        }
        else{
            etNaziv.setBackgroundColor(getResources().getColor(android.R.color.transparent));
        }

        //kategorija "Svi" postaje zabranjena jer se ne treba nalaziti na firestoreu
        if(odabranaKategorija.equals("Svi")) {
            ispravnaKategorija = false;
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(DodajKvizAkt.this);
            alertDialogBuilder.setTitle("Greska pri odabiru kategorije");
            alertDialogBuilder.setIcon(getResources().getDrawable(R.drawable.alert_icon_red));
            alertDialogBuilder.setNeutralButton(R.string.alertButton, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            alertDialogBuilder.setMessage("Kviz mora biti dodijeljen nekoj kategoriji!");
            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();
        }
    }

    private void dohvatiPodatkeIzKvizoviAkt() {
        kategorije = new ArrayList<>();
        kvizovi = new ArrayList<>();
        dodanaPitanja = new ArrayList<>();
        mogucaPitanja = new ArrayList<>();

        InputStream is = getResources().openRawResource(R.raw.secret);
        idKviza = getIntent().getStringExtra("id");

        ispravanNaziv = true;

        new DohvatiKvizSaPitanjima(idDodanih, idIzbacenih, is, this).execute(idKviza);
    }


    @Override
    public void onKvizSaPitanjimaDone(ArrayList<Pitanje> dohvacenaDodana, ArrayList<Pitanje> dohvacenaMoguca, ArrayList<String> dodana, ArrayList<String> moguca, Kviz odabraniKviz) {
        mogucaPitanja = dohvacenaMoguca;
        dodanaPitanja = dohvacenaDodana;
        dodanaPitanja.add(new Pitanje("", "", new ArrayList<String>(), ""));
        idDodanih = dodana;
        idMogucih = moguca;
        adapterDodana = new ListaPitanjaAdapter(this, dodanaPitanja, getResources(), true);
        lvDodanaPitanja.setAdapter(adapterDodana);
        adapterMoguca = new ListaPitanjaAdapter(this, mogucaPitanja, getResources(), false);
        lvMogucaPitanja.setAdapter(adapterMoguca);

        trenutniKviz = odabraniKviz;

        //nakon dobavljanja kviza popunja se edittext za naziv ukoliko nije izmijenjen u medjuvremenu
        if(!idKviza.equals("") && etNoviNaziv==null)
            etNaziv.setText(trenutniKviz.getNaziv());

        InputStream is = getResources().openRawResource(R.raw.secret);
        new DohvatiKategorije(is, DodajKvizAkt.this).execute();

    }

    @Override
    public void onSearchDone(ArrayList<Kategorija> dohvaceneKategorije) {
        kategorije = dohvaceneKategorije;
        kategorije.add(new Kategorija(getString(R.string.sviKvizovi), Integer.toString(R.drawable.question_mark)));
        kategorije.add(new Kategorija("dodaj_novi", "dodaj_novi"));
        adapterKategorije = new SpinnerKategorijaAdapter(this, kategorije, getResources(), true);
        spKategorije.setAdapter(adapterKategorije);

        if(prvoKreiranje) {
            for (int i = 0; i < kategorije.size() - 1; i++) {
                if (kategorije.get(i).getNaziv().equals(trenutniKviz.getKategorija().getNaziv())) {
                    pozicijaKategorije = i;
                    odabranaKategorija = kategorije.get(i).getNaziv();
                    break;
                }
            }
            prvoKreiranje = false;
        }
        else {
            for(int i = 0; i < kategorije.size(); i++)
                if(kategorije.get(i).getNaziv().equals(odabranaKategorija)) {
                    pozicijaKategorije = i;
                    break;
                }
        }

        spKategorije.setSelection(pozicijaKategorije);

        InputStream is = getResources().openRawResource(R.raw.secret);
        if(btnDodajClicked) {
            new DohvatiSveKvizove(is, DodajKvizAkt.this).execute();
        }
    }

    @Override
    public void onSviKvizoviDone(ArrayList<Kviz> dohvaceniKvizovi, ArrayList<Kategorija> dohvaceneKategorije) {
        kvizovi = dohvaceniKvizovi;
        provjeraValidnostiUnosa();
        if(ispravanNaziv && ispravnaKategorija) {
            String temp = etNaziv.getText().toString().trim();
            if(!trenutniKviz.getNaziv().equals("")) {
                // pokretanje servisa za update trenutnog kviza
                Intent servisIntent = new Intent(Intent.ACTION_SYNC, null, DodajKvizAkt.this, KvizPatch.class);
                servisIntent.putExtra("trenutniNaziv", trenutniKviz.getNaziv());
                servisIntent.putExtra("noviNaziv", temp);
                servisIntent.putExtra("kategorija", kategorije.get(spKategorije.getSelectedItemPosition()).getNaziv());
                servisIntent.putStringArrayListExtra("pitanja", idDodanih);

                KvizCreateResultReceiver createReceiver = new KvizCreateResultReceiver(new Handler());
                createReceiver.setReceiver(DodajKvizAkt.this);
                servisIntent.putExtra("receiver", createReceiver);

                startService(servisIntent);
            }
            else {
                // pokretanje servisa za kreiranje novog kviza
                Intent servisIntent = new Intent(Intent.ACTION_SYNC, null, DodajKvizAkt.this, KvizCreate.class);
                servisIntent.putExtra("naziv", temp);
                servisIntent.putExtra("kategorija", kategorije.get(spKategorije.getSelectedItemPosition()).getNaziv());
                servisIntent.putStringArrayListExtra("pitanja", idDodanih);

                KvizCreateResultReceiver createReceiver = new KvizCreateResultReceiver(new Handler());
                createReceiver.setReceiver(DodajKvizAkt.this);
                servisIntent.putExtra("receiver", createReceiver);

                startService(servisIntent);
            }
        }
    }


    private void centrirajAlertDialogButton(AlertDialog alertDialog) {
        Button neutralButton = alertDialog.getButton(AlertDialog.BUTTON_NEUTRAL);
        LinearLayout.LayoutParams neutralButtonLL = (LinearLayout.LayoutParams)neutralButton.getLayoutParams();
        neutralButtonLL.weight = 10;
        neutralButton.setLayoutParams(neutralButtonLL);
    }

    private void readTextFromUri(Uri uri) throws IOException {
        InputStream inputStream = getContentResolver().openInputStream(uri);
        CSVFile csvFile = new CSVFile(inputStream);
        redovi = csvFile.read();

        if(validacijaImportKviza())
            importujKviz();
    }

    private void importujKviz() {
        etNaziv.setText(redovi.get(0)[0].trim());
        etNaziv.setSelection(etNaziv.getText().toString().length());

        importKategorija = redovi.get(0)[1].trim().equals("") ? getString(R.string.sviKvizovi) : redovi.get(0)[1].trim();
        odabranaKategorija = importKategorija;

        int i;
        for(i = 0; i<kategorije.size(); i++) {
            if(importKategorija.equals(kategorije.get(i).getNaziv())) {
                pozicijaKategorije = i;
                spKategorije.setSelection(pozicijaKategorije);
                break;
            }
        }

        if(i == kategorije.size()) {
            iconHelper = IconHelper.getInstance(DodajKvizAkt.this);
            iconHelper.addLoadCallback(new IconHelper.LoadCallback() {
                @Override
                public void onDataLoaded() {
                    Random rand = new Random();
                    iconID = rand.nextInt(iconHelper.getIconCount());

                    //dodavanje nove kategorije i u firestore
                    Intent servisIntent = new Intent(Intent.ACTION_SYNC, null, DodajKvizAkt.this, KategorijaCreate.class);
                    servisIntent.putExtra("naziv", etNaziv.getText().toString());
                    servisIntent.putExtra("ikona", Integer.toString(iconID));

                    KategorijaResultReceiver kategorijaReceiver = new KategorijaResultReceiver(new Handler());
                    kategorijaReceiver.setReceiver(DodajKvizAkt.this);
                    servisIntent.putExtra("receiver", kategorijaReceiver);

                    startService(servisIntent);
                }
            });

        }


        for(i=1; i<redovi.size(); i++) {
            Pitanje temp = new Pitanje();
            temp.setNaziv(redovi.get(i)[0].trim());
            temp.setTekstPitanja(redovi.get(i)[0].trim());
            ArrayList<String> tmpOdgovori = new ArrayList<>();
            for(int j=3; j<redovi.get(i).length; j++) {
                tmpOdgovori.add(redovi.get(i)[j].trim());
            }
            temp.setOdgovori(tmpOdgovori);
            int pozicijaTacnog = Integer.parseInt(redovi.get(i)[2].trim());
            temp.setTacan(tmpOdgovori.get(pozicijaTacnog));
            dodanaPitanja.add(0, temp);

            //dodavanje pitanja i na firestore
            Intent servisIntent = new Intent(Intent.ACTION_SYNC, null, DodajKvizAkt.this, PitanjeCreate.class);
            servisIntent.putExtra("naziv", temp.getNaziv());
            servisIntent.putStringArrayListExtra("odgovori", temp.getOdgovori());
            servisIntent.putExtra("tacan", pozicijaTacnog);

            IndexPitanjaResultReceiver indexReceiver = new IndexPitanjaResultReceiver(new Handler());
            indexReceiver.setReceiver(DodajKvizAkt.this);
            servisIntent.putExtra("receiver", indexReceiver);

            startService(servisIntent);
        }
        adapterDodana.notifyDataSetChanged();
    }

    private boolean validacijaImportKviza() {
        boolean ispravanFormat = true;
        boolean ispravanImportNaziv = true;

        alertDialogBuilder = new AlertDialog.Builder(DodajKvizAkt.this);
        alertDialogBuilder.setTitle(R.string.alertTitle);
        alertDialogBuilder.setIcon(getResources().getDrawable(R.drawable.alert_icon_red));
        alertDialogBuilder.setNeutralButton(R.string.alertButton, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        if(redovi != null) {
            if(redovi.size() < 1 || redovi.get(0).length != 3)
                ispravanFormat = false;
            else {
                for(int i=1; i<redovi.size(); i++)
                    if(redovi.get(i).length < 4) {
                        ispravanFormat = false;
                        break;
                    }
            }

            if(!ispravanFormat) {
                alertPoruka = getString(R.string.porukaNeispravanFormat);
                alertDialogBuilder.setMessage(alertPoruka);
                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();
                centrirajAlertDialogButton(alertDialog);
                return false;
            }

            String naziv = redovi.get(0)[0].trim();
            for(int i = 0; i<kvizovi.size(); i++)
                if(kvizovi.get(i).getNaziv().equals(naziv) && !idKviza.equals(kvizovi.get(i).getFirestoreID())) {
                    ispravanImportNaziv = false;
                    break;
                }

            if(!ispravanImportNaziv) {
                alertPoruka = getString(R.string.porukaKvizPostoji);
                alertDialogBuilder.setMessage(alertPoruka);
                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();
                centrirajAlertDialogButton(alertDialog);
                return false;
            }

            else {
                try {
                    if (Integer.parseInt(redovi.get(0)[2].trim()) != redovi.size() - 1) {
                        alertPoruka = getString(R.string.porukaNeispravanBrojPitanja);
                        alertDialogBuilder.setMessage(alertPoruka);
                        AlertDialog alertDialog = alertDialogBuilder.create();
                        alertDialog.show();
                        centrirajAlertDialogButton(alertDialog);
                        return false;
                    }
                    else {
                        ArrayList<Pitanje> tempDodana = new ArrayList<>(dodanaPitanja);
                        for(int i=1; i<redovi.size(); i++) {
                            Pitanje pitTemp = new Pitanje(redovi.get(i)[0].trim(), "", new ArrayList<String>(), "" );
                            if(tempDodana.contains(pitTemp) || mogucaPitanja.contains(pitTemp)) {
                                alertPoruka = getString(R.string.porukanejedinstvenosPitanja);
                                alertDialogBuilder.setMessage(alertPoruka);
                                AlertDialog alertDialog = alertDialogBuilder.create();
                                alertDialog.show();
                                centrirajAlertDialogButton(alertDialog);
                                return false;
                            }
                            else {
                                tempDodana.add(new Pitanje(redovi.get(i)[0].trim(), "", new ArrayList<String>(), "" ));
                            }

                            if (Integer.parseInt(redovi.get(i)[1].trim()) != redovi.get(i).length - 3 || Integer.parseInt(redovi.get(i)[1].trim()) < 1) {
                                alertPoruka = getString(R.string.porukaNeispravanBrojOdgovora);
                                alertDialogBuilder.setMessage(alertPoruka);
                                AlertDialog alertDialog = alertDialogBuilder.create();
                                alertDialog.show();
                                centrirajAlertDialogButton(alertDialog);
                                return false;
                            }
                            if (Integer.parseInt(redovi.get(i)[2].trim()) < 0 || Integer.parseInt(redovi.get(i)[2].trim()) >= Integer.parseInt(redovi.get(i)[1].trim())) {
                                alertPoruka = getString(R.string.porukaNeispravanTacan);
                                alertDialogBuilder.setMessage(alertPoruka);
                                AlertDialog alertDialog = alertDialogBuilder.create();
                                alertDialog.show();
                                centrirajAlertDialogButton(alertDialog);
                                return false;
                            }
                            for (int j=3; j<redovi.get(i).length; j++)
                                for (int k=j+1;k<redovi.get(i).length; k++)
                                    if (k!=j && redovi.get(i)[k].trim().equals(redovi.get(i)[j].trim())) {
                                        alertPoruka = getString(R.string.porukaPonavljanjeOdgovora);
                                        alertDialogBuilder.setMessage(alertPoruka);
                                        AlertDialog alertDialog = alertDialogBuilder.create();
                                        alertDialog.show();
                                        centrirajAlertDialogButton(alertDialog);
                                        return false;
                                    }
                        }
                    }

                }
                catch (NumberFormatException e) {
                    alertPoruka = getString(R.string.porukaNeispravanFormat);
                    alertDialogBuilder.setMessage(alertPoruka);
                    AlertDialog alertDialog = alertDialogBuilder.create();
                    alertDialog.show();
                    centrirajAlertDialogButton(alertDialog);
                    return false;
                }
            }
        }

        return true;
    }


    @Override
    public void onBackPressed() {
        Intent iData = new Intent();
        setResult(AppCompatActivity.RESULT_OK, iData);
        finish();
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putString("id", idKviza);
        savedInstanceState.putString("noviNaziv", etNoviNaziv);
        savedInstanceState.putStringArrayList("idIzbacenih", idIzbacenih);
        savedInstanceState.putString("kategorija", odabranaKategorija);
        savedInstanceState.putStringArrayList("idDodanih", idDodanih);
        savedInstanceState.putBoolean(SIS_ISPRAVAN_NAZIV, ispravanNaziv);
        savedInstanceState.putInt(SIS_POZICIJA_KATEGORIJE, pozicijaKategorije);
        savedInstanceState.putString(SIS_ALERT_PORUKA, alertPoruka);
    }

    private void ucitajSavedInstanceStatePodatke(Bundle savedInstanceState) {
        ispravanNaziv = savedInstanceState.getBoolean(SIS_ISPRAVAN_NAZIV);
        if(!ispravanNaziv)
            etNaziv.setBackgroundColor(getResources().getColor(R.color.podaci_greska));
        pozicijaKategorije = savedInstanceState.getInt(SIS_POZICIJA_KATEGORIJE);
        alertPoruka = savedInstanceState.getString(SIS_ALERT_PORUKA);
        if(alertPoruka != null && !alertPoruka.equals("")) {
            alertDialogBuilder = new AlertDialog.Builder(DodajKvizAkt.this);
            alertDialogBuilder.setTitle(getString(R.string.alertTitle));
            alertDialogBuilder.setIcon(getResources().getDrawable(R.drawable.alert_icon_red));
            alertDialogBuilder.setMessage(alertPoruka);
            alertDialogBuilder.setNeutralButton(getString(R.string.alertButton), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();
            centrirajAlertDialogButton(alertDialog);
        }
        idKviza = savedInstanceState.getString("id");
        idIzbacenih = savedInstanceState.getStringArrayList("idIzbacenih");
        odabranaKategorija = savedInstanceState.getString("kategorija");
        idDodanih = savedInstanceState.getStringArrayList("idDodanih");
        etNoviNaziv = savedInstanceState.getString("noviNaziv");
    }

    @Override
    public void onReceiveResult(int resultCode, Bundle resultData) {
        switch (resultCode) {
            case KvizPatch.STATUS_RUNNING :
                break;
            case KvizPatch.STATUS_FINISHED :
                Intent iData = new Intent();
                setResult(AppCompatActivity.RESULT_OK, iData);
                finish();
                break;
            case KvizPatch.STATUS_ERROR :
                break;
        }
    }

    @Override
    public void onReceiveIndexResult(int resultCode, Bundle resultData) {
        switch (resultCode) {
            case PitanjeCreate.STATUS_RUNNING :
                break;
            case PitanjeCreate.STATUS_FINISHED :
                idDodanih.add(resultData.getString("id"));
                break;
            case PitanjeCreate.STATUS_ERROR :
                break;
        }
    }

    @Override
    public void onKategorijaReceiveResult(int resultCode, Bundle resultData) {
        switch (resultCode) {
            case KategorijaCreate.STATUS_RUNNING :
                break;
            case KategorijaCreate.STATUS_FINISHED :
                InputStream is = getResources().openRawResource(R.raw.secret);
                new DohvatiKategorije(is, DodajKvizAkt.this).execute();
                break;
            case KategorijaCreate.STATUS_ERROR :
                break;
        }

    }
}
