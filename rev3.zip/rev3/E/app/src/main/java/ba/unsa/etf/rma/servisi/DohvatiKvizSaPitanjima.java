package ba.unsa.etf.rma.servisi;

import android.os.AsyncTask;
import android.util.Log;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class DohvatiKvizSaPitanjima extends AsyncTask<String, Integer, Void> {

    private ArrayList<Pitanje> dodanaPitanja;
    private ArrayList<Pitanje> mogucaPitanja;
    private ArrayList<String> idDodanih;
    private ArrayList<String> idMogucih;
    private ArrayList<String> idIzbacenih;
    private Kviz odabraniKviz;
    private OnMogucaSearchDone pozivatelj;
    private InputStream is;
    private ArrayList<String> newIdDodanih;
    private String TOKEN;

    public DohvatiKvizSaPitanjima(ArrayList<String> dodana, ArrayList<String> izbacena, InputStream inStream, OnMogucaSearchDone p) {
        is = inStream;
        pozivatelj = p;
        idDodanih = dodana;
        idIzbacenih = izbacena;
    }

    @Override
    protected Void doInBackground(String...params) {

        dodanaPitanja = new ArrayList<>();
        mogucaPitanja = new ArrayList<>();
        idMogucih = new ArrayList<>();

        String idKviza = params[0];

        GoogleCredential credentials;
        TOKEN = null;
        try {
            credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            TOKEN = credentials.getAccessToken();
        }
        catch (IOException e) {
            e.printStackTrace();
        }

        String projektID = "rma19-568b8";

        dohvatiKviz(projektID, idKviza);

        dohvatiPitanja(projektID);

        return null;
    }

    private void dohvatiKviz(String projektID, String idKviza) {
        odabraniKviz = new Kviz("", dodanaPitanja, new Kategorija("Svi", "0"), idKviza);

        try {
            //ako je id prazan string onda se dodaje novi kviz, ne uredjuje se postojeci
            if(!idKviza.equals("")) {
                //dohvatanje kviza sa proslijedjenim ID
                String kvizQuery = "https://firestore.googleapis.com/v1/projects/" + projektID + "/databases/(default)/documents/Kvizovi/" + idKviza;

                URL url = new URL(kvizQuery);
                HttpURLConnection urlConnection2 = (HttpURLConnection) url.openConnection();
                urlConnection2.setRequestProperty("Authorization", "Bearer " + TOKEN);

                InputStream in = new BufferedInputStream(urlConnection2.getInputStream());

                String dobavljeniKviz = convertStreamToString(in);
                JSONObject joKviz = new JSONObject(dobavljeniKviz);

                JSONObject fields = joKviz.getJSONObject("fields");

                JSONObject naziv = fields.getJSONObject("naziv");
                odabraniKviz.setNaziv(naziv.getString("stringValue"));

                //dohvatanje naziva kategorije
                JSONObject joKatID = fields.getJSONObject("idKategorije");
                String idKat = joKatID.getString("stringValue");

                String katQuery = "https://firestore.googleapis.com/v1/projects/" + projektID + "/databases/(default)/documents/Kategorije/" + idKat;

                URL urlKategorije = new URL(katQuery);
                HttpURLConnection urlConnectionKat = (HttpURLConnection) urlKategorije.openConnection();
                urlConnectionKat.setRequestProperty("Authorization", "Bearer " + TOKEN);

                in = new BufferedInputStream(urlConnectionKat.getInputStream());

                String dobavljenaKat = convertStreamToString(in);
                JSONObject joKat = new JSONObject(dobavljenaKat);
                JSONObject katFields = joKat.getJSONObject("fields");
                JSONObject katNaziv = katFields.getJSONObject("naziv");
                odabraniKviz.getKategorija().setNaziv(katNaziv.getString("stringValue"));


                //izdvajanje id-eva pitanja dohvacenog kviza
                JSONObject joPitanja = fields.getJSONObject("pitanja");
                JSONObject arrayValue = joPitanja.getJSONObject("arrayValue");
                JSONArray values = arrayValue.optJSONArray("values");
                if (values == null) values = new JSONArray();
                for (int j = 0; j < values.length(); j++) {
                    JSONObject valueItem = values.getJSONObject(j);
                    String tempID = valueItem.getString("stringValue");
                    if(!idDodanih.contains(tempID) && !idIzbacenih.contains(tempID))
                        idDodanih.add(tempID);
                }
            }
        }
        catch (MalformedURLException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void dohvatiPitanja(String projektID) {
        newIdDodanih = new ArrayList<>();

        try {
            //dohvatanje svih pitanja
            String urlPitanja = "https://firestore.googleapis.com/v1/projects/" + projektID +
                    "/databases/(default)/documents/Pitanja?pageSize=500&access_token=" + TOKEN;
            URL url = new URL(urlPitanja);
            HttpURLConnection urlConnection = (HttpURLConnection)url.openConnection();
            InputStream in = new BufferedInputStream(urlConnection.getInputStream());
            String dobavljenaPitanja= convertStreamToString(in);

            JSONObject joPitanja = new JSONObject(dobavljenaPitanja);
            JSONArray pitanjaDocuments = joPitanja.optJSONArray("documents");

            if(pitanjaDocuments != null) {
                for (int l = 0; l < pitanjaDocuments.length(); l++) {
                    JSONObject pitDocument = pitanjaDocuments.getJSONObject(l);

                    String pitName = pitDocument.getString("name");
                    String[] pathFields = pitName.split("/");
                    String pitIndex = pathFields[pathFields.length - 1];

                    //izdvajanje pitanja koja nisu medju pitanjima dohvacenog kviza
                    if (!idDodanih.contains(pitIndex)) {
                        idMogucih.add(pitIndex);
                        JSONObject pitFields = pitDocument.getJSONObject("fields");
                        Pitanje pitanje = new Pitanje();
                        JSONObject nazivPitanja = pitFields.getJSONObject("naziv");
                        pitanje.setNaziv(nazivPitanja.getString("stringValue"));
                        pitanje.setTekstPitanja(nazivPitanja.getString("stringValue"));

                        JSONObject odgovoriPitanja = pitFields.getJSONObject("odgovori");
                        JSONObject arrayValueOdgovori = odgovoriPitanja.getJSONObject("arrayValue");
                        JSONArray valuesOdgovori = arrayValueOdgovori.getJSONArray("values");

                        for (int k = 0; k < valuesOdgovori.length(); k++) {
                            JSONObject odgovorItem = valuesOdgovori.getJSONObject(k);
                            pitanje.getOdgovori().add(odgovorItem.getString("stringValue"));
                        }

                        JSONObject indexTacnog = pitFields.getJSONObject("indexTacnog");
                        pitanje.setTacan(pitanje.getOdgovori().get(indexTacnog.getInt("integerValue")));
                        mogucaPitanja.add(pitanje);
                    }
                    //pitanja koja su trenutno u kvizu
                    else {
                        newIdDodanih.add(pitIndex);
                        JSONObject pitFields = pitDocument.getJSONObject("fields");
                        Pitanje pitanje = new Pitanje();
                        JSONObject nazivPitanja = pitFields.getJSONObject("naziv");
                        pitanje.setNaziv(nazivPitanja.getString("stringValue"));
                        pitanje.setTekstPitanja(nazivPitanja.getString("stringValue"));

                        JSONObject odgovoriPitanja = pitFields.getJSONObject("odgovori");
                        JSONObject arrayValueOdgovori = odgovoriPitanja.getJSONObject("arrayValue");
                        JSONArray valuesOdgovori = arrayValueOdgovori.getJSONArray("values");

                        for (int k = 0; k < valuesOdgovori.length(); k++) {
                            JSONObject odgovorItem = valuesOdgovori.getJSONObject(k);
                            pitanje.getOdgovori().add(odgovorItem.getString("stringValue"));
                        }

                        JSONObject indexTacnog = pitFields.getJSONObject("indexTacnog");
                        pitanje.setTacan(pitanje.getOdgovori().get(indexTacnog.getInt("integerValue")));
                        dodanaPitanja.add(pitanje);
                    }
                }
            }

        }
        catch (MalformedURLException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        pozivatelj.onKvizSaPitanjimaDone(dodanaPitanja, mogucaPitanja, newIdDodanih, idMogucih, odabraniKviz);
    }

    private String convertStreamToString(InputStream iStream) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(iStream));
        StringBuilder sb = new StringBuilder();
        String line;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            try {
                iStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return sb.toString();
    }

    public interface OnMogucaSearchDone {
        void onKvizSaPitanjimaDone(ArrayList<Pitanje> dohvacenaDodana, ArrayList<Pitanje> dohvacenaMoguca, ArrayList<String> dodana, ArrayList<String> moguca, Kviz odabraniKviz);
    }
}
