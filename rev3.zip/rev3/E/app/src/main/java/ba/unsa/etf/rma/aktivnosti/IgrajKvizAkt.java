package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.FrameLayout;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.InformacijeFrag;
import ba.unsa.etf.rma.fragmenti.PitanjeFrag;
import ba.unsa.etf.rma.fragmenti.RangLista;
import ba.unsa.etf.rma.klase.Kviz;

public class IgrajKvizAkt extends AppCompatActivity implements PitanjeFrag.Listener {

    private Kviz kviz;
    private InformacijeFrag infoFrag;
    private PitanjeFrag pitanjeFrag;
    private int brojTacnih;
    private int brojNetacnih;

    private static  final String SIS_KVIZ = "kviz";
    private static  final String SIS_TACNI = "tacni";
    private static  final String SIS_NETACNI = "netacni";

    public static final String EXTRA_KVIZ_TO_PITANJE_FRAG = "pitanjeKviz";
    public static final String EXTRA_KVIZ_TO_INFO_FRAG = "infoKviz";
    public static final String EXTRA_TACNIH_TO_INFO_FRAG = "brTacnih";
    public static final String EXTRA_NETACNIH_TO_INFO_FRAG = "brNetacnih";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_igraj_kviz);

        if(savedInstanceState != null) {
            kviz = savedInstanceState.getParcelable(SIS_KVIZ);
            brojTacnih = savedInstanceState.getInt(SIS_TACNI);
            brojNetacnih = savedInstanceState.getInt(SIS_NETACNI);
        }
        else {
            Intent kvizIntent = getIntent();
            if (kvizIntent != null)
                kviz = kvizIntent.getParcelableExtra(KvizoviAkt.EXTRA_KVIZ_TO_IGRAJKVIZ);
            brojTacnih = 0;
            brojNetacnih = 0;

            FrameLayout ip = findViewById(R.id.informacijePlace);
            FrameLayout pp = findViewById(R.id.pitanjePlace);


            if(ip != null) {
                FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                infoFrag = new InformacijeFrag();
                Bundle argumenti = new Bundle();
                argumenti.putParcelable(EXTRA_KVIZ_TO_INFO_FRAG, kviz);
                argumenti.putInt(EXTRA_TACNIH_TO_INFO_FRAG, brojTacnih);
                argumenti.putInt(EXTRA_NETACNIH_TO_INFO_FRAG, brojNetacnih);
                infoFrag.setArguments(argumenti);
                ft.replace(R.id.informacijePlace, infoFrag).commit();
            }

            if(pp != null) {
                FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                pitanjeFrag = new PitanjeFrag();
                Bundle argPitanje = new Bundle();
                argPitanje.putParcelable(EXTRA_KVIZ_TO_PITANJE_FRAG, kviz);
                pitanjeFrag.setArguments(argPitanje);
                ft.replace(R.id.pitanjePlace, pitanjeFrag).commit();
            }
        }

    }


    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putParcelable(SIS_KVIZ, kviz);
        savedInstanceState.putInt(SIS_TACNI, brojTacnih);
        savedInstanceState.putInt(SIS_NETACNI, brojNetacnih);
    }

    @Override
    public void itemClicked(Boolean odabraniOdgovor) {
        if (odabraniOdgovor) {
            brojTacnih++;
        } else {
            brojNetacnih++;
        }

        infoFrag = new InformacijeFrag();
        Bundle argumenti = new Bundle();
        argumenti.putParcelable(EXTRA_KVIZ_TO_INFO_FRAG, kviz);
        argumenti.putInt(EXTRA_TACNIH_TO_INFO_FRAG, brojTacnih);
        argumenti.putInt(EXTRA_NETACNIH_TO_INFO_FRAG, brojNetacnih);
        infoFrag.setArguments(argumenti);

        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.informacijePlace, infoFrag);
        ft.commit();

    }

    @Override
    public void kvizZavrsen(String imeIgraca) {
        FrameLayout pp = findViewById(R.id.pitanjePlace);

        if(pp != null) {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            RangLista rangLista = new RangLista();
            Bundle argumenti = new Bundle();
            argumenti.putString("ime", imeIgraca);
            argumenti.putDouble("procent", (double)brojTacnih/(brojTacnih + brojNetacnih) * 100);
            argumenti.putString("kviz", kviz.getNaziv());
            rangLista.setArguments(argumenti);
            ft.replace(R.id.pitanjePlace, rangLista).commit();
        }
    }
}
