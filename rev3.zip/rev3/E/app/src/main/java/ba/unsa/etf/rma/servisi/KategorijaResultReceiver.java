package ba.unsa.etf.rma.servisi;

import android.os.Bundle;
import android.os.Handler;
import android.os.ResultReceiver;

public class KategorijaResultReceiver extends ResultReceiver {
    private Receiver mReceiver;

    public KategorijaResultReceiver(Handler handler) {
        super(handler);
    }

    public void setReceiver(Receiver receiver) {
        mReceiver = receiver;
    }

    public interface Receiver {
        void onKategorijaReceiveResult(int resultCode, Bundle resultData);
    }

    @Override
    protected void onReceiveResult(int resultCode, Bundle resultData) {
        if(mReceiver != null)
            mReceiver.onKategorijaReceiveResult(resultCode, resultData);
    }
}
