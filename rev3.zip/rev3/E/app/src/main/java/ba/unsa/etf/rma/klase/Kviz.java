package ba.unsa.etf.rma.klase;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

public class Kviz implements Parcelable {

    private String naziv;
    private ArrayList<Pitanje> pitanja;
    private Kategorija kategorija;
    private String firestoreID;

    public Kviz() {
        pitanja = new ArrayList<>();
        kategorija = new Kategorija();
    }

    public Kviz(String naziv, ArrayList<Pitanje> pitanja, Kategorija kategorija) {
        this.naziv = naziv;
        this.pitanja = pitanja;
        this.kategorija = kategorija;
    }

    public Kviz(String naziv, ArrayList<Pitanje> pitanja, Kategorija kategorija, String id) {
        this.naziv = naziv;
        this.pitanja = pitanja;
        this.kategorija = kategorija;
        this.firestoreID = id;
    }

    private Kviz(Parcel source) {
        this();
        naziv = source.readString();
        source.readTypedList(pitanja, Pitanje.CREATOR);
        kategorija = source.readParcelable(Kategorija.class.getClassLoader());
    }

    public String getFirestoreID() {
        return firestoreID;
    }

    public void setFirestoreID(String firestoreID) {
        this.firestoreID = firestoreID;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public ArrayList<Pitanje> getPitanja() {
        return pitanja;
    }

    public void setPitanja(ArrayList<Pitanje> pitanja) {
        this.pitanja = pitanja;
    }

    public Kategorija getKategorija() {
        return kategorija;
    }

    public void setKategorija(Kategorija kategorija) {
        this.kategorija = kategorija;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(naziv);
        dest.writeTypedList(pitanja);
        dest.writeParcelable(kategorija, flags);
    }

    public static final Parcelable.Creator<Kviz> CREATOR = new Parcelable.Creator<Kviz>() {
        public Kviz createFromParcel(Parcel source) {
            return new Kviz(source);
        }

        public Kviz[] newArray(int size) {
            return new Kviz[size];
        }
    };

    public void dodajPitanje(Pitanje p) {
        if(!pitanja.contains(p))
            pitanja.add(p);
    }

    @Override
    public String toString() {
        return  naziv +  " " + kategorija.getNaziv() +  " " + kategorija.getId();
    }
}
