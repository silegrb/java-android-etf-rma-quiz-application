package ba.unsa.etf.rma.fragmenti;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.ActivityInfo;
import android.graphics.Point;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.Surface;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.adapteri.OdabraniOdgovorAdapter;
import ba.unsa.etf.rma.aktivnosti.IgrajKvizAkt;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;


public class PitanjeFrag extends Fragment {

    private Kviz kviz;
    private int brojPostavljenihPitanja;
    private ArrayList<String> randomOdgovori;
    private Pitanje trenutno;
    private Boolean tacanOdabir;
    private ArrayList<Pitanje> pitanja;
    private TextView tekstPitanja;
    private ListView odgovoriPitanja;
    private OdabraniOdgovorAdapter adapter;
    private Listener listener;
    private String imeIgraca;

    private final static String SIS_KVIZ = "kviz";
    private final static String SIS_RANDOM_ODGOVORI = "random_odg";
    private final static String SIS_BROJ_POSTAVLJENIH_PITANJA = "postavljena";
    private final static String SIS_TRENUTNO_PITANJE = "trenutno";

    public PitanjeFrag() {

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.listener = (Listener)context;
    }


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_pitanje, container, false);
    }

    @Override
    public void onViewCreated (@NonNull View view, Bundle savedInstanceState) {
        tekstPitanja = view.findViewById(R.id.tekstPitanja);
        odgovoriPitanja = view.findViewById(R.id.odgovoriPitanja);

        if(savedInstanceState != null) {
            kviz = savedInstanceState.getParcelable(SIS_KVIZ);
            brojPostavljenihPitanja = savedInstanceState.getInt(SIS_BROJ_POSTAVLJENIH_PITANJA);
            randomOdgovori = savedInstanceState.getStringArrayList(SIS_RANDOM_ODGOVORI);
            trenutno = savedInstanceState.getParcelable(SIS_TRENUTNO_PITANJE);
            pitanja = kviz.getPitanja();
        }
        else {
            if(getArguments() != null && getArguments().containsKey(IgrajKvizAkt.EXTRA_KVIZ_TO_PITANJE_FRAG))
            {
                kviz = getArguments().getParcelable(IgrajKvizAkt.EXTRA_KVIZ_TO_PITANJE_FRAG);
                brojPostavljenihPitanja = 0;
                if(kviz != null)
                    pitanja = kviz.getPitanja();
                if(pitanja.size() != 0) {
                    Random random = new Random();
                    int index = random.nextInt(pitanja.size() - brojPostavljenihPitanja);
                    trenutno = pitanja.get(index);
                    Collections.swap(pitanja, index, pitanja.size() - brojPostavljenihPitanja - 1);
                    randomOdgovori = trenutno.dajRandomOdgovore();
                    brojPostavljenihPitanja++;
                }
            }
        }

        if(pitanja.size() == 0 || pitanja.size() < brojPostavljenihPitanja) {
            tekstPitanja.setText(R.string.zavrsenKviz);
            odgovoriPitanja.setAdapter(new OdabraniOdgovorAdapter(requireActivity(), new ArrayList<String>(), getResources(), ""));
            odgovoriPitanja.setEnabled(false);
            if(listener != null)
                listener.kvizZavrsen("");
        }
        else {
            tekstPitanja.setText(trenutno.getTekstPitanja());
            adapter = new OdabraniOdgovorAdapter(requireActivity(), randomOdgovori, getResources(), trenutno.getTacan());
            odgovoriPitanja.setAdapter(adapter);
        }

        odgovoriPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                if(tacanOdabir == null) {
                    lockActivityOrientation(requireActivity());

                    tacanOdabir = randomOdgovori.get(position).equals(trenutno.getTacan());
                    adapter.setOdabranOdgovor(position);

                    final Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (brojPostavljenihPitanja != pitanja.size()) {
                                Random random = new Random();
                                int index = random.nextInt(pitanja.size() - brojPostavljenihPitanja);
                                trenutno = pitanja.get(index);
                                Collections.swap(pitanja, index, pitanja.size() - brojPostavljenihPitanja -1);
                                tekstPitanja.setText(trenutno.getTekstPitanja());
                                randomOdgovori = trenutno.dajRandomOdgovore();
                                brojPostavljenihPitanja++;
                                adapter = new OdabraniOdgovorAdapter(requireActivity(), randomOdgovori, getResources(), trenutno.getTacan());
                                odgovoriPitanja.setAdapter(adapter);
                            }
                            else {
                                tekstPitanja.setText(R.string.zavrsenKviz);
                                odgovoriPitanja.setAdapter(new OdabraniOdgovorAdapter(requireActivity(), new ArrayList<String>(), getResources(), ""));
                                odgovoriPitanja.setEnabled(false);
                                brojPostavljenihPitanja ++;

                                //alertdialog za unos imena igraca
                                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                                builder.setTitle("Unesite ime za rang listu:");

                                // Set up the input
                                final EditText input = new EditText(requireContext());
                                // Specify the type of input expected; this, for example, sets the input as a password, and will mask the text
                                //input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                                builder.setView(input);

                                // Set up the buttons
                                builder.setPositiveButton("Potvrdi", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        if(!input.getText().toString().trim().equals(""))
                                            imeIgraca = input.getText().toString().trim();
                                        if(listener != null)
                                            listener.kvizZavrsen(imeIgraca);
                                    }
                                });
                                builder.setNegativeButton("Odustani", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        imeIgraca = "";
                                        if(listener != null)
                                            listener.kvizZavrsen(imeIgraca);
                                        dialog.cancel();
                                    }
                                });

                                builder.show();
                            }

                            if(listener != null)
                                listener.itemClicked(tacanOdabir);

                            tacanOdabir = null;
                            requireActivity().setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
                        }
                    }, 2000);
                }
            }
        });

    }


    @Override
    public void onSaveInstanceState(@NonNull Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putParcelable(SIS_KVIZ, kviz);
        savedInstanceState.putInt(SIS_BROJ_POSTAVLJENIH_PITANJA, brojPostavljenihPitanja);
        savedInstanceState.putStringArrayList(SIS_RANDOM_ODGOVORI, randomOdgovori);
        savedInstanceState.putParcelable(SIS_TRENUTNO_PITANJE, trenutno);
    }

    public interface Listener {
        void itemClicked(Boolean odabraniOdgovor);
        void kvizZavrsen(String imeIgraca);
    }

    private static void lockActivityOrientation(Activity activity) {
        Display display = activity.getWindowManager().getDefaultDisplay();
        int rotation = display.getRotation();
        int height;
        int width;

        Point size = new Point();
        display.getSize(size);
        height = size.y;
        width = size.x;

        switch (rotation) {
            case Surface.ROTATION_90:
                if (width > height)
                    activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
                else
                    activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT);
                break;
            case Surface.ROTATION_180:
                if (height > width)
                    activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT);
                else
                    activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE);
                break;
            case Surface.ROTATION_270:
                if (width > height)
                    activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE);
                else
                    activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                break;
            case Surface.ROTATION_0:
                if (height > width)
                    activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                else
                    activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        }
    }

}
