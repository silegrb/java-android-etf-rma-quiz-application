package ba.unsa.etf.rma.fragmenti;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.util.Locale;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.aktivnosti.IgrajKvizAkt;
import ba.unsa.etf.rma.klase.Kviz;


public class InformacijeFrag extends Fragment {

    private Kviz kviz;
    private int ukupnoPitanja;
    private int tacnihOdgovora;
    private int netacnihOdgovora;
    private TextView infBrojTacnih;
    private TextView infBrojPreostalih;
    private TextView infProcenatTacni;

    final private static String SIS_KVIZ = "kviz";
    final private static String SIS_TACNI = "tacni";
    final private static String SIS_NETACNI = "netacni";

    public InformacijeFrag() {}


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_informacije, container, false);

        TextView infNazivKviza = view.findViewById(R.id.infNazivKviza);
        infBrojTacnih = view.findViewById(R.id.infBrojTacnihPitanja);
        infBrojPreostalih = view.findViewById(R.id.infBrojPreostalihPitanja);
        infProcenatTacni = view.findViewById(R.id.infProcenatTacni);
        Button btnKraj = view.findViewById(R.id.btnKraj);

        if(savedInstanceState != null) {
            kviz = savedInstanceState.getParcelable(SIS_KVIZ);
            tacnihOdgovora = savedInstanceState.getInt(SIS_TACNI);
            netacnihOdgovora = savedInstanceState.getInt(SIS_NETACNI);
        }
        else {
            if(getArguments() != null && getArguments().containsKey(IgrajKvizAkt.EXTRA_KVIZ_TO_INFO_FRAG)) {
                kviz = getArguments().getParcelable(IgrajKvizAkt.EXTRA_KVIZ_TO_INFO_FRAG);
                tacnihOdgovora = getArguments().getInt(IgrajKvizAkt.EXTRA_TACNIH_TO_INFO_FRAG);
                netacnihOdgovora = getArguments().getInt(IgrajKvizAkt.EXTRA_NETACNIH_TO_INFO_FRAG);
            }
        }

        ukupnoPitanja = kviz.getPitanja().size();

        infNazivKviza.setText(kviz.getNaziv());
        infBrojTacnih.setText(String.format(Locale.US, " %d", tacnihOdgovora));
        int brojPreostalih = ukupnoPitanja-tacnihOdgovora-netacnihOdgovora-1;
        if(brojPreostalih < 0)
            brojPreostalih = 0;
        infBrojPreostalih.setText(String.format(Locale.US," %d", brojPreostalih));
        if(tacnihOdgovora == 0)
            infProcenatTacni.setText(String.format(Locale.US," %.2f %%", (double)tacnihOdgovora));
        else
            infProcenatTacni.setText(String.format(Locale.US," %.2f %%", (double)tacnihOdgovora/(tacnihOdgovora+netacnihOdgovora)*100));


        btnKraj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requireActivity().onBackPressed();
            }
        });

        return view;
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putParcelable(SIS_KVIZ, kviz);
        savedInstanceState.putInt(SIS_TACNI, tacnihOdgovora);
        savedInstanceState.putInt(SIS_NETACNI, netacnihOdgovora);
    }

}
