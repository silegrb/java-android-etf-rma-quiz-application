package ba.unsa.etf.rma.klase;

import android.os.Parcel;
import android.os.Parcelable;

public class Kategorija implements Parcelable {

    private String naziv;
    private String id;

    public Kategorija() {
    }

    public Kategorija(String naziv, String id) {
        this.naziv = naziv;
        this.id = id;
    }

    private Kategorija(Parcel source) {
        this();
        naziv = source.readString();
        id = source.readString();
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(naziv);
        dest.writeString(id);
    }

    public static final Parcelable.Creator<Kategorija> CREATOR = new Parcelable.Creator<Kategorija>() {
        public Kategorija createFromParcel(Parcel source) {
            return new Kategorija(source);
        }

        public Kategorija[] newArray(int size) {
            return new Kategorija[size];
        }
    };

    @Override
    public String toString() {
        return  naziv +  " " + id;
    }
}
