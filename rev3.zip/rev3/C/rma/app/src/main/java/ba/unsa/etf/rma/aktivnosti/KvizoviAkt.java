package ba.unsa.etf.rma.aktivnosti;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;

public class KvizoviAkt extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kvizovi_akt);
        Spinner spiner = (Spinner) findViewById(R.id.spPostojeceKategorije);
        ListView lista = (ListView) findViewById(R.id.lvKvizovi);
        ArrayList<String> listaKvizova = new ArrayList<String>();
        listaKvizova.add("Nauka");
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.list_red, listaKvizova);
        lista.setAdapter(adapter);
    }
}
