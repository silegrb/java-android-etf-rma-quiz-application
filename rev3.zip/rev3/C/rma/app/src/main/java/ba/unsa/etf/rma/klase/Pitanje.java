package ba.unsa.etf.rma.klase;

import java.util.ArrayList;
import java.util.Collections;

public class Pitanje {
    String naziv;
    String tekstPitanja;
    ArrayList<String> odgovori;
    String tacan;

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getTekstPitanja() {
        return tekstPitanja;
    }

    public void setTekstPitanja(String tekstPitanja) {
        this.tekstPitanja = tekstPitanja;
    }

    public ArrayList<String> getOdgovori() {
        return odgovori;
    }

    public void setOdgovori(ArrayList<String> odgovori) {
        this.odgovori = odgovori;
    }

    public String getTacan() {
        return tacan;
    }

    public void setTacan(String tacan) {
        this.tacan = tacan;
    }

    ArrayList<String> dajRandomOdgovore() {
        ArrayList<String> p=odgovori;
        Collections.shuffle(p);
        return p;
    }
}
